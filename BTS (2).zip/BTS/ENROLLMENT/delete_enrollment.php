<?php 
include '../Database/Database.php';

if (isset($_GET['id']) && !empty($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id'];  
    echo "Received ID: " . $id . "<br>"; 

    $check_stmt = $conn->prepare("SELECT id FROM enrollments WHERE id = ?");
    $check_stmt->bind_param("i", $id);
    $check_stmt->execute();
    $check_stmt->store_result();
    
    if ($check_stmt->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE enrollments SET is_deleted = 1 WHERE id = ?");
        
        if (!$stmt) {
            die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
        }

        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo "<script>alert('Enrollment marked as deleted successfully!'); window.location.href = 'enrolled_masterlist.php';</script>";
            } else {
                echo "No records updated. Verify if the enrollment ID exists or is already marked as deleted.";
            }
        } else {
            echo "Error updating record: " . $conn->error;
        }

        $stmt->close();
    }
}
?>
