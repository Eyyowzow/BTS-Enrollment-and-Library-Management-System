<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$success_message = '';
$error_message = '';

if (isset($_POST['addScholarship'])) {
    $scholarship_name = encryptData(mysqli_real_escape_string($conn, $_POST['scholarship_name']));
    $description = encryptData(mysqli_real_escape_string($conn, $_POST['description']));
    $amount = encryptData(mysqli_real_escape_string($conn, $_POST['amount']));

    $sql = "INSERT INTO scholarships (scholarship_name, description, amount) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("sss", $scholarship_name, $description, $amount);
        if ($stmt->execute()) {
            $success_message = 'Scholarship Added Successfully!';
        } else {
            $error_message = 'Error Adding Scholarship!';
        }
        $stmt->close();
    } 
}

if (isset($_POST['editScholarship'])) {
    $scholarship_id = $_POST['scholarship_id'];
    $scholarship_name = encryptData($_POST['scholarship_name']);
    $description = encryptData($_POST['description']);
    $amount = encryptData($_POST['amount']);

    $sql = "UPDATE scholarships SET scholarship_name=?, description=?, amount=? WHERE scholarship_id=?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sssi", $scholarship_name, $description, $amount, $scholarship_id);
        if ($stmt->execute()) {
            $success_message = 'Scholarship Updated Successfully!';
        } else {
            $error_message = 'Error Updating Scholarship!';
        }
        $stmt->close();
    } else {
        echo "<script>alert('Database error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>

</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Scholarship Masterlist</h4>
                            <p class="mb-0">Data Entry</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Scholarship Button -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addScholarshipModal">Add New Scholarship
                                </button>
                        </ol>
                    </div>
                </div>
                <?php if ($success_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-account-search"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class='alert alert-danger'><?php echo $error_message; ?></div>
                <?php endif; ?>
                <!-- row -->


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Scholarship Name</th>
                                                <th>Amount</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $sql = "SELECT * FROM scholarships WHERE is_deleted = 0 ";
                                            $result = $conn->query($sql);
                                            $count = 1;
                                            if (!$result) {
                                                echo "<tr><td colspan='6'>Error fetching scholarships: " . $conn->error . "</td></tr>";
                                            } else {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . decryptData($row['scholarship_name']) . "</td>";
                                                    echo "<td>" . decryptData($row['amount']) . "</td>";
                                                    echo "<td>
                                                    <span>
                                                    <a href='edit_scholarship.php' 
                                                        data-id='{$row['scholarship_id']}'
                                                        data-name='" . decryptData($row['scholarship_name']) . "' 
                                                        data-description='" . decryptData($row['description']) . "' 
                                                        data-amount='" . decryptData($row['amount']) . "' 
                                                        data-toggle='modal' data-target='#editScholarshipModal'>
                                                        <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>
                                                    
                                                    <a href='view_scholarship.php' class='view-btn'
                                                        data-id='{$row['scholarship_id']}'
                                                        data-scholarship_name='" . decryptData($row['scholarship_name']) . "'
                                                        data-amount='" . decryptData($row['amount']) . "'  
                                                        data-description='" . decryptData($row['description']) . "' 
                                                        data-toggle='modal' data-target='#viewScholarshipModal'>
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>

                                                    <a href='delete_scholarship.php?scholarship_id={$row['scholarship_id']}' 
                                                        data-toggle='tooltip' data-placement='top' title='Delete' 
                                                        onclick=\"return confirm('Are you sure you want to delete this scholarship?')\">
                                                        <i class='fa fa-trash' style='color: red; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>
                                                    </span>
                                                    </td>";
                                                    echo "</tr>";
                                                }
                                            }
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>Scholarship Name</th>
                                                <th>Amount</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                 <!-- Add Scholarship Modal -->
                                <div class="modal fade" id="addScholarshipModal" tabindex="-1" aria-labelledby="addScholarshipModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="manage_scholarships.php" method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addScholarshipModalLabel">Add New Scholarship</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="scholarshipName">Scholarship Name</label>
                                                        <input type="text" class="form-control" name="scholarship_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="scholarshipDescription">Description</label>
                                                        <textarea class="form-control" name="description" required></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="scholarshipAmount">Amount</label>
                                                        <input type="text" class="form-control" name="amount" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="addScholarship" class="btn btn-primary">Add Scholarship</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    
    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 5000); 
        }
    };
    </script>
</body>

</html>
<?php
    include 'edit_scholarship.php';
    include 'view_scholarship.php';

    
?>