<?php
include '../Database/Database.php';

if (isset($_GET['id']) && !empty($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id']; 
    echo "Received ID: " . $id . "<br>";

    $check_stmt = $conn->prepare("SELECT id, is_deleted FROM enrollments WHERE id = ?");
    $check_stmt->bind_param("i", $id);
    $check_stmt->execute();
    $check_stmt->store_result();
    
    echo "Rows returned: " . $check_stmt->num_rows . "<br>"; 

    if ($check_stmt->num_rows > 0) {
        $check_stmt->bind_result($student_id, $is_deleted);
        $check_stmt->fetch();

        echo "Current 'is_deleted' status for student ID " . $id . ": " . $is_deleted . "<br>";

        if ($is_deleted == 1) {
            $stmt = $conn->prepare("UPDATE enrollments SET is_deleted = 0 WHERE id = ?");
            
            if (!$stmt) {
                die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
            }

            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    echo "<script>alert('Student restored successfully!'); window.location.href = 'backup_restore.php';</script>";
                } else {
                    echo "No rows affected. This may be because the student is already restored.";
                }
            } else {
                echo "Error restoring student: " . $conn->error;
            }
$conn->close();
?>
