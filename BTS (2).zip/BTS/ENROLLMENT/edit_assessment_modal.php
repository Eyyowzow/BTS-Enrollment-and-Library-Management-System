<!-- Edit Assessment Modal -->
<div class="modal fade" id="editAssessmentModal" tabindex="-1" aria-labelledby="editAssessmentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="manage_assessments.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editAssessmentModalLabel">Edit Assessment</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="assessment_id" id="edit_assessment_id">
                    <div class="form-group">
                        <label for="edit_assessment_name">Assessment Name</label>
                        <input type="text" class="form-control" name="assessment_name" id="edit_assessment_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_assessment_level">Level</label>
                        <input type="text" class="form-control" name="assessment_level" id="edit_assessment_level" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_assessment_date">Assessment Date</label>
                        <input type="date" class="form-control" name="assessment_date" id="edit_assessment_date" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_competency_title">Competency Title</label>
                        <input type="text" class="form-control" name="competency_title" id="edit_competency_title" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_assessor">Assessor Name</label>
                        <input type="text" class="form-control" name="assessor" id="edit_assessor" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_location">Location</label>
                        <input type="text" class="form-control" name="location" id="edit_location" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button data-toggle="modal" type="submit" name="editAssessment" class="btn btn-primary">Update Assessment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Edit button click
    document.addEventListener('DOMContentLoaded', function () {
        const editButtons = document.querySelectorAll('.edit-btn');
        
        editButtons.forEach(button => {
            button.addEventListener('click', function () {
                // Fetch data
                const assessmentId = this.getAttribute('data-id');
                const assessmentName = this.getAttribute('data-name');
                const assessmentLevel = this.getAttribute('data-level');
                const assessmentDate = this.getAttribute('data-date');
                const competencyTitle = this.getAttribute('data-title');
                const assessorName = this.getAttribute('data-assessor');
                const location = this.getAttribute('data-location');
                document.getElementById('edit_assessment_id').value = assessmentId;
                document.getElementById('edit_assessment_name').value = assessmentName;
                document.getElementById('edit_assessment_level').value = assessmentLevel;
                document.getElementById('edit_assessment_date').value = assessmentDate;
                document.getElementById('edit_competency_title').value = competencyTitle; 
                document.getElementById('edit_assessor').value = assessorName;
                document.getElementById('edit_location').value = location; 
            });
        });
    });
</script>