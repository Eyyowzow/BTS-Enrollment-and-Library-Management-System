<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// FETCHING USER NAME
$user_id = $_SESSION['user_id']; 
$query = "SELECT first_name FROM users WHERE user_id = '$user_id'";  
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $fetchedFirstName = $row['first_name']; 
    $_SESSION['first_name'] = $fetchedFirstName;  
} else {
    $_SESSION['first_name'] = 'User';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
</head>

<body>
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
                <div class="row page-titles mx-0" id="hide">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                        <h4>Welcome, <?php echo decryptData($_SESSION['first_name']); ?>!</h4>
                        <?php
                            
                            // Admin Role
                            if ($_SESSION['role'] == 'Administrator') {
                                echo "<p class='mb-0'>This is Admin Panel</p>";

                            // Registrar Role
                            } elseif ($_SESSION['role'] == 'Registrar') {
                                echo "<p class='mb-0'>This is Registrar Panel</p>";
                            }
                            ?>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="stat-widget-two card-body">
                                <div class="stat-content">
                                    <div class="stat-text">Total Students </div>
                                    <div class="stat-digit">
                                        <?php
                                        $totalStudentsQuery = "SELECT COUNT(student_id) as total_students FROM students WHERE is_deleted = 0";
                                        $totalStudentsResult = mysqli_query($conn, $totalStudentsQuery);
                                        $totalStudents = mysqli_fetch_assoc($totalStudentsResult)['total_students'];
                                        echo $totalStudents; 
                                        ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="stat-widget-two card-body">
                                <div class="stat-content">
                                    <div class="stat-text">Total Enrolled</div>
                                    <div class="stat-digit">
                                        <?php 
                                        // Modify the query to count only enrolled students who are not dropped
                                        $totalEnrolledQuery = "SELECT COUNT(id) as total_enrolled FROM enrollments WHERE student_status != 'dropped' AND is_deleted=0";
                                        $totalEnrolledResult = mysqli_query($conn, $totalEnrolledQuery);
                                        $totalEnrolled = mysqli_fetch_assoc($totalEnrolledResult)['total_enrolled'];                                        
                                        echo $totalEnrolled; 
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="stat-widget-two card-body">
                                <div class="stat-content">
                                    <div class="stat-text">Total Programs</div>
                                    <div class="stat-digit">
                                        <?php 
                                        $totalProgramsQuery = "SELECT COUNT(program_id) as total_programs FROM programs WHERE is_deleted=0";
                                        $totalProgramsResult = mysqli_query($conn, $totalProgramsQuery);
                                        $totalPrograms = mysqli_fetch_assoc($totalProgramsResult)['total_programs'];                                        
                                        echo $totalPrograms; 
                                        ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6"> 
                        <div class="card">
                            <div class="stat-widget-two card-body">
                                <div class="stat-content">
                                    <div class="stat-text">Dropped Students</div>
                                    <div class="stat-digit">
                                        <?php 
                                        // FETCH TOTAL ENROLLED BY YAER BAR CHART
                                        $enrolledQuery = "SELECT YEAR(enrollment_date) as year, COUNT(id) as enrolled_count 
                                        FROM enrollments 
                                        WHERE student_status = 'enrolled'
                                        GROUP BY year";
                                        $enrolledResult = mysqli_query($conn, $enrolledQuery);
                                        $enrolledData = [];
                                        while ($row = mysqli_fetch_assoc($enrolledResult)) {
                                        $enrolledData[$row['year']] = $row['enrolled_count'];
                                        }

                                        // FETCH TOTAL DROPPED BY YEAR BAR CHART
                                        $droppedQuery = "SELECT YEAR(enrollment_date) as year, COUNT(id) as dropped_count 
                                        FROM enrollments 
                                        WHERE student_status = 'dropped' 
                                        GROUP BY year";
                                        $droppedResult = mysqli_query($conn, $droppedQuery);
                                        $droppedData = [];
                                        while ($row = mysqli_fetch_assoc($droppedResult)) {
                                        $droppedData[$row['year']] = $row['dropped_count'];
                                        }
                                        $years = array_unique(array_merge(array_keys($enrolledData), array_keys($droppedData)));
                                        $enrolledCounts = [];
                                        $droppedCounts = [];
                                        foreach ($years as $year) {
                                        $enrolledCounts[] = isset($enrolledData[$year]) ? $enrolledData[$year] : 0;
                                        $droppedCounts[] = isset($droppedData[$year]) ? $droppedData[$year] : 0;
                                        }
                                        // Query to count the number of dropped students
                                        $totalDroppedQuery = "SELECT COUNT(id) as total_dropped FROM enrollments WHERE student_status = 'dropped'";
                                        $totalDroppedResult = mysqli_query($conn, $totalDroppedQuery);
                                        $totalDropped = mysqli_fetch_assoc($totalDroppedResult)['total_dropped'];                                        
                                        echo $totalDropped; 
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Students Overview</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xl-12 col-lg-8">
                                        <div id="morris-bar-chart"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>

    <!-- Vectormap -->
    <script src="../bootstrap/vendor/raphael/raphael.min.js"></script>
    <script src="../bootstrap/vendor/morris/morris.min.js"></script>
    <script src="../bootstrap/vendor/gaugeJS/dist/gauge.min.js"></script>

    <!--  flot-chart js -->
    <script src="../bootstrap/vendor/flot/jquery.flot.js"></script>
    <script src="../bootstrap/vendor/flot/jquery.flot.resize.js"></script>

    <!-- Counter Up -->
    <script src="../bootstrap/vendor/jquery.counterup/jquery.counterup.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


    <script>
        $(document).ready(function () {
            new Morris.Bar({
                element: 'morris-bar-chart', 
                data: [
                    <?php 
                    foreach ($years as $index => $year) {
                        echo "{ year: '{$year}', enrolled: {$enrolledCounts[$index]}, dropped: {$droppedCounts[$index]} },";
                    }
                    ?>
                ],
                xkey: 'year',
                ykeys: ['enrolled', 'dropped'],
                labels: ['Enrolled', 'Dropped'],
                barColors: ['#73a5c6', '#d63031'],
                hideHover: 'auto'
            });
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            setTimeout(function() {
                var message = document.getElementById("hide");
                if (message) {
                    message.style.display = "none"; 
                }
            }, 10000);
        });
    </script>

</body>

</html>