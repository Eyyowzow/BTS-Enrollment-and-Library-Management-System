<?php
session_start();
include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';

if (isset($_POST['addProgram'])) {
    $program_code = encryptData(mysqli_real_escape_string($conn, $_POST['program_code']));
    $program_name = encryptData(mysqli_real_escape_string($conn, $_POST['program_name']));
    $level = encryptData(mysqli_real_escape_string($conn, $_POST['level']));
    $description = encryptData(mysqli_real_escape_string($conn, $_POST['description']));

    $sql = "INSERT INTO programs (program_code, program_name, level, description) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("ssss", $program_code, $program_name, $level, $description);
        if ($stmt->execute()) {
            $success_message = 'Program Added Successfully!';
        } else {
            $error_message = 'Error Adding Program!';
        }
        $stmt->close();
    } 
}

if (isset($_POST['editProgram'])) {
    $program_id = $_POST['program_id'];
    $program_code = encryptData($_POST['program_code']);
    $program_name = encryptData($_POST['program_name']);
    $level = encryptData($_POST['level']);
    $description = encryptData($_POST['description']);

    $sql = "UPDATE programs SET program_code=?, program_name=?, level=?, description=? WHERE program_id=?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ssssi", $program_code, $program_name, $level, $description, $program_id);
        if ($stmt->execute()) {
            $success_message = 'Program Updated Successfully!';
        } else {
            $error_message = 'Error Updating Program!';
        }
        $stmt->close();
    } else {
        echo "<script>alert('Database error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>

</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Program Masterlist</h4>
                            <p class="mb-0">Data Entry</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Program Button -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addProgramModal">Add New Program
                                </button>
                        </ol>
                    </div>
                </div>
                <?php if ($success_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-account-search"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class='alert alert-danger'><?php echo $error_message; ?></div>
                <?php endif; ?>
                <!-- row -->


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Code</th>
                                                <th>Program Name</th>
                                                <th>Level</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $sql = "SELECT * FROM programs WHERE is_deleted = 0";
                                            $result = $conn->query($sql);
                                            $count = 1;
                                            if (!$result) {
                                                echo "<tr><td colspan='6'>Error fetching programs: " . $conn->error . "</td></tr>";
                                            } else {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . decryptData($row['program_code']) . "</td>";
                                                    echo "<td>" . decryptData($row['program_name']) . "</td>";
                                                    echo "<td>" . decryptData($row['level']) . "</td>";
                                                    echo "<td>
                                                    <a href='edit_program.php'
                                                        data-id='{$row['program_id']}'
                                                        data-code='" . decryptData($row['program_code']) . "' 
                                                        data-name='" . decryptData($row['program_name']) . "' 
                                                        data-level='" . decryptData($row['level']) . "' 
                                                        data-description='" . decryptData($row['description']) . "' 
                                                        data-toggle='modal' data-target='#editProgramModal'>
                                                        <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>

                                                    <a href='view_program.php' class='view-btn'
                                                        data-id='{$row['program_id']}'
                                                        data-program_code='" . decryptData($row['program_code']) . "' 
                                                        data-program_name='" . decryptData($row['program_name']) . "' 
                                                        data-level='" . decryptData($row['level']) . "' 
                                                        data-description='" . decryptData($row['description']) . "' 
                                                        data-toggle='modal' data-target='#viewProgramModal'> 
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>

                                                    <a href='delete_program.php?program_id={$row['program_id']}' title='Delete' 
                                                        onclick=\"return confirm('Are you sure you want to delete this assessment?')\">
                                                        <i class='fa fa-trash' style='color: red; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>
                                                    </td>";
                                                    echo "</tr>";
                                                }
                                            }
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>Code</th>
                                                <th>Program Name</th>
                                                <th>Level</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                <!-- Add Program Modal --> 
                                <div class="modal fade" id="addProgramModal" tabindex="-1" aria-labelledby="addProgramModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <input type="hidden" name="program_id" value="<?php echo $program_id; ?>" />

                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addProgramModalLabel">Add New Program</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">        
                                                    <form action="manage_programs.php" method="POST">

                                                    <div class="form-group">
                                                        <label for="programCode">Program Code</label>
                                                        <input type="text" class="form-control" name="program_code" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="programName">Program Name</label>
                                                        <input type="text" class="form-control" name="program_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="level">Level</label>
                                                        <input type="text" class="form-control" name="level" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="description">Description</label>
                                                        <textarea class="form-control" name="description" required></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="addProgram" class="btn btn-primary">Add Program</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    
    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
    
    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 5000); 
        }
    };
    </script>
</body>
<?php
include 'edit_program.php';
include 'view_program.php';
?>
</html>