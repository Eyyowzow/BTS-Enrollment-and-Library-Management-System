<?php
include '../Database/Database.php';
include 'encryption.php';

$query = "SELECT DISTINCT batch_no FROM schedules WHERE is_deleted = '0'";
$result = $conn->query($query);

$options = '<option value="">Select Batch</option>';
while ($row = $result->fetch_assoc()) {
    $options .= '<option value="' . htmlspecialchars($row['batch_no']) . '">' . htmlspecialchars($row['batch_no']) . '</option>';
}
echo $options;
?>
