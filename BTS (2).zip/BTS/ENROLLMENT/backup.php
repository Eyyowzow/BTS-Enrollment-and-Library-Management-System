<?php 
session_start();

include 'header.php';
include 'sidebar.php';

$error_message = "";
$success_message = "";
if (isset($_POST['login'])) {
    $login_username = $_POST['username'];
    $login_password = $_POST['user_password'];

    $stmt = $conn->prepare("SELECT user_password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $login_username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($hashed_password, $role);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($login_password, $hashed_password) && $role === 'Administrator') {
            $_SESSION['isAuthenticated'] = true;
        } else {
            $error_message = 'Invalid credentials or insufficient permissions.';
        }
    } else {
        $errorMsg = 'User not found.';
    }
    $stmt->close();
}

if (isset($_SESSION['isAuthenticated']) && $_SESSION['isAuthenticated'] && isset($_POST['backup'])) {
    $backupFile = '../DATABASE/BACKUPS/' . $dbname . '_' . date('Y-m-d_H-i-s') . '.sql';

    $mysqldumpPath = "C:/xampp/mysql/bin/mysqldump";
    $command = "$mysqldumpPath --opt -h $servername -u $username " . ($password ? "-p$password " : "") . "$dbname > $backupFile";

    exec($command . " 2>&1", $output, $result);

    if ($result === 0) {
        $success_message = "Database backup successful! Saved to $backupFile";
    } else {
        $error_message = "Database backup failed! Error: " . implode("\n", $output);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <style>
        table.dataTable {
            table-layout: fixed;
            width: 100%;
        }
    </style>
</head>

<body>
<div class="content-body">
            <div class="container-fluid">
                <div class="row">
                
                    <div class="col-xl-12 col-xxl-12">
                    <?php if ($success_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-check"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class='alert alert-danger'><?php echo $error_message; ?></div>
                <?php endif; ?>
                        <div class="card">
                            <div class="card-header">
                            </div>
                            <div class="card-body">
                                
                            
                            <form action="backup.php" method="POST">
                                <div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Benguet Technical School <br> Enrollment Management System</h4>
                                    <?php if (!isset($_SESSION['isAuthenticated']) || !$_SESSION['isAuthenticated']): ?>
                                    <form action="" method="">
                                        <div class="form-group">
                                            <input type="text" for="username" name="username" class="form-control" id="username" placeholder="Username" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" for="user_password" id="user_password" name="user_password" class="form-control" placeholder="Password" required>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block" name="login" >Sign In</button>
                                        </div>
                                    </form>
                                    <?php if ($error_message): ?>
                                            <p style="color:red;"><?php echo $error_message; ?></p>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <form method="post" action="">
                                            <button type="submit" name="backup" class="btn btn-primary btn-block">Backup Database</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div> 
                        <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 8000); 
        }
    };
    </script> 

    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
</body>
</html>
