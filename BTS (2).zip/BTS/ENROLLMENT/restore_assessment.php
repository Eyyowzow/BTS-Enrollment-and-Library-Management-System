<?php

include '../Database/Database.php';
if (isset($_GET['assessment_id'])) {
    $assessment_id = $_GET['assessment_id']; 
    
    $sql = "UPDATE assessments SET is_deleted = 0 WHERE assessment_id = $assessment_id";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Assessment deleted successfully');</script>";
        header("Location: backup_restore.php");
        exit(); 
    } else {
        echo "Error hiding assessment: " . mysqli_error($conn);
    }
}
?>
