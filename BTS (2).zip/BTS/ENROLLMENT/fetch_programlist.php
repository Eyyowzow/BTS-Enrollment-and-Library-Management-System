<?php
include '../Database/Database.php';
include_once 'encryption.php';
if (isset($_GET['program_id'])) {
    $program_id = $_GET['program_id'];
    
    if (!empty($program_id)) {
        error_log("Fetching students for Program ID: " . $program_id);
        
        $sql = "SELECT e.id, s.ULI, 
        s.first_name,
        s.last_name,
        s.gender,
        e.student_status 
               
        FROM enrollments e
        JOIN students s ON e.student_id = s.student_id
        JOIN programs p ON e.program_id = p.program_id
        WHERE p.program_id = ?
        ";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $program_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $counter = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $counter++ . "</td>";
                echo "<td>" . decryptData($row['ULI']) . "</td>";
                echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</td>";
                echo "<td>" . decryptData($row['gender']) . "</td>";
                echo "<td>" . htmlspecialchars($row['student_status']) . "</td>";
                echo "<td><a href='edit_student.php?id=" . $row['id'] . "'>
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                echo </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No students found for this trainer</td></tr>";
        }
    }
}

?>
