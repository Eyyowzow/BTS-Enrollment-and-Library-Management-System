<!-- Edit Assessment Modal -->
<div class="modal fade" id="viewAssessmentModal" tabindex="-1" aria-labelledby="viewAssessmentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewAssessmentModalLabel">Assessment Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="assessment_id" id="view_assessment_id">
                    <p><strong>Assessment Name:</strong> <span id="viewAssessment"></span></p>
                    <p><strong>Assessment Level:</strong> <span id="viewLevel"></span></p>
                    <p><strong>Assessment Date:</strong> <span id="viewDate"></span></p>
                    <p><strong>Competency Title:</strong> <span id="viewTitle"></span></p>
                    <p><strong>Assessor Name:</strong> <span id="viewAssessor"></span></p>
                    <p><strong>Location:</strong> <span id="viewLocation"></span></p>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const viewButtons = document.querySelectorAll('.view-btn');

        viewButtons.forEach(btn => {
            btn.addEventListener('click', function () {
            document.getElementById('viewAssessment').textContent = this.getAttribute('data-assessment_name');
            document.getElementById('viewLevel').textContent = this.getAttribute('data-assessment_level');
            document.getElementById('viewDate').textContent = this.getAttribute('data-assessment_date');
            document.getElementById('viewTitle').textContent = this.getAttribute('data-competency_title');
            document.getElementById('viewAssessor').textContent = this.getAttribute('data-assessor');
            document.getElementById('viewLocation').textContent = this.getAttribute('data-location');
        });
    });
});
</script>
