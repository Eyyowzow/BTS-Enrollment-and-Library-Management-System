<?php 
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT first_name, middle_name, last_name, username, user_password FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die('MySQL prepare error: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $first_name = decryptData($user['first_name']);
    $middle_name = decryptData($user['middle_name']);
    $last_name = decryptData($user['last_name']);
    $username = $user['username'];
    $hashed_password = $user['user_password'];

    $_SESSION['first_name'] = $first_name; 
} else {
    echo "User not found.";
    exit();
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_first_name = encryptData($_POST['first_name']);
    $new_middle_name = encryptData($_POST['middle_name']);
    $new_last_name = encryptData($_POST['last_name']);    
    $new_username = $_POST['username'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];

    // Verify current password
    $query = "SELECT user_password FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (password_verify($current_password, $user['user_password'])) {
        // Updates the account name and username
        $update_query = "UPDATE users SET first_name = ?, middle_name = ?, last_name = ?, username = ? WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("ssssi", $new_first_name, $new_middle_name, $new_last_name, $new_username, $user_id);
        
        if ($update_stmt->execute()) {
            $success_message = 'Account details updated successfully!';
        } else {
            $error_message = 'Error updating account details.';
        }

        // Update password if a new one is provided
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_password_query = "UPDATE users SET user_password = ? WHERE user_id = ?";
            $update_password_stmt = $conn->prepare($update_password_query);
            $update_password_stmt->bind_param("si", $hashed_password, $user_id);
            
            if ($update_password_stmt->execute()) {
                $success_message = 'Password updated successfully!';
            } else {
                $error_message = 'Error updating password.';
            }
        }

        // Reload updated data to display in input fields
        $query = "SELECT first_name, middle_name, last_name, username FROM users WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $first_name = decryptData($user['first_name']);
            $middle_name = decryptData($user['middle_name']);
            $last_name = decryptData($user['last_name']);
            $username = $user['username'];
        }
    } else {
        $error_message = 'Current password is incorrect.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System</title>
</head>
<body>
    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4>Hi <?php echo htmlspecialchars($first_name); ?>!</h4>
                        <p class="mb-0">This is your profile.</p>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Profile</a></li>
                        <li class="breadcrumb-item active"><a href="./index.php">Back</a></li>
                    </ol>
                </div>
            </div>
            <!-- Display success or error message -->
            <?php if (!empty($success_message)): ?>
                                        <div class='alert alert-success'><?php echo $success_message; ?></div>
                                    <?php endif; ?>

                                    <?php if (!empty($error_message)): ?>
                                        <div class='alert alert-danger'><?php echo $error_message; ?></div>
                                    <?php endif; ?>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="profile-tab">
                            <div class="custom-tab-1">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a href="#about-me" data-toggle="tab" class="nav-link">Account Setting</a></li>
                                </ul>
                                <div class="pt-4 border-bottom-1 pb-4">
                                    <h5 class="text-primary">Change Password</h5>
                                    
                                    

                                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label for="first_name">First Name</label>
                                                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo htmlspecialchars($first_name); ?>" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="middle_name">Middle Name</label>
                                                <input type="text" class="form-control" id="middle_name" name="middle_name" value="<?php echo htmlspecialchars($middle_name); ?>">
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="last_name">Last Name</label>
                                                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo htmlspecialchars($last_name); ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="username">Username</label>
                                            <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" required>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="current_password">Current Password</label>
                                                <input type="password" id="current_password" name="current_password" placeholder="Current Password" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="new_password">New Password</label>
                                                <input type="password" id="new_password" name="new_password" placeholder="New Password" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input" id="gridCheck" required>
                                                <label for="gridCheck" class="form-check-label">Confirm the above information is correct.</label>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
</body>
</html>
