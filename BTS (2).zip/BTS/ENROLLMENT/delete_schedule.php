<?php
include '../Database/Database.php';

if (isset($_GET['schedule_id'])) {
    $schedule_id = $_GET['schedule_id'];
    
    $sql = "UPDATE schedules SET is_deleted = 1 WHERE schedule_id = $schedule_id";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Schedule deleted successfully');</script>";
        header("Location: manage_schedules.php");

    } else {
        echo "Error hiding student: " . mysqli_error($conn);
    }
}
?>
