<?php
include '../Database/Database.php';
include 'encryption.php';
if (isset($_POST['query'])) {
    $query = trim($_POST['query']);  

    if (!empty($query)) {
        $sql = "SELECT trainor_id, first_name, last_name,
                CONCAT(first_name, ' ', last_name) AS trainor_name 
                FROM trainors 
                WHERE (first_name LIKE ? OR last_name LIKE ? )
                AND is_deleted = 0
                LIMIT 10";
        $stmt = $conn->prepare($sql);
        $search_query = "%".$query."%";
        $stmt->bind_param('ss', $search_query, $search_query);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li data-trainor_id='".$row['trainor_id']."'>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</li>";
            }
        } else {
            echo "<li>No trainers found</li>";
        }
    } else {
        echo "<center><li>Please enter a name to search</li><center>";  
    }
}
?>
