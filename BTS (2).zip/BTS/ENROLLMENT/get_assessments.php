<?php
include '../Database/Database.php';
include 'encryption.php';

$assessment_query = "SELECT assessment_id, assessment_name FROM assessments WHERE is_deleted = 0";
$result = $conn->query($assessment_query);

$options = '<option value="">Select Assessment</option>';
$options = '<option value="">N/A</option>';
while ($row = $result->fetch_assoc()) {
    echo "<option value='" . $row['assessment_id'] . "'>" . decryptData($row['assessment_name']) . "</option>";
}

echo $options;
?>
