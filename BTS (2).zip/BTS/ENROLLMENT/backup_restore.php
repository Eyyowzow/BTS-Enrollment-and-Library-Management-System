<?php
session_start();
include 'header.php';
include 'sidebar.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <style>
        table.dataTable {
            table-layout: fixed;
            width: 100%;
        }
    </style>
</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card">
                            <div class="card-body">
                            <!-- Nav tabs -->
                            <div class="default-tab">
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-toggle="tab" href="#Registered">Registered</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#Enrolled">Enrolled</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#Assessment">Assessment</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#Program">Program</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#Trainor">Trainor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#Schedule">Schedule</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#Scholarship">Scholarship</a>
                                </ul><br>

                                <!-- Tab panes -->
                                <div class="tab-content tabcontent-border">
                                    <div class="tab-pane fade show active" id="Registered" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="registeredTable" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>ULI</th>
                                                        <th>Student Name</th>
                                                        <th>Gender</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php
                                                $sql = "SELECT student_id, ULI, first_name, last_name, gender, status 
                                                        FROM students 
                                                        WHERE is_deleted = 1";

                                                $result = mysqli_query($conn, $sql);

                                                if (!$result) {
                                                    echo '<tr><td colspan="5">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                    exit();
                                                }

                                                $count = 1;

                                                if (mysqli_num_rows($result) > 0) {
                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                        $uli = decryptData($row['ULI']);
                                                        $fullName = decryptData($row['first_name']) . ' ' . decryptData($row['last_name']);
                                                        $gender = decryptData($row['gender']);
                                                        $status = decryptData($row['status']);
                                                        $action = '<a href="restore_student.php?student_id=' . $row['student_id'] . '" 
                                                                    class="btn btn-primary">
                                                                    <i class="fa fa-undo" style:"color: green; font-size: 15px;"></i>
                                                                </a>';
                                                        echo "
                                                        <tr>
                                                            <td>{$count}</td>
                                                            <td>{$uli}</td>
                                                            <td>{$fullName}</td>
                                                            <td>{$gender}</td>
                                                            <td>{$action}</td>
                                                        </tr>";
                                                        $count++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>#</th>
                                                    <th>ULI</th>
                                                    <th>Student Name</th>
                                                    <th>Gender</th>
                                                    <th>Action</th>
                                                </tr>
                                            </tfoot>
                                        </table>

                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="Enrolled" role="tabpanel">
                                        <div class="table-responsive">
                                        <table id="enrolledTable" class="display table-responsive-sm" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>ULI</th>
                                                    <th>Student Name</th>
                                                    <th>Gender</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $sql = "SELECT e.id,
                                                        s.ULI,
                                                        s.first_name, 
                                                        s.last_name, 
                                                        CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                                                        CONCAT(p.program_name, ' ', p.level) AS tesda_program, 
                                                        CONCAT(t.first_name, ' ', t.last_name) AS trainor_name, 
                                                        sched.batch_no,
                                                        CONCAT(sched.starts_date, ' - ', sched.end_date) AS date_span, 
                                                        e.student_status 
                                                    FROM enrollments e
                                                    JOIN students s ON e.student_id = s.student_id
                                                    JOIN programs p ON e.program_id = p.program_id
                                                    JOIN trainors t ON e.trainor_id = t.trainor_id
                                                    JOIN schedules sched ON e.schedule_id = sched.schedule_id
                                                    WHERE e.is_deleted = 1";

                                            $result = mysqli_query($conn, $sql);

                                            if (!$result) {
                                                echo "<tr><td colspan='5'>Error executing query: " . mysqli_error($conn) . "</td></tr>";
                                                exit;
                                            }

                                            $count = 1;

                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    $uli = decryptData($row['ULI']);
                                                    $student_name = decryptData($row['first_name']) . ' ' . decryptData($row['last_name']);
                                                    $batch = htmlspecialchars($row['batch_no']);
                                                    $action = '<a href="restore_enrollee.php?id=' . $row['id'] . '"><i class="fa fa-undo" style:"color: green; font-size: 15px;"></i></a>';

                                                    echo "<tr>
                                                            <td>{$count}</td>
                                                            <td>{$uli}</td>
                                                            <td>{$student_name}</td>
                                                            <td>{$batch}</td>
                                                            <td>{$action}</td>
                                                        </tr>";
                                                    $count++;
                                                }
                                            } 
                                              
                                            ?>

                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>#</th>
                                                    <th>ULI</th>
                                                    <th>Student Name</th>
                                                    <th>Gender</th>
                                                    <th>Action</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="Assessment" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="assessmentTable" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Assessment Name</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    // Query to fetch deleted assessments
                                                    $sql = "SELECT * FROM assessments WHERE is_deleted = 1";
                                                    $result = $conn->query($sql);

                                                    // Error handling
                                                    if (!$result) {
                                                        echo '<tr><td colspan="3">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                        exit;
                                                    }

                                                    $count = 1;

                                                    if (mysqli_num_rows($result) > 0) {
                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            $assessmentName = decryptData($row['assessment_name']);
                                                            
                                                            $action = '<a href="restore_assessment.php?assessment_id=' . $row['assessment_id'] . '" 
                                                                    class="btn btn-primary">
                                                                    <i class="fa fa-undo" style:"color: green; font-size: 15px;"></i>
                                                                    </a>';

                                                            echo "
                                                            <tr>
                                                                <td>{$count}</td>
                                                                <td>{$assessmentName}</td>
                                                                <td>{$action}</td>
                                                            </tr>";
                                                            $count++;
                                                        }
                                                    } 
                                                    ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Assessment Name</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="Program" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="programTable" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Code</th>
                                                        <th>Program Name</th>
                                                        <th>Level</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql = "SELECT * FROM programs WHERE is_deleted = 1";
                                                    $result = mysqli_query($conn, $sql);

                                                    // Error handling
                                                    if (!$result) {
                                                        echo '<tr><td colspan="5">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                        exit;
                                                    }

                                                    $count = 1;

                                                    if (mysqli_num_rows($result) > 0) {
                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            $programCode = decryptData($row['program_code']);
                                                            $programName = decryptData($row['program_name']);
                                                            $level = decryptData($row['level']);

                                                            $action = '<a href="restore_program.php?program_id=' . $row['program_id'] . '" 
                                                                    class="btn btn-primary">
                                                                    <i class="fa fa-undo" style:"color: green; font-size: 15px;"></i>
                                                                    </a>';

                                                            echo "
                                                            <tr>
                                                                <td>{$count}</td>
                                                                <td>{$programCode}</td>
                                                                <td>{$programName}</td>
                                                                <td>{$level}</td>
                                                                <td>{$action}</td>
                                                            </tr>";
                                                            $count++;
                                                        }
                                                    } 
                                                    ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Code</th>
                                                        <th>Program Name</th>
                                                        <th>Level</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="Trainor" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="trainorTable" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Trainor Name</th>
                                                        <th>Expertise</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql = "SELECT trainor_id, tesda_accreditation_no, 
                                                                    first_name, middle_name, last_name, 
                                                                    CONCAT(first_name, ' ', last_name) AS full_name, 
                                                                    contact_number, email, expertise 
                                                            FROM trainors 
                                                            WHERE is_deleted = 1";

                                                    $result = mysqli_query($conn, $sql);

                                                    if (!$result) {
                                                        echo '<tr><td colspan="4">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                        exit;
                                                    }

                                                    $count = 1;

                                                    if (mysqli_num_rows($result) > 0) {
                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            $fullName = decryptData($row['first_name']) . ' ' . decryptData($row['last_name']);
                                                            $expertise = decryptData($row['expertise']);

                                                            $action = '<a href="restore_trainor.php?trainor_id=' . $row['trainor_id'] . '" 
                                                                        class="btn btn-primary">
                                                                        <i class="fa fa-undo" style:"color: green; font-size: 15px;"></i>
                                                                    </a>';

                                                            // Display row
                                                            echo "
                                                            <tr>
                                                                <td>{$count}</td>
                                                                <td>{$fullName}</td>
                                                                <td>{$expertise}</td>
                                                                <td>{$action}</td>
                                                            </tr>";
                                                            $count++;
                                                        }
                                                    } 
                                                    ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Trainor Name</th>
                                                        <th>Expertise</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="Schedule" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="scheduleTable" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Batch</th>
                                                        <th>Program</th>
                                                        <th>Date</th>
                                                        <th>Trainer</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    // Query to fetch deleted schedules
                                                    $schedule_query = "SELECT s.schedule_id, s.program_id, s.trainor_id, 
                                                                            p.program_name, p.level, t.first_name, t.last_name, 
                                                                            CONCAT(p.program_name, ' ', p.level) AS tesda_program, 
                                                                            CONCAT(s.starts_date, ' - ', s.end_date) AS date_span,
                                                                            s.batch_no, s.days, 
                                                                            CONCAT(t.first_name, ' ', t.last_name) AS trainor_name
                                                                    FROM schedules s
                                                                    JOIN programs p ON s.program_id = p.program_id
                                                                    JOIN trainors t ON s.trainor_id = t.trainor_id
                                                                    WHERE s.is_deleted = 1";

                                                    $result = mysqli_query($conn, $schedule_query);

                                                    // Error handling
                                                    if (!$result) {
                                                        echo '<tr><td colspan="6">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                        exit;
                                                    }

                                                    $count = 1;

                                                    // If deleted schedules are found, display them
                                                    if (mysqli_num_rows($result) > 0) {
                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            // Decrypt the necessary fields
                                                            $program = decryptData($row['program_name']) . " " . decryptData($row['level']);
                                                            $trainer = decryptData($row['first_name']) . ' ' . decryptData($row['last_name']);
                                                            $dateSpan = htmlspecialchars($row['date_span']);
                                                            $batch = htmlspecialchars($row['batch_no']);

                                                            // Restore button
                                                            $action = '<a href="restore_schedule.php?schedule_id=' . $row['schedule_id'] . '" 
                                                                        class="btn btn-primary">
                                                                        <i class="fa fa-undo" style:"color: green; font-size: 15px;"></i> 
                                                                    </a>';

                                                            // Display row
                                                            echo "
                                                            <tr>
                                                                <td>{$count}</td>
                                                                <td>{$batch}</td>
                                                                <td>{$program}</td>
                                                                <td>{$dateSpan}</td>
                                                                <td>{$trainer}</td>
                                                                <td>{$action}</td>
                                                            </tr>";
                                                            $count++;
                                                        }
                                                    } 
                                                    ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                    <th>#</th>
                                                        <th>Batch</th>
                                                        <th>Program</th>
                                                        <th>Date</th>
                                                        <th>Trainer</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="Scholarship" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="scholarshipTable" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Scholarship Name</th>
                                                        <th>Amount</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    // Query to fetch deleted scholarships
                                                    $sql = "SELECT * FROM scholarships WHERE is_deleted = 1";
                                                    $result = mysqli_query($conn, $sql);

                                                    // Error handling
                                                    if (!$result) {
                                                        echo '<tr><td colspan="4">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                        exit;
                                                    }

                                                    $count = 1;

                                                    // If scholarships are found, display them
                                                    if (mysqli_num_rows($result) > 0) {
                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            // Decrypt the scholarship name and amount
                                                            $name = decryptData($row['scholarship_name']);
                                                            $amount = decryptData($row['amount']);

                                                            // Restore button
                                                            $action = '<a href="restore_scholarship.php?scholarship_id=' . $row['scholarship_id'] . '" 
                                                                        <i class="fa fa-undo" style:"color: green; font-size: 15px;"></i>
                                                                    </a>';

                                                            // Display row
                                                            echo "
                                                            <tr>
                                                                <td>{$count}</td>
                                                                <td>{$name}</td>
                                                                <td>{$amount}</td>
                                                                <td>{$action}</td>
                                                            </tr>";
                                                            $count++;
                                                        }
                                                    } 
                                                    ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Scholarship Name</th>
                                                        <th>Amount</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>

<script>
    $(document).ready(function () {
    $('#registeredTable, #enrolledTable, #assessmentTable, #programTable, #trainorTable, #scheduleTable, #scholarshipTable').DataTable({
        scrollY: "42vh",
        scrollCollapse: true,
        paging: false,
        autoWidth: false, 
        responsive: true,  
        createdRow: function (row, data, index) {
            $(row).addClass('selected');
        }
    }).columns.adjust().draw(); 

    $(window).on('resize', function () {
        $('#registeredTable, #enrolledTable, #assessmentTable, #programTable, #trainorTable, #scheduleTable, #scholarshipTable')
            .DataTable().columns.adjust();
    });
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
    });
});
</script>
</body>

</html>