<div class="modal fade" id="editTrainorModal" tabindex="-1" aria-labelledby="editTrainorModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="manage_trainer.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editTrainorModalLabel">Edit Trainor</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <input type="hidden" name="trainor_id" id="edit_trainor_id">
                    <div class="form-group">
                        <label for="edit_first_name">First Name</label>
                        <input type="text" class="form-control" name="first_name" id="edit_first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_middle_name">Middle Name</label>
                        <input type="text" class="form-control" name="middle_name" id="edit_middle_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_last_name">Last Name</label>
                        <input type="text" class="form-control" name="last_name" id="edit_last_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_phone_number">Phone Number</label>
                        <input type="text" class="form-control" name="phone_number" id="edit_phone_number" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_email">Email</label>
                        <input type="text" class="form-control" name="email" id="edit_email" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_tesda_accreditation_number">TESDA Accreditation Number</label>
                        <input type="text" class="form-control" name="tesda_accreditation_number" id="edit_tesda_accreditation_number" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_expertise">Expertise</label>
                        <input type="text" class="form-control" name="expertise" id="edit_expertise" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="editTrainor" class="btn btn-primary">Update Trainor</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
    $('#editTrainorModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget); 
        const trainor_id = button.data('id');
        const first_name = button.data('firstname');
        const middle_name = button.data('middlename');
        const last_name = button.data('lastname');
        const phone_number = button.data('number');
        const email = button.data('email');
        const tesda_accreditation_number = button.data('accreditation');
        const expertise = button.data('expertise');

        const modal = $(this);
        modal.find('#edit_trainor_id').val(trainor_id);
        modal.find('#edit_first_name').val(first_name);
        modal.find('#edit_middle_name').val(middle_name);
        modal.find('#edit_last_name').val(last_name);
        modal.find('#edit_phone_number').val(phone_number);
        modal.find('#edit_email').val(email);
        modal.find('#edit_tesda_accreditation_number').val(tesda_accreditation_number);
        modal.find('#edit_expertise').val(expertise);
    });
});

</script>
