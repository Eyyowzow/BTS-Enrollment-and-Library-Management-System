<!-- Program Modal --> 
<div class="modal fade" id="editProgramModal" tabindex="-1" aria-labelledby="editProgramModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="manage_programs.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProgramModalLabel">Edit Program</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="program_id" id="edit_program_id">
                    <div class="form-group">
                        <label for="edit_program_code">Program Code</label>
                        <input type="text" class="form-control" name="program_code" id="edit_program_code" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_program_name">Program Name</label>
                        <input type="text" class="form-control" name="program_name" id="edit_program_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_program_level">Level</label>
                        <input type="text" class="form-control" name="level" id="edit_program_level" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_program_description">Description</label>
                        <textarea class="form-control" name="description" id="edit_program_description" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="editProgram" class="btn btn-primary">Update Program</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
    $('#editProgramModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget); 
        const programId = button.data('id');
        const programCode = button.data('code');
        const programName = button.data('name');
        const level = button.data('level');
        const description = button.data('description');

        const modal = $(this);
        modal.find('#edit_program_id').val(programId);
        modal.find('#edit_program_code').val(programCode);
        modal.find('#edit_program_name').val(programName);
        modal.find('#edit_program_level').val(level);
        modal.find('#edit_program_description').val(description);
    });
});

</script>
