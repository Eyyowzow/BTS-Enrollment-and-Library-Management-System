<?php
include '../Database/Database.php';
include 'encryption.php';

if (isset($_POST['query'])) {
    $query = $_POST['query'];

    $sql = "SELECT student_id, ULI, first_name, last_name 
            FROM students 
            WHERE (ULI LIKE ? OR CONCAT(first_name, ' ', last_name) LIKE ?)
            AND is_deleted = 0";

    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $query . "%";
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    $output = '';
    while ($row = $result->fetch_assoc()) {
        $ULI = decryptData($row['ULI']);
        $firstName = decryptData($row['first_name']);
        $lastName = decryptData($row['last_name']);

        $studentName = $firstName . ' ' . $lastName;

        $output .= '<li data-id="' . $row['student_id'] . '" data-uli="' . decryptData($row['ULI']) . '">'
        . decryptData($row['ULI']) . ' - ' . $studentName . '</li>';
  }

    echo $output ? $output : '<li>No results found</li>';
}
?>
