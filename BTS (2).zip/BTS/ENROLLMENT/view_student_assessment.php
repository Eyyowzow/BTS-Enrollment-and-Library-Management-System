<!-- View Enrollment Modal -->
<div class="modal fade" id="viewEnrollmentAssessmentModal" tabindex="-1" role="dialog" aria-labelledby="viewEnrollmentLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="viewEnrollmentLabel">Enrollment Details</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>ULI:</strong> <span id="viewUli"></span></p>
                                                <p><strong>Student Name:</strong> <span id="viewStudentName"></span></p>
                                                <p><strong>Assessment Name:</strong> <span id="viewAssessmentName"></span></p>
                                                <p><strong>Assessor:</strong> <span id="viewAssessor"></span></p>
                                                <p><strong>Location:</strong> <span id="viewLocation"></span></p>
                                                <p><strong>Educational Attainment:</strong> <span id="viewEducationalAttainment"></span></p>
                                                <p><strong>employment Before Training:</strong> <span id="viewEmployment"></span></p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script>
        document.addEventListener('DOMContentLoaded', function () {
            const viewButtons = document.querySelectorAll('.view-btn');

            viewButtons.forEach(btn => {
                btn.addEventListener('click', function () {
                    document.getElementById('viewUli').textContent = this.dataset.uli;
                    document.getElementById('viewStudentName').textContent = this.dataset.studentName;
                    document.getElementById('viewAssessmentName').textContent = this.dataset.assessment;
                    document.getElementById('viewAssessor').textContent = this.dataset.assessor;
                    document.getElementById('viewLocation').textContent = this.dataset.location;
                    document.getElementById('viewEducationalAttainment').textContent = this.dataset.education;
                    document.getElementById('viewEmployment').textContent = this.dataset.employment;
                    document.getElementById('viewStatus').textContent = this.dataset.status;
                });
            });
        });
    </script>