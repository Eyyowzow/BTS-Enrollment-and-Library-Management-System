<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$success_message = '';
$error_message = '';

if (isset($_POST['addSchedule'])) {
    $program_id = isset($_POST['program']) ? $_POST['program'] : '';
    $trainor_id = isset($_POST['trainor']) ? $_POST['trainor'] : '';
    $batch_no = isset($_POST['batch_no']) ? $_POST['batch_no'] : '';
    $starts_date = isset($_POST['starts_date']) ? $_POST['starts_date'] : '';
    $end_date = isset($_POST['end_date']) ? $_POST['end_date'] : '';
    $days = isset($_POST['days']) ? $_POST['days'] : '';

    // Insert schedule into the database
    $sql = "INSERT INTO schedules (program_id, batch_no, starts_date, end_date, days, trainor_id) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("issssi", $program_id, $batch_no, $starts_date, $end_date, $days, $trainor_id);

        if ($stmt->execute()) {
            $success_message = 'Schedule Added Successfully!';
        } else {
            $error_message = 'Error Adding Schedule!';
        }
        $stmt->close();
    } else {
        $error_message = 'Failed to prepare SQL statement!';
    }
}


if (isset($_POST['editSchedule'])) {
    $scheduleId = $_POST['schedule_id'];
    $programId = $_POST['program'];
    $trainorId = $_POST['trainor'];
    $batchNo = $_POST['batch_no'];
    $startDate = $_POST['starts_date'];
    $endDate = $_POST['end_date'];
    $days = $_POST['days'];

    $updateQuery = "UPDATE schedules SET program_id = ?, trainor_id = ?, batch_no = ?, starts_date = ?, end_date = ?, days = ? WHERE schedule_id = ?";
    $stmt = $conn->prepare($updateQuery);

    if ($stmt) {
        $stmt->bind_param("iissssi", $programId, $trainorId, $batchNo, $startDate, $endDate, $days, $scheduleId);
        if ($stmt->execute()) {
            $success_message = 'Schedule Updated Successfully!';
        } else {
            $error_message = 'Error Updating Schedule!';
        }
        $stmt->close();
    } else {
        echo "<script>alert('Database error: " . $conn->error . "');</script>";
    }
}
// Fetch programs and trainers for dropdowns

$programs = $conn->query("SELECT program_id, program_name, level, CONCAT(program_name, ' ', level) as tesda_program FROM programs WHERE is_deleted=0");
$trainors = $conn->query("SELECT trainor_id, first_name, last_name, expertise, CONCAT(first_name, ' ', last_name) as trainor_name FROM trainors WHERE is_deleted=0");
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
</head>

<body>
       <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Schedule Masterlist</h4>
                            <span class="ml-1">Data Entry</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Add New Program Button -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addScheduleModal">Add New Schedule
                                </button>
                        </ol>
                    </div>
                </div>
                <?php if ($success_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-account-search"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class='alert alert-danger'><?php echo $error_message; ?></div>
                <?php endif; ?>
                <!-- row -->

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Batch</th>
                                                <th>Program</th>
                                                <th>Date</th>
                                                <th>Trainer</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $schedule_query = "
                                        SELECT s.schedule_id, 
                                               s.program_id, 
                                               s.trainor_id, p.program_name, p.level, t.first_name, t.last_name, 
                                               CONCAT(p.program_name, ' ', level) as tesda_program,
                                               CONCAT(s.starts_date, ' - ', s.end_date) as date_span,
                                               s.batch_no, s.starts_date, s.end_date, s.days, 
                                               CONCAT(t.first_name, ' ', t.last_name) as trainor_name
                                        FROM schedules s 
                                        JOIN programs p ON s.program_id = p.program_id
                                        JOIN trainors t ON s.trainor_id = t.trainor_id
                                        WHERE s.is_deleted = 0";
                                        $count = 1;
                                        $schedule_result = $conn->query($schedule_query);
                                        if (!$schedule_result) {
                                            echo "<div class='alert alert-danger'>Error fetching schedules: " . $conn->error . "</div>";
                                            exit; 
                                        }
                                        if ($schedule_result->num_rows > 0) {
                                            while ($row = $schedule_result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $count++ . "</td>";
                                                echo "<td>" . htmlspecialchars($row['batch_no']) . "</td>";
                                                echo "<td>" . decryptData($row['program_name']) . " " . decryptData($row['level']) . "</td>";
                                                echo "<td>" . htmlspecialchars($row['date_span']) . "</td>";
                                                echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) ."</td>";
                                                echo "<td>
                                                    <span>
                                                    <a href='edit_schedule.php' class='edit-btn'
                                                    data-id='{$row['schedule_id']}' 
                                                    data-program='{$row['program_id']}' 
                                                    data-trainor='{$row['trainor_id']}' 
                                                    data-batch='{$row['batch_no']}' 
                                                    data-start='{$row['starts_date']}' 
                                                    data-end='{$row['end_date']}' 
                                                    data-days='{$row['days']}'
                                                    data-toggle='modal' data-target='#editScheduleModal' >
                                                        <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->

                                                    <a href='view_schedule.php' class='view-btn' 
                                                    data-id='{$row['schedule_id']}'
                                                    data-program='{$row['program_id']}' 
                                                    data-trainor='{$row['trainor_id']}' 
                                                    data-batch='{$row['batch_no']}' 
                                                    data-start='{$row['starts_date']}' 
                                                    data-end='{$row['end_date']}' 
                                                    data-days='{$row['days']}'
                                                    data-toggle='modal' data-target='#viewScheduleModal'>
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>


                                                    <a href='delete_schedule.php?schedule_id={$row['schedule_id']}' 
                                                        data-toggle='tooltip' data-placement='top' title='Delete' 
                                                        onclick=\"return confirm('Are you sure you want to delete this schedule?')\">
                                                        <i class='fa fa-trash' style='color: red; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>
                                                    </span>
                                                    </td>";
                                                    echo "</tr>";
                                                }
                                            }
                                        
                                            
                                        
                                            ?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>Batch</th>
                                                <th>Program</th>
                                                <th>Date</th>
                                                <th>Trainer</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                <div class="modal fade" id="addScheduleModal" tabindex="-1" aria-labelledby="addScheduleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                        <input type="hidden" name="schedule_id" value="<?php echo $schedule_id; ?>" />
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="addScheduleModalLabel">Add New Schedule</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form id="addScheduleForm" method="POST" action="manage_schedules.php">
                                            <!-- Program Input -->
                                            <div class="mb-6">
                                                <label for="program" class="form-label">Program</label>
                                                <select class="form-control" id="program" name="program" required>
                                                    <option value="">Select Program</option>
                                                    <?php while ($row = $programs->fetch_assoc()): ?>
                                                                <option value="<?php echo $row['program_id']; ?>">
                                                                    <?php echo decryptData($row['program_name']) . " " . decryptData($row['level']); ?>
                                                                </option>
                                                            <?php endwhile; ?>
                                                </select>
                                            </div>

                                            <!-- Trainer Input -->
                                            <div class="mb-3">
                                                <label for="trainor" class="form-label">Trainer</label>
                                                <select class="form-control" id="trainor" name="trainor" required>
                                                    <option value="">Select Trainer</option>
                                                    <?php while ($row = $trainors->fetch_assoc()): ?>
                                                                <option value="<?php echo $row['trainor_id']; ?>">
                                                                    <?php echo decryptData($row['first_name']) . " " . decryptData($row['last_name']) . " " . "(" . decryptData($row['expertise']) . ")"; ?>
                                                                </option>
                                                            <?php endwhile; ?>
                                                </select>
                                            </div>

                                            <!-- Batch Number -->
                                            <div class="mb-3">
                                                <label for="batch_no" class="form-label">Batch Number</label>
                                                <input type="text" class="form-control" id="batch_no" name="batch_no" required>
                                            </div>
                                            <!-- Start Date Input -->
                                            <div class="mb-3">
                                                <label for="starts_date" class="form-label">Start Date</label>
                                                <input type="date" class="form-control" id="starts_date" name="starts_date" required>
                                            </div>

                                            <!-- End Date Input -->
                                            <div class="mb-3">
                                                <label for="end_date" class="form-label">End Date</label>
                                                <input type="date" class="form-control" id="end_date" name="end_date" required>
                                            </div>

                                            <!-- Days Input -->
                                            <div class="mb-3">
                                                <label for="days" class="form-label">Days</label>
                                                <input type="number" class="form-control" id="days" name="days" readonly>
                                            </div>

                                            <div class="modal-footer">
                                                <button type="submit" name="addSchedule" class="btn btn-primary">Add Schedule</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>

<!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    

    <script>
        const today = new Date().toISOString().split('T')[0];

        document.getElementById('starts_date').setAttribute('min', today);
        document.getElementById('end_date').setAttribute('min', today);

        const startDateInput = document.getElementById('starts_date');
        const endDateInput = document.getElementById('end_date');
        const daysInput = document.getElementById('days');

        function calculateDays() {
            const startDate = new Date(startDateInput.value);
            const endDate = new Date(endDateInput.value);

            if (startDate && endDate && endDate >= startDate) {
                const differenceInTime = endDate - startDate;
                const days = differenceInTime / (1000 * 60 * 60 * 24) + 1; 
                daysInput.value = days;
            } else {
                daysInput.value = ''; 
            }
        }

        startDateInput.addEventListener('change', calculateDays);
        endDateInput.addEventListener('change', calculateDays);
    </script>
    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 5000); 
        }
    };
    </script>
</body>
</html>

<?php
include 'edit_schedule.php';
include 'view_schedule.php';
?>