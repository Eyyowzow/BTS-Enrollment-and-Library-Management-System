<?php 
session_start();

include 'header.php';
include 'sidebar.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
} 
$alert_message = '';
if (isset($_SESSION['alert_message'])) {
    $alert_message = $_SESSION['alert_message'];
    unset($_SESSION['alert_message']); 
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    if (isset($_POST['toggle_status'])) {
        $enrollment_id = $_POST['enrollment_id'];
        $current_status = $_POST['current_status'];
        $new_status = ($current_status == 'passed') ? 'failed' : 'passed';

        $stmt = $conn->prepare("UPDATE enrollments SET student_status = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("si", $new_status, $enrollment_id);
            if ($stmt->execute()) {
                $_SESSION['alert_message'] = "Status updated successfully to " . ucfirst($current_status) . ".";
            } else {
                $_SESSION['alert_message'] = "Error updating status: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['alert_message'] = "Error preparing statement: " . $conn->error;
        }
        
    } else {
        $student_id = $_POST['student_name'];
        $checkStudentStmt = $conn->prepare("SELECT student_id FROM students WHERE student_id = ?");
        $checkStudentStmt->bind_param("i", $student_id);
        $checkStudentStmt->execute();
        $checkResult = $checkStudentStmt->get_result();

        if ($checkResult->num_rows > 0) {
            $program_id = $_POST['program'];
            $trainor_id = $_POST['trainor']; 
            $schedule_id = $_POST['date']; 
            $scholarship_id = $_POST['scholarship'];
            $educational_attainment = $_POST['educational_attainment'];
            $student_status = 'passed';

        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
</head>

<body>
    
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Student Record</h4>
                            <span class="ml-1">Record and Reports</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Add New Student Button -->
                        </ol>
                    </div>
                </div>
                <?php if ($alert_message): ?>
                        <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                            <span><i class="mdi mdi-account-search"></i></span>
                            <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                                <span><i class="mdi mdi-close"></i></span>
                            </button> 
                            <?php echo $alert_message; ?>
                        </div>
                    <?php endif; ?>
                <!-- row -->
                 

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $sql = "SELECT e.id,
                                                s.ULI,
                                                s.first_name,
                                                s.last_name, 
                                                CONCAT(p.program_name, ' ', p.level) AS tesda_program, 
                                                CONCAT(t.first_name, ' ', t.last_name) AS trainor_name, 
                                                sched.batch_no,
                                                CONCAT(sched.starts_date, ' - ', sched.end_date) AS date_span, 
                                                sch.scholarship_name, 
                                                e.student_status 
                                            FROM enrollments e
                                            JOIN students s ON e.student_id = s.student_id
                                            JOIN programs p ON e.program_id = p.program_id
                                            JOIN trainors t ON e.trainor_id = t.trainor_id
                                            JOIN schedules sched ON e.schedule_id = sched.schedule_id
                                            JOIN scholarships sch ON e.scholarship_id = sch.scholarship_id
                                            
                                        ";
                                        $result = mysqli_query($conn, $sql);
                                        $count = 1;
                                        if (!$result) {
                                            echo "Error executing query: " . mysqli_error($conn);
                                            exit;
                                        }
                                        
                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo "<tr>";
                                                echo "<td>" . $count++ . "</td>";
                                                echo "<td>" . decryptData($row['ULI']) . "</td>";
                                                echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</td>"; 
                                                echo "<td>
                                                    <form method='POST' action=''>
                                                        <input type='hidden' name='enrollment_id' value='" . htmlspecialchars($row['id']) . "'>
                                                        <input type='hidden' name='current_status' value='" . htmlspecialchars($row['student_status']) . "'>
                                                        <button type='submit' name='toggle_status' class='btn btn-text' style='color: #414152;'>
                                                            " . htmlspecialchars(ucfirst($row['student_status'])) . "
                                                        </button>
                                                    </form>
                                                </td>";
                                                echo "<td>
                                                        <a href='view_enrollment.php?id=" . $row['id'] . "' class='mr-2' ;'>
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                                                        </a>
                                                    </td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    


    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>

    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 3000); 
        }
    };
</script>

</body>

</html>

