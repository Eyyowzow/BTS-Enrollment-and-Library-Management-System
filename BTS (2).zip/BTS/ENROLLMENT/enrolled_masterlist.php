<?php  
session_start();
include 'header.php';
include 'sidebar.php';

$alert_message = '';

if (isset($_SESSION['alert_message'])) {
    $alert_message = $_SESSION['alert_message'];
    unset($_SESSION['alert_message']); 
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    if (isset($_POST['toggle_status'])) {
        // Toggle student status code (unchanged)
        $enrollment_id = $_POST['enrollment_id'];
        $current_status = $_POST['current_status'];
        $new_status = ($current_status == 'enrolled') ? 'dropped' : 'enrolled';

        $stmt = $conn->prepare("UPDATE enrollments SET student_status = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("si", $new_status, $enrollment_id);
            if ($stmt->execute()) {
                $_SESSION['alert_message'] = "Status updated successfully to " . ucfirst($new_status) . ".";
            } else {
                $_SESSION['alert_message'] = "Error updating status: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['alert_message'] = "Error preparing statement: " . $conn->error;
        }
    } else {
        // Edit or Add enrollment record
        $student_id = $_POST['student'];
        $program_id = $_POST['program'];
        $trainor_id = $_POST['trainor']; 
        $schedule_id = $_POST['date']; 
        $educational_attainment = $_POST['educational_attainment'];
        $scholarship_id = !empty($_POST['scholarship']) ? $_POST['scholarship'] : null;

        if (isset($_POST['enrollment_id']) && !empty($_POST['enrollment_id'])) {
            // Edit existing enrollment
            $enrollment_id = $_POST['enrollment_id'];
            $query = "UPDATE enrollments SET student_id = ?, program_id = ?, trainor_id = ?, schedule_id = ?, educational_attainment = ?, scholarship_id = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            if ($scholarship_id !== null) {
                $stmt->bind_param("iiiissi", $student_id, $program_id, $trainor_id, $schedule_id, $educational_attainment, $scholarship_id, $enrollment_id);
            } else {
                $stmt->bind_param("iiiissi", $student_id, $program_id, $trainor_id, $schedule_id, $educational_attainment, null, $enrollment_id);
            }

            if ($stmt && $stmt->execute()) {
                $_SESSION['alert_message'] = "Enrollment successfully updated.";
            } else {
                $_SESSION['alert_message'] = "Error updating enrollment: " . $stmt->error;
            }
            $stmt->close();
        } else {
            // Add new enrollment
            $student_status = 'enrolled';
            if ($scholarship_id !== null) {
                $stmt = $conn->prepare("
                    INSERT INTO enrollments 
                    (student_id, program_id, trainor_id, schedule_id, educational_attainment, scholarship_id, student_status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("iiiisss", $student_id, $program_id, $trainor_id, $schedule_id, $educational_attainment, $scholarship_id, $student_status);
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO enrollments 
                    (student_id, program_id, trainor_id, schedule_id, educational_attainment, student_status) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("iiiiss", $student_id, $program_id, $trainor_id, $schedule_id, $educational_attainment, $student_status);
            }

            if ($stmt && $stmt->execute()) {
                $_SESSION['alert_message'] = "Enrollment successfully added.";
            } else {
                $_SESSION['alert_message'] = "Error adding enrollment: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
</head>

<body>
    
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Enrolled Masterlist</h4>
                            <span class="ml-1">Data Entry</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Add New Student Button -->
                                <a href="enroll_student.php"><button type="button" class="btn btn-primary">Enroll Student</button></a>
                        </ol>
                    </div>
                </div>
                <?php if ($alert_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-check"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $alert_message; ?>
                    </div>
                <?php endif; ?>
                <!-- row -->
                 

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student</th>
                                                <th>Batch</th>
                                                <th>Scholarship</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $sql = "
                                            SELECT e.id,
                                                e.educational_attainment,
                                                s.ULI,
                                                s.first_name AS student_first_name, s.last_name AS student_last_name, 
                                                p.program_name, p.level,
                                                t.first_name AS t_first_name, t.last_name AS t_last_name,
                                                CONCAT(p.program_name, ' ', p.level) AS tesda_program, 
                                                CONCAT(t.first_name, ' ', t.last_name) AS trainor_name,
                                                sched.batch_no, sched.starts_date, sched.end_date, sched.days,
                                                CONCAT(sched.starts_date, ' - ', sched.end_date) AS date_span, 
                                                sch.scholarship_name, e.employment,
                                                e.student_status 
                                            FROM enrollments e
                                            JOIN students s ON e.student_id = s.student_id
                                            JOIN programs p ON e.program_id = p.program_id
                                            JOIN trainors t ON e.trainor_id = t.trainor_id
                                            JOIN schedules sched ON e.schedule_id = sched.schedule_id
                                            LEFT JOIN scholarships sch ON e.scholarship_id = sch.scholarship_id
                                            WHERE e.is_deleted=0
                                        ";
                                        $result = mysqli_query($conn, $sql);
                                        $count = 1;
                                        if (!$result) {
                                            echo "Error executing query: " . mysqli_error($conn);
                                            exit;
                                        }
                                        
                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo "<tr>";
                                                echo "<td>" . $count++ . "</td>";
                                                echo "<td>" . decryptData($row['ULI']) . "</td>"; 
                                                echo "<td>" . decryptData($row['student_first_name']) . " " . decryptData($row['student_last_name']) . "</td>"; 
                                                echo "<td>" . $row['batch_no'] . "</td>";
                                                echo "<td>" . (!empty($row['scholarship_name']) ? decryptData($row['scholarship_name']) : 'N/A') . "</td>";
                                                echo "<td>
                                                    <form method='POST' action=''>
                                                        <input type='hidden' name='enrollment_id' value='" . htmlspecialchars($row['id']) . "'>
                                                        <input type='hidden' name='current_status' value='" . htmlspecialchars($row['student_status']) . "'>
                                                        <button type='submit' name='toggle_status' class='btn btn-text' style='color: #414152;'>
                                                            " . htmlspecialchars(ucfirst($row['student_status'])) . "
                                                        </button>
                                                    </form>
                                                </td>";
                                                echo "<td>
                                                       <a href='edit_enrollment.php' class='edit-btn' 
                                                        data-id='{$row['id']}' 
                                                        data-student='" . decryptData($row['student_first_name']) . " " . decryptData($row['student_last_name']) . "' 
                                                        data-educational_attainment='" . htmlspecialchars($row['educational_attainment']) . "' 
                                                        data-employment='" . htmlspecialchars($row['employment']) . "' 
                                                        data-scholarship='" . decryptData($row['scholarship_name']) . "' 
                                                        data-batch_no='" . htmlspecialchars($row['batch_no']) . "'  
                                                        data-program='" . decryptData($row['program_name']) . " " . decryptData($row['level']) . "' 
                                                        data-trainor='" . decryptData($row['t_first_name']) . " " . decryptData($row['t_last_name']) . "'
                                                        data-date='" . htmlspecialchars($row['date_span']) . "' 
                                                        data-days='" . htmlspecialchars($row['days']) . "'  
                                                        data-toggle='modal' data-target='#editEnrollmentModal'>
                                                        <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                        </a>


                                                        <a href='#' class='view-btn' 
                                                            data-id='" . htmlspecialchars($row['id']) . "' 
                                                            data-uli='" . decryptData($row['ULI']) . "' 
                                                            data-student-name='" . decryptData($row['student_first_name']) . " " . decryptData($row['student_last_name']) . "' 
                                                            data-education='" . htmlspecialchars($row['educational_attainment']) . "'
                                                            data-employment='" . decryptData($row['employment']) . "'
                                                            data-batch='" . htmlspecialchars($row['batch_no']) . "' 
                                                            data-program='" . decryptData($row['program_name']) . " - " . decryptData($row['level']) . "' 
                                                            data-trainor='" . decryptData($row['t_first_name']) . " " . decryptData($row['t_last_name']) . "' 
                                                            data-scholarship='" . decryptData($row['scholarship_name']) . "' 
                                                            data-schedule='" . htmlspecialchars($row['date_span']) . "' 
                                                            data-status='" . decryptData($row['student_status']) . "' 
                                                            data-toggle='modal' data-target='#viewEnrollmentModal'>
                                                                <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> 
                                                        </a>
                                                        <a href='delete_enrollment.php?id=" . $row['id'] . "' 
                                                            onclick='return confirm(\"Are you sure you want to delete this enrollment?\");'>
                                                            <i class='fa fa-trash' style='color: red; font-size: 15px;'></i>
                                                        </a>
                                                    </td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student</th>
                                                <th>Batch</th>
                                                <th>Scholarship</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                <!-- View Enrollment Modal -->
                                <div class="modal fade" id="viewEnrollmentModal" tabindex="-1" role="dialog" aria-labelledby="viewEnrollmentLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="viewEnrollmentLabel">Enrollment Details</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>ULI:</strong> <span id="viewUli"></span></p>
                                                <p><strong>Student Name:</strong> <span id="viewStudentName"></span></p>
                                                <p><strong>Educational Attainment:</strong> <span id="viewEducation"></span></p>
                                                <p><strong>Employment:</strong> <span id="viewEmployment"></span></p>
                                                <p><strong>Batch:</strong> <span id="viewBatch"></span></p>
                                                <p><strong>Program:</strong> <span id="viewProgram"></span></p>
                                                <p><strong>Trainer:</strong> <span id="viewTrainorName"></span></p>
                                                <p><strong>Scholarship:</strong> <span id="viewScholarship"></span></p>
                                                <p><strong>Schedule:</strong> <span id="viewSchedule"></span></p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    


    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>

    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 3000); 
        }
    };
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const viewButtons = document.querySelectorAll('.view-btn');

            viewButtons.forEach(btn => {
                btn.addEventListener('click', function () {
                    document.getElementById('viewUli').textContent = this.dataset.uli;
                    document.getElementById('viewStudentName').textContent = this.dataset.studentName;
                    document.getElementById('viewEducation').textContent = this.dataset.education;
                    document.getElementById('viewEmployment').textContent = this.dataset.employment;
                    document.getElementById('viewBatch').textContent = this.dataset.batch;
                    document.getElementById('viewProgram').textContent = this.dataset.program;
                    document.getElementById('viewTrainorName').textContent = this.dataset.trainor;
                    document.getElementById('viewScholarship').textContent = this.dataset.scholarship;
                    document.getElementById('viewSchedule').textContent = this.dataset.schedule;
                    document.getElementById('viewStatus').textContent = this.dataset.status;
                });
            });
        });
    </script>
</body>
</html>
<?php
include 'edit_enrollment.php';
?>