<?php
include '../Database/Database.php';

if (isset($_GET['program_id'])) {
    $program_id = $_GET['program_id'];
    
    $sql = "UPDATE programs SET is_deleted = 0 WHERE program_id = $program_id";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Program deleted successfully');</script>";
        header("Location: backup_restore.php");

    } else {
        echo "Error hiding student: " . mysqli_error($conn);
    }
}
?>
