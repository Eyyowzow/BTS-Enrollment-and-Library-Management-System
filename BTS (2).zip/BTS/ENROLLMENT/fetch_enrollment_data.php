<?php
include '../Database/Database.php';
include 'encryption.php';

$query = "
    SELECT 
        YEAR(enrollment_date) AS year, 
        COUNT(CASE WHEN student_status = 'fail' THEN 1 END) AS dropped, 
        COUNT(CASE WHEN student_status = 'pass' THEN 1 END) AS enrolled
    FROM enrollments
    GROUP BY YEAR(enrollment_date)
    ORDER BY year ASC;
";

$result = mysqli_query($conn, $query);

$data = array();

while ($row = mysqli_fetch_assoc($result)) {
    $data[] = array(
        'year' => $row['year'],
        'dropped' => (int) $row['dropped'], 
        'enrolled' => (int) $row['enrolled'] 
    );
}

echo json_encode($data);
?>
