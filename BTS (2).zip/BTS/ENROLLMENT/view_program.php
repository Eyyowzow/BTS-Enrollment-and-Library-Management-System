
<!-- Program Modal --> 
<div class="modal fade" id="viewProgramModal" tabindex="-1" aria-labelledby="viewProgramModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="viewModalLabel">Program Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="program_id" id="edit_program_id">
                    <p><strong>Program Code:</strong> <span id="viewCode"></span></p>
                    <p><strong>Program Name:</strong> <span id="viewName"></span></p>
                    <p><strong>Level:</strong> <span id="viewLevel"></span></p>
                    <p><strong>Description:</strong> <span id="viewDescription"></span></p>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const viewButtons = document.querySelectorAll('.view-btn');

        viewButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                document.getElementById('viewCode').textContent = this.getAttribute('data-program_code');
                document.getElementById('viewName').textContent = this.getAttribute('data-program_name');
                document.getElementById('viewLevel').textContent = this.getAttribute('data-level');
                document.getElementById('viewDescription').textContent = this.getAttribute('data-description');
            });
        });
    });
    </script>