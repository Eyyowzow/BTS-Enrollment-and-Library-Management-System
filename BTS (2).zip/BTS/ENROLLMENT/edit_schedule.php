<?php
include '../Database/Database.php';


// Fetch programs and trainers for dropdown
$programs = $conn->query("SELECT program_id, program_name, level, CONCAT(program_name, ' ', level) as tesda_program FROM programs");
$trainors = $conn->query("SELECT trainor_id, first_name, last_name, CONCAT(first_name, ' ', last_name) as trainor_name FROM trainors");
?>

<div class="modal fade" id="editScheduleModal" tabindex="-1" aria-labelledby="editScheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <form id="editScheduleForm" method="POST" action="manage_schedules.php">

            <div class="modal-header">
                <h5 class="modal-title" id="editScheduleModalLabel">Edit Schedule</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <input type="hidden" name="schedule_id" id="edit_schedule_id" />

                    <!-- Program Selection -->
                    <div class="mb-3">
                        <label for="edit_program" class="form-label">Program</label>
                        <select class="form-control" id="edit_program" name="program" required>
                            <option value="">Select Program</option>
                            <?php while ($row = $programs->fetch_assoc()): ?>
                                <option value="<?php echo $row['program_id']; ?>">
                                    <?php echo decryptData($row['program_name']) . " " . decryptData($row['level']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <!-- Trainer Selection -->
                    <div class="mb-3">
                        <label for="edit_trainor" class="form-label">Trainor</label>
                        <select class="form-control" id="edit_trainor" name="trainor" required>
                            <option value="">Select Trainor</option>
                            <?php while ($row = $trainors->fetch_assoc()): ?>
                                <option value="<?php echo $row['trainor_id']; ?>">
                                    <?php echo decryptData($row['first_name']) . " " . decryptData($row['last_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Other Input Fields -->
                    <div class="mb-3">
                        <label for="edit_batch_no" class="form-label">Batch Number</label>
                        <input type="text" class="form-control" id="edit_batch_no" name="batch_no" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_starts_date" class="form-label">Start Date</label>
                        <input type="date" class="form-control" id="edit_starts_date" name="starts_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_end_date" class="form-label">End Date</label>
                        <input type="date" class="form-control" id="edit_end_date" name="end_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_days" class="form-label">Days</label>
                        <input type="text" class="form-control" id="edit_days" name="days" required>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" name="editSchedule" class="btn btn-primary">Update Schedule</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
        const today = new Date().toISOString().split('T')[0];

        document.getElementById('edit_starts_date').setAttribute('min', today);
        document.getElementById('edit_end_date').setAttribute('min', today);

        const startDateInput = document.getElementById('edit_starts_date');
        const endDateInput = document.getElementById('edit_end_date');
        const daysInput = document.getElementById('edit_days');

        function calculateDays() {
            const startDate = new Date(startDateInput.value);
            const endDate = new Date(endDateInput.value);

            if (startDate && endDate && endDate >= startDate) {
                const differenceInTime = endDate - startDate;
                const days = differenceInTime / (1000 * 60 * 60 * 24) + 1; 
                daysInput.value = days;
            } else {
                daysInput.value = ''; 
            }
        }

        startDateInput.addEventListener('change', calculateDays);
        endDateInput.addEventListener('change', calculateDays);
    </script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const editButtons = document.querySelectorAll('.edit-btn');
        
        editButtons.forEach(button => {
            button.addEventListener('click', function () {
                const scheduleId = this.getAttribute('data-id');
                const program = this.getAttribute('data-program');
                const trainor = this.getAttribute('data-trainor');
                const batch = this.getAttribute('data-batch');
                const startDate = this.getAttribute('data-start');
                const endDate = this.getAttribute('data-end');
                const days = this.getAttribute('data-days');
                
                document.getElementById('edit_schedule_id').value = scheduleId;
                document.getElementById('edit_program').value = program;
                document.getElementById('edit_trainor').value = trainor;
                document.getElementById('edit_batch_no').value = batch;
                document.getElementById('edit_starts_date').value = startDate;
                document.getElementById('edit_end_date').value = endDate;
                document.getElementById('edit_days').value = days;
            });
        });
    });
</script>
