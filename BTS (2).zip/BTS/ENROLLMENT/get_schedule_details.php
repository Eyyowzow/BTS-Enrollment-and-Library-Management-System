<?php
include '../Database/Database.php';
include 'encryption.php';

if (isset($_POST['trainor_id']) && isset($_POST['batch_no']) && isset($_POST['program_id'])) {
    $trainor_id = $_POST['trainor_id'];
    $batch_no = $_POST['batch_no'];
    $program_id = $_POST['program_id'];

    $schedule_query = "
        SELECT schedule_id, starts_date, end_date,
               CONCAT(starts_date, ' - ', end_date) AS date_span,
               days
        FROM schedules 
        WHERE trainor_id = '$trainor_id' 
          AND batch_no = '$batch_no'
          AND program_id = '$program_id'
          AND is_deleted = 0;
    ";

    $result = $conn->query($schedule_query);

    if ($result->num_rows > 0) {
        $scheduleData = $result->fetch_assoc();

        $response = array(
            'dates' => '<option value="' . $scheduleData['schedule_id'] . '">' . htmlspecialchars($scheduleData['starts_date']) . " " . decryptData($scheduleData['end_date']) .'</option>',
            'days' => '<option value="' . $scheduleData['schedule_id'] . '">' . htmlspecialchars($scheduleData['days']) . '</option>'
        );

        echo json_encode($response);
    } else {
        echo json_encode(array(
            'dates' => '<option value="">No available dates</option>',
            'days' => '<option value="">No available days</option>'
        ));
    }
}
?>
