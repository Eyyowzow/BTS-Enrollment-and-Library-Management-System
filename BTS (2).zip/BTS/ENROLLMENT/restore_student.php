<?php
include '../Database/Database.php';

if (isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];

    $sql = "UPDATE students SET is_deleted = 0 WHERE student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);

    if ($stmt->execute()) {
        echo "Student restored successfully!";
        header("Location: backup_restore.php");
    } else {
        echo "Error restoring student: " . $stmt->error;
    }

    $stmt->close();
}
?>
