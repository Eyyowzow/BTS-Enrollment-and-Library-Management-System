<?php
include '../Database/Database.php';

if (isset($_GET['scholarship_id'])) {
    $scholarship_id = $_GET['scholarship_id'];
    
    $sql = "UPDATE scholarships SET is_deleted = 1 WHERE scholarship_id = $scholarship_id";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Scholarship deleted successfully');</script>";
        header("Location: manage_students.php");

    } else {
        echo "Error hiding student: " . mysqli_error($conn);
    }
}
?>
