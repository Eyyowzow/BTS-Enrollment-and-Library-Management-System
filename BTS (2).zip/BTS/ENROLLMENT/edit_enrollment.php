<?php 
include '../Database/Database.php';
include_once 'encryption.php';

$alert_message = '';

if (isset($_SESSION['alert_message'])) {
    $alert_message = $_SESSION['alert_message'];
    unset($_SESSION['alert_message']); 
}

$program = $trainor = $batch_no = $starts_date = $end_date = $time_start = $time_end = $days = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $trainor = $_POST['trainor'];
    $batch_no = $_POST['batch_no'];
    $days = $_POST['days'];
}

$program_query = "SELECT program_id, program_name, level, CONCAT(program_name, ' ', level) AS tesda_program FROM programs WHERE is_deleted = 0";
$trainor_query = "SELECT trainor_id, first_name, last_name, CONCAT(first_name, ' ', last_name) AS trainor_name FROM trainors WHERE is_deleted = 0";
$date_query = "SELECT schedule_id, CONCAT(starts_date, ' - ', end_date) AS date_span FROM schedules WHERE is_deleted = 0";

$programs = $conn->query($program_query);
$trainors = $conn->query($trainor_query);
$schedules = $conn->query($date_query);
?>

<div class="col-xl-12 col-xxl-12">
    <div id="editEnrollmentModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <form id="editEnrollmentForm" method="POST" action="enrolled_masterlist.php" >
                    <input type="hidden" name="id" id="id">
                    <div>
                        <center><h4>UPDATE ENROLLMENT FORM</h4></center>
                            <hr>
                            <div class="col-lg-12 mb-12">
                                <h6 class="text-primary">PERSONAL INFORMATION</h6>
                            </div>
                            <div class="row">
                            <div class="col-lg-12 mb-12">
                                <div class="form-group">
                                    <label class="text-label" for="student_name">Student's Name</label>
                                    <span class="text-danger">*</span>
                                    <div class="input-group">
                                    <input type="text" id="studentName" class="form-control" name="student" placeholder="Search Student Name" autocomplete="off" required>

                                    <div class="input-group">
                                            <ul id="studentList" style="list-style-type: none;"></ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-12">
                                <div class="form-group">
                                    <label class="text-label" for="educational_attainment">Educational Attainment</label>
                                    <span class="text-danger">*</span>
                                    <div class="input-group">
                                    <select class="form-control" id="education" name="educational_attainment" required>
                                        <option value="">Select</option>
                                        <option>NA</option>
                                        <option>Primary Education</option>
                                        <option>Secondary Education</option>
                                        <option>Post-Secondary Education</option>
                                        <option>Tertiary Education</option>
                                        <option>Graduate</option>
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-12">
                                <div class="form-group">
                                    <label class="text-label">Employment Before Training</label>
                                    <div class="input-group">
                                        <input type="text" id="employment" name="employment" class="form-control" placeholder="Employment Before Training">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-4">
                                <div class="form-group">
                                    <label class="text-label" for="scholarship">Scholarship</label>
                                    <span class="text-danger">*</span>
                                    <div class="input-group">
                                        <select class="form-control" id="scholarship" name="scholarship" required>
                                            <option value="">Select Scholarship</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-12">
                                <center><h6 class="text-primary">TESDA PROGRAM</h6></center>
                            </div>
                            <div class="col-lg-1 mb-12">
                                <div class="form-group">
                                    <label class="text-label" for="batch_no">Batch</label>
                                    <span class="text-danger">*</span>
                                    <div class="input-group">
                                    <select class="form-control" id="batch_no" name="batch_no" required>
                                        <option value="">Select Batch</option>
                                        <?php 
                                        $batches = $conn->query("SELECT DISTINCT batch_no FROM schedules"); 
                                        while ($row = $batches->fetch_assoc()): ?>
                                            <option value="<?php echo $row['batch_no']; ?>"><?php echo htmlspecialchars($row['batch_no']); ?></option>
                                        <?php endwhile; ?>
                                    </select>

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-12">
                                <div class="form-group">
                                    <label class="text-label" for="program">Program</label>
                                    <span class="text-danger">*</span>
                                    <div class="input-group">
                                        <select class="form-control" id="program" name="program" required>
                                        <option value="">Select Program</option>
                                        <?php while ($row = $programs->fetch_assoc()): ?>
                                            <option value="<?php echo $row['program_id']; ?>"><?php echo decryptData($row['program_name']) . " " . decryptData($row['level']); ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                                <div class="col-lg-3 mb-12">
                                    <div class="form-group">
                                        <label class="text-label" for="trainor">Trainor</label>
                                        <span class="text-danger">*</span>
                                        <div class="input-group">
                                            <select class="form-control" id="trainor" name="trainor" value="<?php echo decryptData($row['first_name']) . " " . decryptData($row['last_name']); ?>" required>
                                            <option value="">Select Trainor</option>
                                            <?php while ($row = $trainors->fetch_assoc()): ?>
                                                <option value="<?php echo $row['trainor_id']; ?>"><?php echo decryptData($row['first_name']) . " " . decryptData($row['last_name']); ?></option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-12">
                                    <div class="form-group">
                                    <label class="text-label" for="date">Date</label>
                                    <span class="text-danger">*</span>
                                        <div class="input-group">
                                            <select class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($row['starts_date']) . " - " . htmlspecialchars($row['end_date']) ; ?>" required>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2 mb-12">
                                    <div class="form-group">
                                        <label class="text-label" for="days">Days</label>
                                        <span class="text-danger">*</span>
                                        <div class="input-group">
                                            <select class="form-control" id="days" name="days" required>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>

                        <div>
                            <center><button type="submit" class="btn btn-primary">  Update  </button></center>
                        </div> 
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const editButtons = document.querySelectorAll('.edit-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Populate the hidden input with ID
            document.getElementById('id').value = button.getAttribute('data-id');
            document.getElementById('studentName').value = button.getAttribute('data-student');
            document.getElementById('education').value = button.getAttribute('data-educational_attainment');
            document.getElementById('employment').value = button.getAttribute('data-employment');
            document.getElementById('scholarship').value = button.getAttribute('data-scholarship');
            document.getElementById('batch_no').value = button.getAttribute('data-batch_no');
            document.getElementById('program').value = button.getAttribute('data-program');
            document.getElementById('trainor').value = button.getAttribute('data-trainor');
            
            // Split start and end dates from the `data-date` attribute
            document.getElementById('date').value = button.getAttribute('data-date');
            document.getElementById('days').value = button.getAttribute('data-days');
        });
    });
});
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
// Student Name
$(document).ready(function() {
    $('#studentName').keyup(function() {
        let query = $(this).val();
        if (query != '') {
            $.ajax({
                url: "fetch_data.php",
                method: "POST",
                data: { query: query, type: 'student' },
                success: function(data) {
                    $('#studentList').fadeIn();
                    $('#studentList').html(data);
                }
            });
        } else {
            $('#studentList').fadeOut();
        }
    });

    //ULI
    $(document).on('click', '#studentList li', function() {
        $('#studentName').val($(this).text());
        $('#uli').val($(this).data('uli'));
        $('#studentList').fadeOut();
    }); 

    $(document).click(function(event) {
        if (!$(event.target).closest('#studentName, #studentList').length) {
            $('#studentList').fadeOut();
        }
    });
});

// Scholarship
$.ajax({
    url: 'get_scholarships.php', 
    method: 'GET',
    success: function(response) {
        $('#scholarship').html(response);
    }
});


// Batch Number
$.ajax({
    url: 'get_batches.php', 
    method: 'GET',
    success: function(response) {
        $('#batch_no').html(response);
    }
});

// Programs
$('#batch_no').on('change', function() {
    var batchNo = $(this).val();
    if (batchNo) {
        $.ajax({
        url: 'get_programs.php',
        method: 'POST',
        data: { batch_no: batchNo },
        success: function(response) {
            $('#program').html(response);
            }
        });
    }
});

// Trainer/Trainor haha
$('#program').on('change', function() {
    var programId = $(this).val();
    var batchNo = $('#batch_no').val();
    if (programId) {
        $.ajax({
            url: 'get_trainors.php',
            method: 'POST',
            data: { program_id: programId },
            success: function(response) {
                $('#trainor').html(response);
            }
        });
    }
});

// Autoselect Date/Tim/eDays
$('#trainor').on('change', function() {
    var trainorID = $(this).val();
    var batchNo = $('#batch_no').val();
    var programID = $('#program').val();
    
    if (trainorID && batchNo && programID) {
        $.ajax({
            url: 'get_schedule_details.php',
            method: 'POST',
            data: { 
                trainor_id: trainorID, 
                batch_no: batchNo, 
                program_id: programID 
            },
            success: function(response) {
                var data = JSON.parse(response);
                $('#date').html(data.dates); 
                $('#days').html(data.days);  
            }
        });
    }
});
</script>
<script>
    document.getElementById('studentList').addEventListener('click', function (e) {
    if (e.target.tagName === 'LI') {
        const studentId = e.target.getAttribute('data-id');
        document.getElementById('student_id').value = studentId;
    }
});
</script>