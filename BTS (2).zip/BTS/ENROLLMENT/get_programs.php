<?php 
include '../Database/Database.php';
include 'encryption.php';

if (isset($_POST['batch_no'])) {
    $batch_no = $_POST['batch_no'];
    $query = "SELECT DISTINCT p.program_id, 
              p.program_name, p.level,
              CONCAT(p.program_name, ' ', p.level) AS tesda_program 
              FROM programs p 
              JOIN schedules s ON p.program_id = s.program_id 
              WHERE s.batch_no = ?
              AND s.is_deleted = 0"; 
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $batch_no);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $options = '<option value="">Select Program</option>';
    while ($row = $result->fetch_assoc()) {
        $options .= '<option value="' . $row['program_id'] . '">' . decryptData($row['program_name']) . " " . decryptData($row['level']) . '</option>';
    }
    echo $options;
}
if ($programs->num_rows > 0) {
    while ($row = $programs->fetch_assoc()) {
        echo "Program ID: " . $row['program_id'] . " - Program: " . decryptData($row['program_name']) . " " . decryptData($row['level']) . "<br>";
    }
} else {
    echo "No programs found or all programs are deleted.";
}

?>
