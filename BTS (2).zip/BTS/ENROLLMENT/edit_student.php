<!-- CODE FOR EDITIN STUDEN INFORMATIONS -->
<div class="col-xl-12 col-xxl-12">
    <div id="editStudent" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editStudentForm" action="manage_students.php" method="POST" >
                        <input type="hidden" name="studentId" id="editStudentId">
                        <div>
                            <center><h4 id="editStudentLabel">UPDATE REGISTRATION FORM</h4></center>
                            <hr>    
                            <section>
                                <h6 class="text-primary">PERSONAL INFORMATION</h6>
                                <div class="row">
                                    <div class="col-lg-2 mb-2">
                                        <div class="form-group">
                                        <label class="text-label" for="uli">Student ULI</label>
                                        <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" name="uli" class="form-control" id="uli" placeholder="Student ULI" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="form-group">
                                            <label class="text-label" for="lastName">Last Name</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" name="lastName" class="form-control" id="lastName" placeholder="Surname" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="form-group">
                                            <label class="text-label" for="firstName">First Name</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" name="firstName" class="form-control" id="firstName" placeholder="First Name" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-2">
                                        <div class="form-group">
                                            <label class="text-label" for="middleName">Middle Name</label>
                                            <div class="input-group">
                                                <input type="text" name="middleName" class="form-control" id="middleName" placeholder="Middle Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="birthPlace">Birthplace</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" name="birthPlace" class="form-control" id="birthPlace" placeholder="Birthplace" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="birthDate">Birthdate</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="date" id="birthDate" name="birthDate" class="form-control" placeholder="Birthdate" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="gender">Gender</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                            <select class="form-control" id="gender" name="gender" required>
                                                <option value="">Select</option>
                                                <option>Female</option>
                                                <option>Male</option>
                                            </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="maritalStatus">Marital Status</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                            <select class="form-control" id="maritalStatus" name="maritalStatus" required>
                                                <option value="">Select</option>
                                                <option>Single</option>
                                                <option>Married</option>
                                            </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="citizenship">Citizenship</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" id="citizenship" name="citizenship" class="form-control" placeholder="Citizenship" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <h6 class="text-primary">PERSONAL CONTACT INFORMATION</h6>
                                    </div>
                                    <div class="col-lg-5 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="email">Email</label>
                                            <div class="input-group">
                                                <input type="email" id="email" name="email" class="form-control" placeholder="Email Adddress">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="fbAccount">Facebook Account</label>
                                            <div class="input-group">
                                                <input type="text" id="fbAccount" name="fbAccount" class="form-control" placeholder="Facebook Account">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="phoneNumber">Phone Number</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="number" id="phoneNumber" name="phoneNumber" class="form-control" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <h6 class="text-primary">PARENT/GUARDIAN INFORMATION</h6>
                                    </div>
                                    <div class="col-lg-4 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="parentLastName">Last Name</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" id="parentLastName" name="parentLastName" class="form-control" placeholder="Surname" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="parentFirstName">First Name</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" id="parentFirstName" name="parentFirstName" class="form-control" placeholder="First Name" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="parentMiddleName">Middle Name</label>
                                            <div class="input-group">
                                                <input type="text" id="parentMiddleName" name="parentMiddleName" class="form-control" placeholder="Middle Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="parentPhone">Phone Number</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="number" id="parentPhone" name="parentPhone" class="form-control" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <h6 class="text-primary">CURRENT ADDRESS</h6>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="form-group">
                                            <label class="text-label" for="streetNumber">Street No. / Unit No.</label>
                                            <div class="input-group">
                                                <input type="number" id="streetNumber" name="streetNumber" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="form-group">
                                            <label class="text-label" for="streetName">Street</label>
                                            <div class="input-group">
                                                <input type="text" id="streetName" name="streetName" class="form-control" placeholder="Street Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="form-group">
                                            <label class="text-label" for="subdivision">Subdivision / Village / Bldg</label>
                                            <div class="input-group">
                                                <input type="text" id="subdivision" name="subdivision" class="form-control" placeholder="Subdivision / Village / Bldg">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="form-group">
                                            <label class="text-label" for="barangay">Barangay</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" id="barangay" name="barangay" class="form-control" placeholder="Barangay" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-4">
                                        <div class="form-group">
                                            <label class="text-label" for="city">City / Municipality</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" id="city" name="city" class="form-control" placeholder="City / Municipality" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-4">
                                            <div class="form-group">
                                            <label class="text-label" for="province">Province</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="text" id="province" name="province" class="form-control" placeholder="Province" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <h6 class="text-primary">REQUIREMENTS PASSED</h6>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="form137" name="form137" class="form-check-input" value="1">Form 137 or Form 10
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="reportCard" name="reportCard" class="form-check-input" value="1">Form 9 or Report Card
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline disabled">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="diploma" name="diploma" class="form-check-input" value="1">DIPLOMA
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="completionCert" name="completionCert" class="form-check-input" value="1">Completion Certificate
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="transcript" name="transcript" class="form-check-input" value="1">Transcript of Records
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="birthCert" name="birthCert" class="form-check-input" value="1">PSA Birth Certificate
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="marriageCert" name="marriageCert" class="form-check-input" value="1">PSA Marriage Certificate
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="checkbox" id="idPhoto" name="idPhoto" class ="form-check-input" value="1">Passport Size ID/1x1 ID
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <h6 class="text-primary">UPLOAD DOCUMENTS</h6>
                                    </div>
                                    <div class="col-lg-12 mb-4">
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input">
                                                <label class="custom-file-label">Choose file</label>
                                            </div>
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="button">Button</button>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            <div >
                            <center><button type="submit" name="editStudent" class="btn btn-primary">  Update  </button></center>
                        </div>     
                    </section> 
                </div>
            </form>
        </div>
    </div>
</div>
<script>
$(document).on('click', '.edit-btn', function() {
    var studentId = $(this).data('id');
    var uli = $(this).data('uli');
    var lastName = $(this).data('lastname');
    var firstName = $(this).data('firstname');
    var middleName = $(this).data('middlename');
    var birthPlace = $(this).data('birthplace');
    var birthDate = $(this).data('birthdate');
    var gender = $(this).data('gender');
    var maritalStatus = $(this).data('status');
    var citizenship = $(this).data('citizenship');
    var email = $(this).data('email');
    var fbAccount = $(this).data('account');
    var phoneNumber = $(this).data('phonenumber');
    var parentLastName = $(this).data('plastname');
    var parentFirstName = $(this).data('pfirstname');
    var parentMiddleName = $(this).data('pmiddlename');
    var parentPhone = $(this).data('pcontact');
    var streetNumber = $(this).data('streetnumber');
    var streetName = $(this).data('streetname');
    var subdivision = $(this).data('subdivision');
    var barangay = $(this).data('barangay');
    var city = $(this).data('city');
    var province = $(this).data('province');
    var form137 = $(this).data('form137');
    var reportCard = $(this).data('form9');
    var diploma = $(this).data('diploma');
    var completionCert = $(this).data('completioncert');
    var transcript = $(this).data('transcript');
    var birthCert = $(this).data('psabirth');
    var marriageCert = $(this).data('psamarriage');
    var idPhoto = $(this).data('passportsizeid');

    $('#editStudentId').val(studentId);
    $('#uli').val(uli);
    $('#lastName').val(lastName);
    $('#firstName').val(firstName);
    $('#middleName').val(middleName);
    $('#birthPlace').val(birthPlace);
    $('#birthDate').val(birthDate);
    $('#gender').val(gender);
    $('#maritalStatus').val(maritalStatus);
    $('#citizenship').val(citizenship);
    $('#email').val(email);
    $('#fbAccount').val(fbAccount);
    $('#phoneNumber').val(phoneNumber);
    $('#parentLastName').val(parentLastName);
    $('#parentFirstName').val(parentFirstName);
    $('#parentMiddleName').val(parentMiddleName);
    $('#parentPhone').val(parentPhone);
    $('#streetNumber').val(streetNumber);
    $('#streetName').val(streetName);
    $('#subdivision').val(subdivision);
    $('#barangay').val(barangay);
    $('#city').val(city);
    $('#province').val(province);
    $('#form137').prop('checked', form137 ? true : false);
    $('#reportCard').prop('checked', reportCard ? true : false );
    $('#diploma').prop('checked', diploma ? true : false);
    $('#completionCert').prop('checked', completionCert ? true : false);
    $('#transcript').prop('checked', transcript ? true : false);
    $('#birthCert').prop('checked', birthCert ? true : false);
    $('#marriageCert').prop('checked', marriageCert ? true : false );
    $('#idPhoto').prop('checked', idPhoto ? true : false );
});

</script>
