<?php 
session_start();
include 'header.php';
include 'sidebar.php';

$alert_message = '';

if (isset($_SESSION['alert_message'])) {
    $alert_message = $_SESSION['alert_message'];
    unset($_SESSION['alert_message']); 
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    if (isset($_POST['toggle_status'])) {
        $enrollment_id = $_POST['enrollment_id'];
        $current_status = $_POST['current_status'];

         // Toggle button for setting student status
        $new_status = ($current_status == 'enrolled') ? 'dropped' : 'enrolled';

        // Updates the enrollment status in the database
        $stmt = $conn->prepare("UPDATE enroll_assessment SET student_status = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("si", $new_status, $enrollment_id);
            if ($stmt->execute()) {
                $_SESSION['alert_message'] = "Status updated successfully to " . ucfirst($current_status) . ".";
            } else {
                $_SESSION['alert_message'] = "Error updating status: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['alert_message'] = "Error preparing statement: " . $conn->error;
        }
    } else {
        $student_id = $_POST['student_id'];
        $assessment_id = $_POST['assessment'];
        $educational_attainment = $_POST['educational_attainment'];
        $employment = $_POST['employment'];

        $student_status = 'enrolled';

        // Insertig enrollment into the database
        $stmt = $conn->prepare("
            INSERT INTO enrollments 
            (student_id, assessment_id, educational_attainment, employment, student_status) 
            VALUES (?, ?, ?, ?, ?)
        ");

        if ($stmt) {
            $stmt->bind_param("iisss", $student_id, $assessment_id, $educational_attainment, $employment, $student_status);
            if ($stmt->execute()) {
                $_SESSION['alert_message'] = "Enrollment successfully added.";
            } else {
                $_SESSION['alert_message'] = "Error executing statement: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['alert_message'] = "Error preparing statement: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
</head>

<body>
    
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Enrolled Masterlist</h4>
                            <span class="ml-1">Data Entry</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Add New Assessment Button -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addAssessmentModal">Enroll Student
                                </button>
                        </ol>
                    </div>
                </div>
                <?php if ($alert_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-check"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $alert_message; ?>
                    </div>
                <?php endif; ?>
                <!-- row -->
                 

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $sql = "
                                            SELECT e.id,
                                                e.educational_attainment,
                                                e.employment,
                                                s.ULI,
                                                s.first_name, s.last_name, 
                                                a.assessment_name, a.location,
                                                CONCAT(a.assessment_name, ' ', a.location) AS tesda_assessment,
                                                e.student_status 
                                            FROM enroll_assessment e
                                            JOIN students s ON e.student_id = s.student_id
                                            JOIN assessments a ON e.assessment_id = a.assessment_id
                                            
                                        ";
                                        $result = mysqli_query($conn, $sql);
                                        $count = 1;
                                        if (!$result) {
                                            echo "Error executing query: " . mysqli_error($conn);
                                            exit;
                                        }
                                        
                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo "<tr>";
                                                echo "<td>" . $count++ . "</td>";
                                                echo "<td>" . decryptData($row['ULI']) . "</td>";
                                                echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</td>"; 
                                                echo "<td>
                                                    <form method='POST' action=''>
                                                        <input type='hidden' name='enrollment_id' value='" . htmlspecialchars($row['id']) . "'>
                                                        <input type='hidden' name='current_status' value='" . htmlspecialchars($row['student_status']) . "'>
                                                        <button type='submit' name='toggle_status' class='btn btn-text' style='color: #414152;'>
                                                            " . htmlspecialchars(ucfirst($row['student_status'])) . "
                                                        </button>
                                                    </form>
                                                </td>";
                                                echo "<td>
                                                       <a href='.php' class='edit-btn' 
                                                        data-id='{$row['id']}' 
                                                        data-student='" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "' 
                                                        data-educational_attainment='" . htmlspecialchars($row['educational_attainment']) . "' 
                                                        data-employment='" . htmlspecialchars($row['employment']) . "' 
                                                        data-assessment='" . decryptData($row['assessment_name']) . "'
                                                        data-toggle='modal' data-target='#'>
                                                        <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                        </a>


                                                        <a href='#' class='view-btn' 
                                                            data-id='" . htmlspecialchars($row['id']) . "' 
                                                            data-uli='" . decryptData($row['ULI']) . "' 
                                                            data-student-name='" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "' 
                                                            data-assessment='" . decryptData($row['assessment_name']) . " - " . decryptData($row['level']) . "' 
                                                            data-status='" . decryptData($row['student_status']) . "' 
                                                            data-toggle='modal' data-target='#viewEnrollmentAssessmentModal'>
                                                                <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> 
                                                        </a>
                                                        <a href='delete_enrollment.php?id=" . $row['id'] . "' 
                                                            onclick='return confirm(\"Are you sure you want to delete this enrollment?\");'>
                                                            <i class='fa fa-trash' style='color: red; font-size: 15px;'></i>
                                                        </a>
                                                    </td>";
                                                echo "</tr>";
                                            }
                                        }
                                        ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                <div class="modal fade" id="addAssessmentModal" tabindex="-1" aria-labelledby="addAssessmentodalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                <form method="POST" action="enrolled_assessment.php" >
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addAssessmentModalLabel">Enroll Student</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                            <div class="col-lg-12 mb-12">
                                            <center><h6 class="text-primary">PERSONAL INFORMATION</h6></center>
                                            </div>
                                            <div class="col-lg-12 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="student_name">Student's Name</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                    <input type="text" id="student_name" class="form-control" name="student_name" placeholder="Search Student Name" autocomplete="off" required>
                                                    <input type="hidden" name="student_id" id="student_id" value="">

                                                    <div class="input-group" style="position: relative;">
                                                    <ul id="studentList" 
                                                    class="form-control"
                                                    style="list-style-type: none; padding: 0; margin: 0; 
                                                            position: absolute; width: 100%; z-index: 1000; 
                                                            background: white; border: 1px solid #ccc; border-radius: 0 0 5px 5px;
                                                            max-height: 200px; overflow-y: auto; display: none;">
                                                    </ul>
                                                    </div>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-6">
                                                <div class="form-group">
                                                    <label class="text-label" for="educational_attainment">Educational Attainment</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                    <select class="form-control" id ="educational_attainment" name="educational_attainment" required>
                                                        <option value="">Select</option>
                                                        <option>NA</option>
                                                        <option>Primary Education</option>
                                                        <option>Secondary Education</option>
                                                        <option>Post-Secondary Education</option>
                                                        <option>Tertiary Education</option>
                                                        <option>Graduate</option>
                                                    </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-6">
                                                <div class="form-group">
                                                    <label class="text-label">Employment Before Training</label>
                                                    <div class="input-group">
                                                        <input type="text" name="employment" class="form-control" placeholder="Employment Before Training">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-12">
                                                <center><h6 class="text-primary">TESDA ASSESSMENT / PROGRAM</h6></center>
                                            </div>
                                            <div class="col-lg-12 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="assessment">Assessment</label>
                                                    <div class="input-group">
                                                        <select class="form-control" id="assessment" name="assessment">
                                                            
                                                            <option value="">Select Assessment</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>

                                    <div class="modal-footer">
                                        <button type="submit" name="addAssessment" class="btn btn-primary">  Enroll Student  </button>
                                    </div> 
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>

    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>

    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 3000); 
        }
    };
    </script>
    <!-- Fetching Script -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
// Student Name
$(document).ready(function() {
    $('#student_name').keyup(function() {
        let query = $(this).val();
        if (query != '') {
            $.ajax({
                url: "fetch_data.php",
                method: "POST",
                data: { query: query, type: 'student' },
                success: function(data) {
                    $('#studentList').fadeIn();
                    $('#studentList').html(data);
                }
            });
        } else {
            $('#studentList').fadeOut();
        }
    });

    //ULI
    $(document).on('click', '#studentList li', function() {
        $('#student_name').val($(this).text());
        $('#uli').val($(this).data('uli'));
        $('#studentList').fadeOut();
    }); 

    $(document).click(function(event) {
        if (!$(event.target).closest('#student_name, #studentList').length) {
            $('#studentList').fadeOut();
        }
    });
});


// Assessment
$.ajax({
    url: 'get_assessments.php', 
    method: 'GET',
    success: function(response) {
        $('#assessment').html(response);
    }
});


</script>
</body>
</html>
<?php
include 'view_student_assessment.php';
?>