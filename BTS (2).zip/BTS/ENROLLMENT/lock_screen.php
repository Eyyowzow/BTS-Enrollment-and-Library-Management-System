<?php
session_start();
include '../Database/Database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $entered_password = $_POST['user_password'];

    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $query = "SELECT user_password FROM users WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $stored_password = $row['user_password'];

            if (password_verify($entered_password, $stored_password)) {
                header('Location: index.php');
                exit();
            } else {
                $error_message = "Incorrect password. Please try again.";
            }
        } else {
            $error_message = "User not found.";
        }
    } else {
        header('Location: login.php');
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System</title>
    <link rel="icon" type="image/png" sizes="16x16" href="../bootstrap/images/logo.png">
    <link href="../bootstrap/css/style.css" rel="stylesheet">

    <style>
        body {
            background-image: url('../ASSETS/7.jpg');
            background-repeat: no-repeat;
            background-size: cover;
        }
        div.authincation-content {
            border-radius: 9px;
            -moz-border-radius: 9px;
            -webkit-border-radius: 9px;
            color: #5d5d5d;
        }
    </style>
</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container-fluid h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-4">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Benguet Technical School <br> Enrollment Management System <br> Account Locked!</h4>
                                    <form action="index.php" method="POST"> 
                                        <div>
                                            <center><img src="../bootstrap/images/logo.png" height="100px" class="img-responsive" alt="" /></center>
                                        </div><br>
                                        <div class="form-group">
                                            <input type="password" name="user_password" class="form-control" placeholder="Password" required> 
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Unlock</button>
                                        </div>
                                    </form>
                                    <div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>

</body>

</html>
