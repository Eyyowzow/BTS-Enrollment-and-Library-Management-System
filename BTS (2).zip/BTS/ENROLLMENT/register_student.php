<?php
session_start();

include 'header.php';
include 'sidebar.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <!-- Form step -->
    <link href="../bootstrap/vendor/jquery-steps/css/jquery.steps.css" rel="stylesheet">


</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Register Student</h4>
                            <p class="mb-0">Transaction</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Transaction </a></li>
                            <li class="breadcrumb-item active"><a href="./index.php">Back</a></li>
                        </ol>
                    </div>
                </div>
                <!-- row -->
                <div class="row" id="addProgram">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card">
                            <div class="card-header">
                            </div>
                            <div class="card-body">
                                <form action="manage_students.php" method="POST" enctype="multipart/form-data">
                                    <div>
                                        <center><h4 id="addProgram">REGISTRATION FORM</h4></center>
                                        <hr>
                                        <section>
                                            <h6 class="text-primary">PERSONAL INFORMATION</h6>
                                            <div class="row">
                                                <div class="col-lg-2 mb-2">
                                                    <div class="form-group">
                                                    <label class="text-label" >Student ULI</label>
                                                    <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="uli" class="form-control" placeholder="Student ULI" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-2">
                                                    <div class="form-group">
                                                        <label class="text-label">Last Name</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="last_name" class="form-control" placeholder="Surname" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-2">
                                                    <div class="form-group">
                                                        <label class="text-label">First Name</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="first_name" class="form-control" placeholder="First Name" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-2">
                                                    <div class="form-group">
                                                        <label class="text-label">Middle Name</label>
                                                        <div class="input-group">
                                                            <input type="text" name="middle_name" class="form-control" placeholder="Middle Name">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Birthplace</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="birth_place" class="form-control" placeholder="Birthplace" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Birthdate</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="date" name="birth_date" class="form-control" placeholder="Birthdate" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label" for="val-skill">Gender</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                        <select class="form-control" name="gender" required>
                                                            <option value="">Select</option>
                                                            <option>Female</option>
                                                            <option>Male</option>
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label" for="val-skill">Marital Status</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                        <select class="form-control" name="marital_status" required>
                                                            <option value="">Select</option>
                                                            <option>Single</option>
                                                            <option>Married</option>
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Citizenship</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="citizenship" class="form-control" placeholder="Citizenship" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 mb-12">
                                                    <h6 class="text-primary">PERSONAL CONTACT INFORMATION</h6>
                                                </div>
                                                <div class="col-lg-5 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Email</label>
                                                        <div class="input-group">
                                                            <input type="email" name="email" class="form-control" placeholder="Email Adddress">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Facebook Account</label>
                                                        <div class="input-group">
                                                            <input type="url" name="fb_account" class="form-control" placeholder="Enter Facebook URL" pattern="https?://(www\.)?facebook\.com/.+" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Phone Number</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="phone_number" class="form-control" pattern="\d{11}" 
                                                            maxlength="11" title="Phone number must be exactly 11 digits" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 mb-12">
                                                    <h6 class="text-primary">PARENT/GUARDIAN INFORMATION</h6>
                                                </div>
                                                <div class="col-lg-4 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Last Name</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="parent_lastname" class="form-control" placeholder="Surname" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">First Name</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="text" name="parent_firstname" class="form-control" placeholder="First Name" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Middle Name</label>
                                                        <div class="input-group">
                                                            <input type="text" name="parent_middlename" class="form-control" placeholder="Middle Name">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 mb-4">
                                                    <div class="form-group">
                                                        <label class="text-label">Phone Number</label>
                                                        <span class="text-danger">*</span>
                                                        <div class="input-group">
                                                            <input type="number" name="parent_phone" class="form-control" pattern="\d{11}" 
                                                            maxlength="11" title="Phone number must be exactly 11 digits" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                    <div class="col-lg-12 mb-12">
                                                        <h6 class="text-primary">CURRENT ADDRESS</h6>
                                                    </div>
                                                    <div class="col-lg-4 mb-2">
                                                        <div class="form-group">
                                                            <label class="text-label">Street No. / Unit No.</label>
                                                            <div class="input-group">
                                                                <input type="number" name="street_number" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-2">
                                                        <div class="form-group">
                                                            <label class="text-label">Street</label>
                                                            <div class="input-group">
                                                                <input type="text" name="street_name" class="form-control" placeholder="Street Name">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-2">
                                                        <div class="form-group">
                                                            <label class="text-label">Subdivision / Village / Bldg</label>
                                                            <div class="input-group">
                                                                <input type="text" name="subdivision" class="form-control" placeholder="Subdivision / Village / Bldg">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-2">
                                                        <div class="form-group">
                                                            <label class="text-label">Barangay</label>
                                                            <span class="text-danger">*</span>
                                                            <div class="input-group">
                                                                <input type="text" name="barangay" class="form-control" placeholder="Barangay" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-4">
                                                        <div class="form-group">
                                                            <label class="text-label">City / Municipality</label>
                                                            <span class="text-danger">*</span>
                                                            <div class="input-group">
                                                                <input type="text" name="city" class="form-control" placeholder="City / Municipality" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-4">
                                                            <div class="form-group">
                                                            <label class="text-label">Province</label>
                                                            <span class="text-danger">*</span>
                                                            <div class="input-group">
                                                                <input type="text" name="province" class="form-control" placeholder="Province" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 mb-12">
                                                        <h6 class="text-primary">REQUIREMENTS PASSED</h6>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="form_137" class="form-check-input" value="">Form 137 or Form 10
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="report_card" class="form-check-input" value="">Form 9 or Report Card
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline disabled">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="diploma" class="form-check-input" value="">DIPLOMA
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="completion_cert" class="form-check-input" value="">Completion Certificate
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="transcript_records" class="form-check-input" value="">Transcript of Records
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="birth_cert" class="form-check-input" value="">PSA Birth Certificate
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="marriage_cert" class="form-check-input" value="">PSA Marriage Certificate
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 mb-2">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="id_photo" class ="form-check-input" value="">Passport Size ID/1x1 ID
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 mb-12">
                                                        <h6 class="text-primary">UPLOAD DOCUMENTS</h6>
                                                    </div>
                                                    <div class="col-lg-12 mb-4">
                                                        <div class="input-group">
                                                            <div class="custom-file">
                                                            <input type="file" name="attached" id="attached" class="custom-file-input" accept=".pdf, .doc, .docx, .jpg, .jpeg, .png" />
                                                                <label class="custom-file-label">Choose file</label>
                                                            </div>
                                                            <div class="input-group-append">
                                                                <button class="btn btn-primary" type="button">Attach File</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div >
                                                <center><button type="submit" name="addStudent" class="btn btn-primary">  Register Student  </button></center>
                                                </div>     
                                        </section> 
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    


    <script src="../bootstrap/vendor/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="../bootstrap/vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Form validate init -->
    <script src="../bootstrap/js/plugins-init/jquery.validate-init.js"></script>



    <!-- Form step init -->
    <script src="../bootstrap/js/plugins-init/jquery-steps-init.js"></script>

</body>

</html>