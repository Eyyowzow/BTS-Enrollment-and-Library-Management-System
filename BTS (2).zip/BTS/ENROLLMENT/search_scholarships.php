<?php
include '../Database/Database.php';
include 'encryption.php';

if (isset($_POST['query'])) {
    $query = trim($_POST['query']);  

    if (!empty($query)) {
        $sql = "SELECT scholarship_id, scholarship_name 
                FROM scholarships 
                WHERE scholarship_name LIKE ? 
                AND is_deleted = 0
                LIMIT 10";
        $stmt = $conn->prepare($sql);
        
        $search_query = "%" . $query . "%";
        $stmt->bind_param('s', $search_query);  
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li data-scholarship_id='".$row['scholarship_id']."'>" . decryptData($row['scholarship_name']) . "</li>";
            }
        } else {
            echo "<li>No assessments found</li>";
        }
    } else {
        echo "<center><li>Please enter a name to search</li></center>";  
    }
}
?>
