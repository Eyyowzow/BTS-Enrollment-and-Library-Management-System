<?php
include '../Database/Database.php';

if (isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];
    
    $sql = "UPDATE students SET is_deleted = 1 WHERE student_id = $student_id";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Student deleted successfully');</script>";
        header("Location: manage_students.php");

    } else {
        echo "Error hiding student: " . mysqli_error($conn);
    }
}
?>
