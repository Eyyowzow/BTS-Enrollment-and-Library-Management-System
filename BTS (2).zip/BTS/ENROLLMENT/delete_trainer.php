<?php
include '../Database/Database.php';

if (isset($_GET['trainor_id'])) {
    $trainor_id = $_GET['trainor_id'];
    
    $sql = "UPDATE trainors SET is_deleted = 1 WHERE trainor_id = $trainor_id";
    
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Trainor deleted successfully');</script>";
        header("Location: manage_trainer.php");

    } else {
        echo "Error hiding student: " . mysqli_error($conn);
    }
}
?>
