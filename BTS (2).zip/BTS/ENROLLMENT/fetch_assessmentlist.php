<?php
include '../Database/Database.php';
include_once 'encryption.php';
if (isset($_GET['assessment_id'])) {
    $assessment_id = $_GET['assessment_id'];
    
    if (!empty($assessment_id)) {
        error_log("Fetching students for Assessment ID: " . $assessment_id);
        
        $sql = "SELECT e.id, s.ULI, 
        s.first_name,
        s.last_name,
        s.gender,
        e.student_status
        FROM enrollments e
        JOIN students s ON e.student_id = s.student_id  
        JOIN assessments a ON e.assessment_id = a.assessment_id
        WHERE a.assessment_id = ? AND is_delete=0
        ";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $assessment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $counter = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $counter++ . "</td>";
                echo "<td>" . decryptData($row['ULI']) . "</td>";
                echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</td>";
                echo "<td>" . decryptData($row['gender']) . "</td>";
                echo "<td>" . htmlspecialchars($row['student_status']) . "</td>";
                echo "<td><a href='edit_student.php?id=" . $row['id'] . "'>
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                echo </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No students found for this assessment</td></tr>";  
        }
    } else {
        echo "<tr><td colspan='7'>Assessment ID is empty</td></tr>";
    }
}
?>
