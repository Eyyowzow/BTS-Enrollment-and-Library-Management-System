<?php
// view_file.php

$encryptionKey = 'your-encryption-key-32-chars';

if (isset($_GET['file'])) {
    $fileName = basename($_GET['file']);
    $filePath = "../uploads/" . $fileName;

    if (file_exists($filePath)) {
        // Read encrypted file
        $encryptedData = file_get_contents($filePath);
        $decodedData = base64_decode($encryptedData);

        // Get IV length
        $ivLength = openssl_cipher_iv_length('aes-256-cbc');
        $iv = substr($decodedData, 0, $ivLength);
        $encryptedContent = substr($decodedData, $ivLength);

        // Decrypt
        $decryptData = openssl_decrypt($encryptedContent, 'aes-256-cbc', $encryptionKey, 0, $iv);
        
        if ($decryptedData !== false) {
            // Determine MIME type
            $mimeType = mime_content_type($filePath); 
            header("Content-Type: $mimeType");
            header("Content-Disposition: inline; filename=\"$fileName\"");

            // Output file
            echo $decryptData;
            exit;
        } else {
            echo "Error: Decryption failed.";
        }
    } else {
        echo "Error: File not found.";
    }
} else {
    echo "Error: No file specified.";
}
?>
