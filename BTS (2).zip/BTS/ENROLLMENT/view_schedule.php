<!-- View Schedule Modal -->
<div class="modal fade" id="viewScheduleModal" tabindex="-1" aria-labelledby="viewScheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewScheduleModalLabel">View Schedule Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="schedule_id" id="view_schedule_id">
                
                <p><strong>Batch Number:</strong> <span id="viewBatch"></span></p>
                <p><strong>Program:</strong> <span id="viewProgram"></span></p>
                <p><strong>Trainer:</strong> <span id="viewTrainer"></span></p>
                <p><strong>Start Date:</strong> <span id="viewStartDate"></span></p>
                <p><strong>End Date:</strong> <span id="viewEndDate"></span></p>
                <p><strong>Days:</strong> <span id="viewDays"></span></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const viewButtons = document.querySelectorAll('.view-btn');

        viewButtons.forEach(button => {
            button.addEventListener('click', function () {
                const program = this.getAttribute('data-program');
                const trainor = this.getAttribute('data-trainor');
                const batch = this.getAttribute('data-batch');
                const start = this.getAttribute('data-start');
                const end = this.getAttribute('data-end');
                const days = this.getAttribute('data-days');

                document.getElementById('viewProgram').innerText = program;
                document.getElementById('viewTrainer').innerText = trainor;
                document.getElementById('viewBatch').innerText = batch;
                document.getElementById('viewStartDate').innerText = start;
                document.getElementById('viewEndDate').innerText = end;
                document.getElementById('viewDays').innerText = days;
            });
        });
    });
</script>
