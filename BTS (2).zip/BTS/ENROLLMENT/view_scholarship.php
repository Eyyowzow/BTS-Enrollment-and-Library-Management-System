 <!-- View Scholarship Modal -->
 <div class="modal fade" id="viewScholarshipModal" tabindex="-1" aria-labelledby="viewScholarshipModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewScholarshipModalLabel">Edit Scholarship</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <input type="hidden" name="scholarship_id" id="view_scholarship_id">
                <p><strong>Scholarship Name:</strong> <span id="Name"></span></p>
                <p><strong>Amount:</strong> <span id="Amount"></span></p>
                <p><strong>Description:</strong> <span id="Desc"></span></p>

                <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Close</button>
                </div>        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.view-btn');

        viewButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                document.getElementById('Name').textContent = this.getAttribute('data-scholarship_name');
                document.getElementById('Amount').textContent = this.getAttribute('data-amount');
                document.getElementById('Desc').textContent = this.getAttribute('data-description');
        });
    });
});
</script>