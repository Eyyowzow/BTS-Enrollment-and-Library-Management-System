<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';

if (isset($_POST['addTrainor'])) {
    $first_name = encryptData(mysqli_real_escape_string($conn, $_POST['first_name']));
    $middle_name = encryptData(mysqli_real_escape_string($conn, $_POST['middle_name']));
    $last_name = encryptData(mysqli_real_escape_string($conn, $_POST['last_name']));
    $phone_number = encryptData(mysqli_real_escape_string($conn, $_POST['phone_number'])); 
    $email = encryptData(mysqli_real_escape_string($conn, $_POST['email']));
    $tesda_accreditation_number = encryptData(mysqli_real_escape_string($conn, $_POST['tesda_accreditation_number'])); 
    $expertise = encryptData(mysqli_real_escape_string($conn, $_POST['expertise']));

    // SQL query
    $sql = "INSERT INTO trainors (first_name, middle_name, last_name, contact_number, email, tesda_accreditation_no, expertise) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("sssssss", $first_name, $middle_name, $last_name, $phone_number, $email, $tesda_accreditation_number, $expertise);
        if ($stmt->execute()) {
            $success_message = 'Trainor Added Successfully!';
        } else {
            $error_message = 'Error Adding Trainor!';
        }
        $stmt->close();
    } 
}

if (isset($_POST['editTrainor'])) {
    $trainor_id = $_POST['trainor_id'];
    $tesda_accreditation_no = encryptData($_POST['tesda_accreditation_number']); 
    $first_name = encryptData($_POST['first_name']);
    $middle_name = encryptData($_POST['middle_name']);
    $last_name = encryptData($_POST['last_name']);
    $contact_number = encryptData($_POST['phone_number']);
    $email = encryptData($_POST['email']);
    $expertise = encryptData($_POST['expertise']);

    $sql = "UPDATE trainors SET tesda_accreditation_no=?, first_name=?, middle_name=?, last_name=?, contact_number=?, email=?, expertise=? WHERE trainor_id=?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sssssssi", $tesda_accreditation_no, $first_name, $middle_name, $last_name, $contact_number, $email, $expertise, $trainor_id);
        if ($stmt->execute()) {
            $success_message = 'Trainor Updated Successfully!';
        } else {
            $error_message = 'Error Updating Trainor!';
        }
        $stmt->close();
    } else {
        echo "<script>alert('Database error: " . $conn->error . "');</script>";
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <!-- Datatable -->
</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Trainor Masterlist</h4>
                            <span class="ml-1">Data Entry</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Program Button -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addTrainorModal">Add New Trainor
                                </button>
                        </ol>
                    </div>
                </div>
                <?php if ($success_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-account-search"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class='alert alert-danger'><?php echo $error_message; ?></div>
                <?php endif; ?>
                <!-- row -->

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Trainor Name</th>
                                                <th>Expertise</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $sql = "SELECT trainor_id, tesda_accreditation_no, first_name, middle_name, last_name, contact_number, email, expertise FROM trainors WHERE is_deleted = 0";
                                            $result = $conn->query($sql);
                                            $count = 1;
                                            
                                            if (!$result) {
                                                echo "<tr><td colspan='6'>Error fetching trainers: " . $conn->error . "</td></tr>";
                                            } else {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . decryptData($row['first_name']) . ' ' . decryptData($row['middle_name']) . ' ' . decryptData($row['last_name']) . "</td>";
                                                    echo "<td>" . decryptData($row['expertise']) . "</td>";
                                                    echo "<td>
                                                        <span>
                                                        <a href='edit_trainer.php' class='edit-btn'
                                                            data-id='{$row['trainor_id']}'
                                                            data-accreditation='" . decryptData($row['tesda_accreditation_no']) . "'
                                                            data-firstname='" . decryptData($row['first_name']) . "'
                                                            data-middlename='" . decryptData($row['middle_name']) . "'
                                                            data-lastname='" . decryptData($row['last_name']) . "'
                                                            data-number='" . decryptData($row['contact_number']) . "' 
                                                            data-email='" . decryptData($row['email']) . "' 
                                                            data-expertise='" . decryptData($row['expertise']) . "' 
                                                            data-toggle='modal' data-target='#editTrainorModal'>
                                                        <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                        </a>
                                                        
                                                        <a href='' class='view-btn'
                                                            data-id='{$row['trainor_id']}' 
                                                            data-tesda_accreditation_number='" . decryptData($row['tesda_accreditation_no']) . "'
                                                            data-first_name='" . decryptData($row['first_name']) . "'
                                                            data-middle_name='" . decryptData($row['middle_name']) . "'
                                                            data-last_name='" . decryptData($row['last_name']) . "'
                                                            data-phone_number='" . decryptData($row['contact_number']) . "' 
                                                            data-email='" . decryptData($row['email']) . "' 
                                                            data-expertise='" . decryptData($row['expertise']) . "' 
                                                            data-toggle='modal' data-target='#viewTrainorModal'>
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                                                        </a>

                                                        <a href='delete_trainer.php?trainor_id={$row['trainor_id']}' 
                                                            data-toggle='tooltip' data-placement='top' title='Delete' 
                                                            onclick=\"return confirm('Are you sure you want to delete this trainor?')\">
                                                        <i class='fa fa-trash' style='color: red; font-size: 15px;'></i> <!-- Blue -->
                                                        </a>
                                                        </span>
                                                    </td>";
                                                    echo "</tr>";
                                                }
                                            }
                                            
                                            
                                            ?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>Trainor Name</th>
                                                <th>Expertise</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                <!-- Add Trainor Modal --> 
                                <div class="modal fade" id="addTrainorModal" tabindex="-1" aria-labelledby="addTrainorModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="manage_trainer.php" method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addTrainorModalLabel">Add New Trainor</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="first_name">First Name</label>
                                                        <input type="text" class="form-control" name="first_name" required>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                        <label for="middle_name">Middle Name</label>
                                                        <input type="text" class="form-control" name="middle_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="last_name">Last Name</label>
                                                        <input type="text" class="form-control" name="last_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="phone_number">Phone Number</label>
                                                        <input type="text" class="form-control" name="phone_number" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="email">Email</label>
                                                        <input type="text" class="form-control" name="email" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="tesda_accreditation_number">TESDA Accreditation Number</label>
                                                        <input type="text" class="form-control" name="tesda_accreditation_number" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="expertise">Expertise</label>
                                                        <input type="text" class="form-control" name="expertise" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="addTrainor" class="btn btn-primary">Add Trainor</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="viewTrainorModal" tabindex="-1" aria-labelledby="viewTrainorModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="viewTrainorModalLabel">View Trainor</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                <input type="hidden" name="trainor_id" id="view_trainor_id">
                                                <p><strong>First Name:</strong> <span id="viewFName"></span></p>
                                                <p><strong>Middle Name:</strong> <span id="viewMName"></span></p>
                                                <p><strong>Last Name:</strong> <span id="viewLName"></span></p>
                                                <p><strong>Phone Number:</strong> <span id="viewPNum"></span></p>
                                                <p><strong>Email:</strong> <span id="viewEmail"></span></p>
                                                <p><strong>TESDA Accreditation Number:</strong> <span id="viewTAN"></span></p>
                                                <p><strong>Expertise:</strong> <span id="viewExpertise"></span></p>
                                                <div class="modal-footer">
                                                <button name="viewTrainor" type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Close</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div> 
                        </div>
                    </div>         
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    
    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 3000); 
        }
    };
    </script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const viewButtons = document.querySelectorAll('.view-btn');

            viewButtons.forEach(btn => {
                btn.addEventListener('click', function () {
                    document.getElementById('viewFName').textContent = this.getAttribute('data-first_name');
                    document.getElementById('viewMName').textContent = this.getAttribute('data-middle_name');
                    document.getElementById('viewLName').textContent = this.getAttribute('data-last_name');
                    document.getElementById('viewPNum').textContent = this.getAttribute('data-phone_number');
                    document.getElementById('viewEmail').textContent = this.getAttribute('data-email');
                    document.getElementById('viewTAN').textContent = this.getAttribute('data-tesda_accreditation_number');
                    document.getElementById('viewExpertise').textContent = this.getAttribute('data-expertise');
            });
        });
    });
    </script>
</body>

</html>

<?php
include 'edit_trainer.php';
?>
