<?php
include '../Database/Database.php';
include_once 'encryption.php';
if (isset($_GET['trainor_id'])) {
    $trainor_id = $_GET['trainor_id'];
    
    if (!empty($trainor_id)) {
        error_log("Fetching students for Trainor ID: " . $trainor_id);
        
        $sql = "
        SELECT e.id, s.ULI, 
               s.first_name,
               s.last_name, 
               s.gender,
               e.student_status 
        FROM enrollments e
        JOIN students s ON e.student_id = s.student_id
        JOIN trainors t ON e.trainor_id = t.trainor_id
        WHERE t.trainor_id = ?
        AND t.is_deleted = 0
        ";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $trainor_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $counter = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $counter++ . "</td>";
                echo "<td>" . decryptData($row['ULI']) . "</td>";
                echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</td>";
                echo "<td>" . decryptData($row['gender']) . "</td>";
                echo "<td>" . htmlspecialchars($row['student_status']) . "</td>";
                echo "<td><a href='edit_student.php?id=" . $row['id'] . "' >
                <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i>
                <tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No students found for this trainer</td></tr>";
        }
    }
}

?>
