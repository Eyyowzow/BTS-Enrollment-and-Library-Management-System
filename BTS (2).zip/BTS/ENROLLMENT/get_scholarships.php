<?php
include '../Database/Database.php';
include 'encryption.php';
$scholarship_query = "SELECT scholarship_id, scholarship_name FROM scholarships WHERE is_deleted = 0";
$result = $conn->query($scholarship_query);

$options = '<option value="">Select Scholarship</option>';
$options = '<option value="">N/A</option>';
//DROPDOWN
while ($row = $result->fetch_assoc()) {
    echo "<option value='" . $row['scholarship_id'] . "'>" . decryptData($row['scholarship_name']) . "</option>";
}

echo $options;
?>
