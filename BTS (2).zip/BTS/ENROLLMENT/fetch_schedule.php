<?php
include '../Database/Database.php';

if (isset($_POST['batch_no']) && isset($_POST['program']) && isset($_POST['trainor'])) {
    $batch = $_POST['batch_no'];
    $program = $_POST['program'];
    $trainer = $_POST['trainor'];

    $sql = "SELECT starts_date, end_date, days FROM schedules 
            WHERE batch_no = ? AND program_id = ? AND trainor_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $batch, $program, $trainer);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $schedule = $result->fetch_assoc();
        echo json_encode($schedule);
    } else {
        echo json_encode(array("error" => "No schedule found"));
    }
}
?>
