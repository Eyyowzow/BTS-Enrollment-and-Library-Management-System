<!-- Edit Scholarship Modal -->
<div class="modal fade" id="editScholarshipModal" tabindex="-1" aria-labelledby="editScholarshipModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="manage_scholarships.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editScholarshipModalLabel">Edit Scholarship</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <input type="hidden" name="scholarship_id" id="edit_scholarship_id">
                    <div class="form-group">
                        <label for="scholarshipName">Scholarship Name</label>
                        <input type="text" class="form-control" name="scholarship_name" id="edit_scholarship_name"  required>
                    </div>
                    <div class="form-group">
                        <label for="scholarshipDescription">Description</label>
                        <textarea class="form-control" name="description" id="edit_description"  required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="scholarshipAmount">Amount</label>
                        <input type="text" class="form-control" name="amount" id="edit_amount" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="editScholarship" class="btn btn-primary">Update Scholarship</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
    $('#editScholarshipModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget); 
        const scholarshipId = button.data('id');
        const scholarshipName = button.data('name');
        const scholarshipDescription = button.data('description');
        const scholarshipAmount = button.data('amount');
        
        const modal = $(this);
        modal.find('#edit_scholarship_id').val(scholarshipId);
        modal.find('#edit_scholarship_name').val(scholarshipName);
        modal.find('#edit_description').val(scholarshipDescription);
        modal.find('#edit_amount').val(scholarshipAmount); 
    
        });
    });
</script>