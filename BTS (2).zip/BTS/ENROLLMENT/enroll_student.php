<?php
session_start();
include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$program = $trainor = $batch_no = $starts_date = $end_date = $time_start = $time_end = $days = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $program = $_POST['program'];
    $trainor = $_POST['trainor'];
    $batch_no = $_POST['batch_no'];
    $starts_date = $_POST['starts_date'];
    $end_date = $_POST['end_date'];
    $days = $_POST['days'];
}

$program_query = "SELECT program_id, program_name, level, CONCAT(program_name, ' ', level) AS tesda_program FROM programs WHERE is_deleted = 0";
$trainor_query = "SELECT trainor_id, first_name, last_name, CONCAT(first_name, ' ', last_name) AS trainor_name FROM trainors WHERE is_deleted = 0";
$date_query = "SELECT schedule_id, CONCAT(starts_date, ' - ', end_date) AS date_span FROM schedules WHERE is_deleted = 0";

$programs = $conn->query($program_query);
$trainors = $conn->query($trainor_query);
$schedules = $conn->query($date_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <!-- Form step -->
    <style>
    /* Ensure the suggestion list matches input box styling */
    .student-item {
        border-bottom: 1px solid #ddd;
    }

    .student-item:last-child {
        border-bottom: none;  /* No border for the last item */
    }

    .student-item.highlight {
        background-color: #007bff;
        color: white;
    }

    #studentList {
        font-size: 16px;
        line-height: 1.5;
    }
</style>
</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Enroll Student</h4>
                            <p class="mb-0">Transaction</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active"><a href="./index.php">Back</a></li>
                        </ol>
                    </div>
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card">
                            <div class="card-header">
                            </div>
                            <div class="card-body">
                                <form method="POST" action="enrolled_masterlist.php" >
                                    <div>
                                        <div class="row">
                                            <div class="col-lg-12 mb-12">
                                            <center><h4>ENROLLMENT FORM</h4></center>
                                            <hr>
                                            </div>
                                            <div class="col-lg-12 mb-12">
                                            <h6 class="text-primary">PERSONAL INFORMATION</h6>
                                            </div>
                                            <div class="col-lg-12 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="student_name">Student's Name</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                    <input type="text" id="student_name" class="form-control" name="student_name" placeholder="Search Student Name" autocomplete="off" required>
                                                    <input type="hidden" name="student_id" id="student_id" value="">

                                                    <div class="input-group" style="position: relative;">
                                                    <ul id="studentList" 
                                                    class="form-control"
                                                    style="list-style-type: none; padding: 0; margin: 0; 
                                                            position: absolute; width: 100%; z-index: 1000; 
                                                            background: white; border: 1px solid #ccc; border-radius: 0 0 5px 5px;
                                                            max-height: 200px; overflow-y: auto; display: none;">
                                                    </ul>
                                                    </div>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="educational_attainment">Educational Attainment</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                    <select class="form-control" id ="educational_attainment" name="educational_attainment" required>
                                                        <option value="">Select</option>
                                                        <option>NA</option>
                                                        <option>Primary Education</option>
                                                        <option>Secondary Education</option>
                                                        <option>Post-Secondary Education</option>
                                                        <option>Tertiary Education</option>
                                                        <option>Graduate</option>
                                                    </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label">Employment Before Training</label>
                                                    <div class="input-group">
                                                        <input type="text" name="employment" class="form-control" placeholder="Employment Before Training">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 mb-4">
                                                <div class="form-group">
                                                    <label class="text-label" for="scholarship">Scholarship</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                        <select class="form-control" id="scholarship" name="scholarship">
                                                            <option value="">Select Scholarship</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-12">
                                                <center><h6 class="text-primary">TESDA PROGRAM</h6></center>
                                            </div>
                                            <div class="col-lg-1 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="batch_no">Batch</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                    <select class="form-control" id="batch_no" name="batch_no" required>
                                                        <option value="">Select Batch</option>
                                                        <?php 
                                                        $batches = $conn->query("SELECT DISTINCT batch_no FROM schedules"); 
                                                        while ($row = $batches->fetch_assoc()): ?>
                                                            <option value="<?php echo $row['batch_no']; ?>"><?php echo htmlspecialchars($row['batch_no']); ?></option>
                                                        <?php endwhile; ?>
                                                    </select>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="program">Program</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                        <select class="form-control" id="program" name="program" required>
                                                        <option value="">Select Program</option>
                                                        <?php while ($row = $programs->fetch_assoc()): ?>
                                                                <option value="<?php echo $row['program_id']; ?>"><?php echo decryptData($row['program_name']) . " " . decryptData($row['level']); ?></option>
                                                            <?php endwhile; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="trainor">Trainor</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                        <select class="form-control" id="trainor" name="trainor" required>
                                                        <option value="">Select Trainor</option>
                                                        <?php while ($row = $trainors->fetch_assoc()): ?>
                                                                <option value="<?php echo $row['trainor_id']; ?>"><?php echo decryptData($row['first_name']) . " " . decryptData($row['last_name']); ?></option>
                                                            <?php endwhile; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-12">
                                                <div class="form-group">
                                                <label class="text-label" for="date">Date</label>
                                                <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                        <select class="form-control" id="date" name="date" required>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-2 mb-12">
                                                <div class="form-group">
                                                    <label class="text-label" for="days">Days</label>
                                                    <span class="text-danger">*</span>
                                                    <div class="input-group">
                                                        <select class="form-control" id="days" name="days" required>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>

                                    <div>
                                        <center><button type="submit" class="btn btn-primary">  Enroll Student  </button></center>
                                    </div> 
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    <script src="../bootstrap/js/cursor.js"></script>
    <script src="../bootstrap/vendor/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="../bootstrap/vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Form validate init -->
    <script src="../bootstrap/js/plugins-init/jquery.validate-init.js"></script>
    <!-- Form step init -->
    <script src="../bootstrap/js/plugins-init/jquery-steps-init.js"></script>

<!-- Fetching Script -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
// Student Name
$(document).ready(function() {
    $('#student_name').keyup(function() {
        let query = $(this).val();
        if (query != '') {
            $.ajax({
                url: "fetch_data.php",
                method: "POST",
                data: { query: query, type: 'student' },
                success: function(data) {
                    $('#studentList').fadeIn();
                    $('#studentList').html(data);
                }
            });
        } else {
            $('#studentList').fadeOut();
        }
    });

    //ULI
    $(document).on('click', '#studentList li', function() {
        $('#student_name').val($(this).text());
        $('#uli').val($(this).data('uli'));
        $('#studentList').fadeOut();
    }); 

    $(document).click(function(event) {
        if (!$(event.target).closest('#student_name, #studentList').length) {
            $('#studentList').fadeOut();
        }
    });
});

// Scholarship
$.ajax({
    url: 'get_scholarships.php', 
    method: 'GET',
    success: function(response) {
        $('#scholarship').html(response);
    }
});


// Batch Number
$.ajax({
    url: 'get_batches.php', 
    method: 'GET',
    success: function(response) {
        $('#batch_no').html(response);
    }
});

// Programs
$('#batch_no').on('change', function() {
    var batchNo = $(this).val();
    if (batchNo) {
        $.ajax({
        url: 'get_programs.php',
        method: 'POST',
        data: { batch_no: batchNo },
        success: function(response) {
            $('#program').html(response);
            }
        });
    }
});

// Trainer/Trainor haha
$('#program').on('change', function() {
    var programId = $(this).val();
    var batchNo = $('#batch_no').val();
    if (programId) {
        $.ajax({
            url: 'get_trainors.php',
            method: 'POST',
            data: { program_id: programId },
            success: function(response) {
                $('#trainor').html(response);
            }
        });
    }
});

// Autoselect Date/Tim/eDays
$('#trainor').on('change', function() {
    var trainorID = $(this).val();
    var batchNo = $('#batch_no').val();
    var programID = $('#program').val();
    
    if (trainorID && batchNo && programID) {
        $.ajax({
            url: 'get_schedule_details.php',
            method: 'POST',
            data: { 
                trainor_id: trainorID, 
                batch_no: batchNo, 
                program_id: programID 
            },
            success: function(response) {
                var data = JSON.parse(response);
                $('#date').html(data.dates); 
                $('#days').html(data.days);  
            }
        });
    }
});

</script>
<script>
    document.getElementById('studentList').addEventListener('click', function (e) {
    if (e.target.tagName === 'LI') {
        const studentId = e.target.getAttribute('data-id');
        document.getElementById('student_id').value = studentId;
    }
});

</script>
</body>
</html>