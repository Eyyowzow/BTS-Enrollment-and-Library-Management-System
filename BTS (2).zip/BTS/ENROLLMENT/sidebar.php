
<div class="quixnav">
    <div class="quixnav-scroll">
        <ul class="metismenu" id="menu">
            <!-- Dashboard -->
            <li class="nav-label first">Main Menu</li>
            <li><a href="./index.php"><i class="icon icon-home"></i><span class="nav-text">Dashboard</span></a>
            </li> 
            <!-- Transactions -->
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                class="icon icon-form"></i><span class="nav-text">Transaction</span></a>
        <ul aria-expanded="false">
            <!-- TESDA Training -->
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Add New</a>
                <ul aria-expanded="false">
                <li><a href="./register_student.php">Register Student</a></li>
                <li><a href="./enroll_student.php">Enroll Student</a></li>
        </ul>
        </li>

            <!-- List -->
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">List</a>
                <ul aria-expanded="false">
                <li><a href="./manage_students.php">Registered Student</a></li>
                <li><a href="./enrolled_masterlist.php">Enrolled Student</a></li>
            </ul>
            </li>
            </ul>
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                class="icon icon-layout-25"></i><span class="nav-text">Data Entry</span></a>
            <ul aria-expanded="false">
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">TESDA Training</a>
                <ul aria-expanded="false">
                    
                <li><a href="./manage_assessments.php">Assessment</a></li>
                <li><a href="./manage_programs.php">Program</a></li>
            </ul>
            </li>
                <li><a href="./manage_trainer.php">Trainor</a></li>
                <li><a href="./manage_schedules.php">Schedule</a></li>
                <li><a href="./manage_scholarships.php">Scholarship</a></li>
            </ul>
            </li>

            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                        class="icon icon-chart-bar-33"></i><span class="nav-text">Records and Reports</span></a>
                <ul aria-expanded="false">
                    <li><a href="./student_record.php">Student Record</a></li>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Student List</a>
                        <ul aria-expanded="false">
                        <li><a href="./studlist_trainor.php">Student List per Trainor</a></li>
                        <li><a href="./studlist_program.php">Student List per Program</a></li>
                        <li><a href="./studlist_assessment.php">Student List per Assessment</a></li>
                        <li><a href="./studlist_scholarship.php">Student List per Scholarship</a></li>
                    </ul>
                    </li>
                </ul>
            </li>
            <?php if ($_SESSION['role'] === 'Administrator') : ?>
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                        class="icon icon-settings"></i><span class="nav-text">Settings</span></a>
                <ul aria-expanded="false">
                    <li><a href="./user_settings.php">User Settings</a></li>
                    <li><a href="./school_settings.php">School Settings</a></li>
                    <li><a href="./backup_restore.php">Trash Bin</a></li>
                    <li><a href="./backup.php">BackUp</a></li>


                </ul>
            </li>
            <?php endif; ?>
            <?php if ($_SESSION['role'] === 'Administrator') : ?>
            <?php endif; ?>
            <li><a href="../login.php" aria-expanded="false">
                <i class="icon icon-plug"></i><span class="nav-text">Logout</span></a>
            </li>
        </ul>
    </div>
</div>