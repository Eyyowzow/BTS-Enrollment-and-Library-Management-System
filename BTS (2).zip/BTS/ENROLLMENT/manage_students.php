<?php 
session_start();
include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$alert_message = ""; 
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['addStudent'])) {
        // Personal Details
        $ULI = encryptData(mysqli_real_escape_string($conn, $_POST['uli']));
        $first_name = encryptData(mysqli_real_escape_string($conn, $_POST['first_name']));
        $middle_name = encryptData(mysqli_real_escape_string($conn, $_POST['middle_name']));
        $last_name = encryptData(mysqli_real_escape_string($conn, $_POST['last_name']));
        $birth_place = encryptData(mysqli_real_escape_string($conn, $_POST['birth_place']));
        $birth_date = encryptData(mysqli_real_escape_string($conn, $_POST['birth_date']));
        $gender = encryptData(mysqli_real_escape_string($conn, $_POST['gender']));
        $marital_status = encryptData(mysqli_real_escape_string($conn, $_POST['marital_status']));
        $citizenship = encryptData(mysqli_real_escape_string($conn, $_POST['citizenship']));

        // Personal Contact Information
        $email = encryptData(mysqli_real_escape_string($conn, $_POST['email']));
        $fb_account = encryptData(mysqli_real_escape_string($conn, $_POST['fb_account']));
        $phone_number = encryptData(mysqli_real_escape_string($conn, $_POST['phone_number']));

        // Parent/Guardian Information
        $parent_firstname = encryptData(mysqli_real_escape_string($conn, $_POST['parent_firstname']));
        $parent_lastname = encryptData(mysqli_real_escape_string($conn, $_POST['parent_lastname']));
        $parent_middlename = encryptData(mysqli_real_escape_string($conn, $_POST['parent_middlename']));
        $parent_phone = encryptData(mysqli_real_escape_string($conn, $_POST['parent_phone']));

        // Current Address
        $street_number = encryptData(mysqli_real_escape_string($conn, $_POST['street_number']));
        $street_name = encryptData(mysqli_real_escape_string($conn, $_POST['street_name']));
        $subdivision = encryptData(mysqli_real_escape_string($conn, $_POST['subdivision']));
        $barangay = encryptData(mysqli_real_escape_string($conn, $_POST['barangay']));
        $city = encryptData(mysqli_real_escape_string($conn, $_POST['city']));
        $province = encryptData(mysqli_real_escape_string($conn, $_POST['province']));

        // Requirements Checkboxes
        $form_137 = isset($_POST['form_137']) ? '1' : '0';
        $report_card = isset($_POST['report_card']) ? '1' : '0';
        $diploma = isset($_POST['diploma']) ? '1' : '0';
        $completion_cert = isset($_POST['completion_cert']) ? '1' : '0';
        $transcript_records = isset($_POST['transcript_records']) ? '1' : '0';
        $birth_cert = isset($_POST['birth_cert']) ? '1' : '0';
        $marriage_cert = isset($_POST['marriage_cert']) ? '1' : '0';
        $id_photo = isset($_POST['id_photo']) ? '1' : '0';
        $status = isset($_POST['status']) ? mysqli_real_escape_string($conn, $_POST['status']) : '';
        $targetDir = "../attached_files/";
$attached = ""; 

// Define encryption key and initialization vector (IV)
$encryptionKey = 'your-encryption-key-32-chars'; // Make sure this is 32 characters for AES-256
$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc')); // Generate a random IV

if (isset($_FILES['attached']) && $_FILES['attached']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = '../uploads/';
    $tmpName = $_FILES['attached']['tmp_name'];
    $fileName = basename($_FILES['attached']['name']);
    $uploadFile = $uploadDir . $fileName;

    // Read file contents
    $fileContents = file_get_contents($tmpName);

    // Encrypt the file contents
    $encryptedData = openssl_encrypt($fileContents, 'aes-256-cbc', $encryptionKey, 0, $iv);

    // Combine IV and encrypted data for storage
    $dataToSave = base64_encode($iv . $encryptedData);

    // Save the encrypted data to the target directory
    if (file_put_contents($uploadFile, $dataToSave) !== false) {
        $attached = $fileName; 
    } else {
        $error_message = "File upload failed.";
    }
}


        // SQL Insert Query
        $sql = "INSERT INTO students (ULI, first_name, middle_name, last_name, birth_place, birth_date, gender, marital_status, citizenship, email, fb_account, phone_number, parent_firstname,
                parent_lastname, parent_middlename, parent_phone, street_number, street_name, subdivision, barangay, city, province, attached, form_137, report_card, diploma, completion_cert, transcript_records, birth_cert, marriage_cert, id_photo, status)
                VALUES ('$ULI', '$first_name', '$middle_name', '$last_name', '$birth_place', '$birth_date', '$gender', '$marital_status', '$citizenship', '$email', '$fb_account', '$phone_number', '$parent_firstname',
                '$parent_lastname', '$parent_middlename', '$parent_phone', '$street_number', '$street_name', '$subdivision', '$barangay', '$city', '$province', '$attached', '$form_137', '$report_card', '$diploma',
                '$completion_cert', '$transcript_records','$birth_cert', '$marriage_cert', '$id_photo', '$status')";

        if (mysqli_query($conn, $sql)) {
            $alert_message = "Student Added Successfully!"; 
        } else {
            $error_message = 'Error Adding Student!';
        }
    } 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['editStudent'])) {
        $student_id = $_POST['studentId']; 
        $uli = encryptData($_POST['uli']);
        
        $first_name = encryptData($_POST['firstName']);
        $middle_name = encryptData($_POST['middleName']);
        $last_name = encryptData($_POST['lastName']);
        $birth_place = encryptData($_POST['birthPlace']);
        $birth_date = encryptData($_POST['birthDate']);
        $gender = encryptData($_POST['gender']);
        $marital_status = encryptData($_POST['maritalStatus']);
        $citizenship = encryptData($_POST['citizenship']);
        $email = encryptData($_POST['email']);
        $fb_account = encryptData($_POST['fbAccount']);
        $phone_number = encryptData($_POST['phoneNumber']);
        $parent_lastname = encryptData($_POST['parentLastName']);
        $parent_firstname = encryptData($_POST['parentFirstName']);
        $parent_middlename = encryptData($_POST['parentMiddleName']);
        $parent_contact = encryptData($_POST['parentPhone']);
        $street_number = encryptData($_POST['streetNumber']);
        $street_name = encryptData($_POST['streetName']);
        $subdivision = encryptData($_POST['subdivision']);
        $barangay = encryptData($_POST['barangay']);
        $city = encryptData($_POST['city']);
        $province = encryptData($_POST['province']);

        $form_137 = isset($_POST['form137']) ? 1 : 0; 
        $report_card = isset($_POST['reportCard']) ? 1 : 0;
        $diploma = isset($_POST['diploma']) ? 1 : 0;
        $completion_cert = isset($_POST['completionCert']) ? 1 : 0;
        $transcript_records = isset($_POST['transcript']) ? 1 : 0;
        $birth_cert = isset($_POST['birthCert']) ? 1 : 0;
        $marriage_cert = isset($_POST['marriageCert']) ? 1 : 0;
        $id_photo = isset($_POST['idPhoto']) ? 1 : 0;
        
        $sql = "UPDATE students SET 
                ULI = ?, first_name = ?, middle_name = ?, last_name = ?, birth_place = ?, birth_date = ?, 
                gender = ?, marital_status = ?, citizenship = ?, email = ?, fb_account = ?, phone_number = ?, 
                parent_lastname = ?, parent_firstname = ?, parent_middlename = ?, parent_phone = ?, street_number = ?,  
                street_name = ?, subdivision = ?, barangay = ?, city = ?, province = ?, form_137 = ?, report_card = ?, diploma = ?, 
                completion_cert = ?, transcript_records = ?, birth_cert = ?, marriage_cert = ?, id_photo = ? WHERE student_id = ?";

        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("ssssssssssssssssssssssssssssssi", 
                $uli, $first_name, $middle_name, $last_name, $birth_place, $birth_date, $gender, $marital_status,  $citizenship, $email, 
                $fb_account, $phone_number, $parent_lastname, $parent_firstname, $parent_middlename, $parent_contact, $street_number, 
                $street_name, $subdivision, $barangay, $city, $province, $form_137, 
                $report_card, $diploma, $completion_cert, $transcript_records, 
                $birth_cert, $marriage_cert, $id_photo, $student_id);

            if ($stmt->execute()) {
                $alert_message = "Student Updated Successfully!"; 
            } else {
                $error_message = 'Error Updating Student!';
            }
        } else {
            echo "<script>alert('Database error: " . $conn->error . "');</script>";
        }
    } 
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <!-- Datatable -->
</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Student Masterlist</h4>
                            <p class="mb-0">Data Entry</p>
                        </div>
                    </div><div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Student Button -->
                            <a href="./register_student.php"><button type="button" class="btn btn-primary">Add New Student
                                </button></a>
                        </ol>
                    </div>
                </div>
                <?php if ($alert_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-account-search"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $alert_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class='alert alert-danger'><?php echo $error_message; ?></div>
                <?php endif; ?>
                <!-- row -->


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student Name</th>
                                                <th>Gender</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php  
                                            $sql = "SELECT student_id, ULI, first_name, last_name, middle_name, 
                                                    CONCAT(first_name, ' ', last_name) AS full_name, birth_place, 
                                                    birth_date, gender, marital_status, citizenship, email, fb_account, 
                                                    phone_number, parent_lastname, parent_firstname, parent_middlename, 
                                                    parent_phone, street_number, street_name, subdivision, barangay, 
                                                    city, province, attached, form_137, report_card, diploma, completion_cert, 
                                                    transcript_records, birth_cert, marriage_cert, id_photo, status 
                                                    FROM students WHERE is_deleted = 0";

                                            $result = mysqli_query($conn, $sql);
                                            $count = 1;

                                            if (!$result) {
                                                echo "Error executing query: " . mysqli_error($conn);
                                                exit;
                                            }

                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . decryptData($row['ULI']) . "</td>";
                                                    echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</td>"; 
                                                    echo "<td>" . decryptData($row['gender']) . "</td>"; 
                                                    echo "<td>
                                                            <span>
                                                                <a href='edit_student.php' class='edit-btn'
                                                                    data-id='{$row['student_id']}'
                                                                    data-uli='" . decryptData($row['ULI']) . "' 
                                                                    data-lastname='" . decryptData($row['last_name']) . "' 
                                                                    data-firstname='" . decryptData($row['first_name']) . "' 
                                                                    data-middlename='" . decryptData($row['middle_name']) . "' 
                                                                    data-birthplace='" . decryptData($row['birth_place']) . "' 
                                                                    data-birthdate='" . decryptData($row['birth_date']) . "' 
                                                                    data-gender='" . decryptData($row['gender']) . "'
                                                                    data-status='" . decryptData($row['marital_status']) . "' 
                                                                    data-citizenship='" . decryptData($row['citizenship']) . "' 
                                                                    data-email='" . decryptData($row['email']) . "' 
                                                                    data-account='" . decryptData($row['fb_account']) . "' 
                                                                    data-phonenumber='" . decryptData($row['phone_number']) . "' 
                                                                    data-plastname='" . decryptData($row['parent_lastname']) . "' 
                                                                    data-pfirstname='" . decryptData($row['parent_firstname']) . "' 
                                                                    data-pmiddlename='" . decryptData($row['parent_middlename']) . "' 
                                                                    data-pcontact='" . decryptData($row['parent_phone']) . "' 
                                                                    data-streetnumber='" . decryptData($row['street_number']) . "' 
                                                                    data-streetname='" . decryptData($row['street_name']) . "' 
                                                                    data-subdivision='" . decryptData($row['subdivision']) . "' 
                                                                    data-barangay='" . decryptData($row['barangay']) . "'  
                                                                    data-city='" . decryptData($row['city']) . "'  
                                                                    data-province='" . decryptData($row['province']). "'  
                                                                    data-form137='{$row['form_137']}'  
                                                                    data-report9='{$row['report_card']}' 
                                                                    data-diploma='{$row['diploma']}'  
                                                                    data-completioncert='{$row['completion_cert']}' 
                                                                    data-transcript='{$row['transcript_records']}'  
                                                                    data-psabirth='{$row['birth_cert']}' 
                                                                    data-psamarriage='{$row['marriage_cert']}' 
                                                                    data-passportsizeid='{$row['id_photo']}'
                                                                    data-toggle='modal' title='Edit' data-target='#editStudent'> 
                                                                    <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                                </a>
                                                                <a href='#' class='view-btn' 
                                                                    title='View' data-toggle='modal' data-target='#viewModal' 
                                                                    data-id='{$row['student_id']}' 
                                                                    data-uli='" . decryptData($row['ULI']) . "' 
                                                                    data-lastname='" . decryptData($row['last_name']) . "' 
                                                                    data-firstname='" . decryptData($row['first_name']) . "' 
                                                                    data-middlename='" . decryptData($row['middle_name']) . "' 
                                                                    data-birthplace='" . decryptData($row['birth_place']) . "' 
                                                                    data-birthdate='" . decryptData($row['birth_date']) . "' 
                                                                    data-gender='" . decryptData($row['gender']) . "' 
                                                                    data-status='" . decryptData($row['marital_status']) . "' 
                                                                    data-citizenship='" . decryptData($row['citizenship']) . "'  
                                                                    data-email='" . decryptData($row['email']) . "' 
                                                                    data-account='" . decryptData($row['fb_account']) . "' 
                                                                    data-phonenumber='" . decryptData($row['phone_number']) . "' 
                                                                    data-plastname='" . decryptData($row['parent_lastname']) . "' 
                                                                    data-pfirstname='" . decryptData($row['parent_firstname']) . "' 
                                                                    data-pmiddlename='" . decryptData($row['parent_middlename']) . "' 
                                                                    data-pcontact='" . decryptData($row['parent_phone']) . "' 
                                                                    data-streetnumber='" . decryptData($row['street_number']) . "' 
                                                                    data-streetname='" . decryptData($row['street_name']) . "' 
                                                                    data-subdivision='" . decryptData($row['subdivision']) . "' 
                                                                    data-barangay='" . decryptData($row['barangay']) . "'  
                                                                    data-city='" . decryptData($row['city']) . "'  
                                                                    data-province='" . decryptData($row['province']). "'                                          
                                                                    data-attachedFiles='" . decryptData($row['attached']). "'  
                                                                    data-form137='{$row['form_137']}'  
                                                                    data-form9='{$row['report_card']}'  
                                                                    data-diploma='{$row['diploma']}'  
                                                                    data-completioncert='{$row['completion_cert']}' 
                                                                    data-transcript='{$row['transcript_records']}'  
                                                                    data-psabirth='{$row['birth_cert']}'  
                                                                    data-psamarriage='{$row['marriage_cert']}'  
                                                                    data-passportsizeid='{$row['id_photo']}'> 
                                                                    <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                                                                </a>
                                                                <a href='delete_student.php?student_id={$row['student_id']}' 
                                                                    data-toggle='tooltip' data-placement='top' title='Delete' 
                                                                    onclick=\"return confirm('Are you sure you want to delete this student?')\"> 
                                                                    <i class='fa fa-trash' style='color: red; font-size: 15px;'></i> <!-- Blue -->
                                                                </a>                                                    
                                                            </span>
                                                        </td>";      
                                                        echo "</tr>";
                                                        }
                                                    }
                                                ?>
                                            </tbody>
                                            

                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Student Name</th>
                                                <th>Gender</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                <!-- View Modal -->
                                <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="viewModalLabel">Student Details</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>ULI:</strong> <span id="viewULI"></span></p>
                                                <p><strong>Full Name:</strong> <span id="viewFullName"></span></p>
                                                <p><strong>Birthplace:</strong> <span id="viewBirthPlace"></span></p>
                                                <p><strong>Birthdate:</strong> <span id="viewBirthDate"></span></p>
                                                <p><strong>Gender:</strong> <span id="viewGender"></span></p>
                                                <p><strong>Marital Status:</strong> <span id="viewMaritalStatus"></span></p>
                                                <p><strong>Citizenship:</strong> <span id="viewCitizenship"></span></p>
                                                <p><strong>Email:</strong> <span id="viewEmail"></span></p>
                                                <p><strong>Phone Number:</strong> <span id="viewPhoneNumber"></span></p>
                                                <p><strong>Parent/Guardian:</strong> <span id="viewParent"></span></p>
                                                <p><strong>Address:</strong> <span id="viewAddress"></span></p>
                                                <p><strong>Attached File:</strong> <span id="viewAttached"></span></p>
                                                <p><strong>Requirements:</strong> <span id="viewRequirements"></span></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>

    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.view-btn');

    viewButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            document.getElementById('viewULI').textContent = this.getAttribute('data-uli');
            document.getElementById('viewFullName').textContent = `${this.getAttribute('data-firstname')} ${this.getAttribute('data-middlename')} ${this.getAttribute('data-lastname')}`;
            document.getElementById('viewBirthPlace').textContent = this.getAttribute('data-birthplace');
            document.getElementById('viewBirthDate').textContent = this.getAttribute('data-birthdate');
            document.getElementById('viewGender').textContent = this.getAttribute('data-gender');
            document.getElementById('viewMaritalStatus').textContent = this.getAttribute('data-status');
            document.getElementById('viewCitizenship').textContent = this.getAttribute('data-citizenship');
            document.getElementById('viewEmail').textContent = this.getAttribute('data-email');
            document.getElementById('viewPhoneNumber').textContent = this.getAttribute('data-phonenumber');
            document.getElementById('viewParent').textContent = `${this.getAttribute('data-pfirstname')} ${this.getAttribute('data-pmiddlename')} ${this.getAttribute('data-plastname')}`;
            document.getElementById('viewAddress').textContent = `${this.getAttribute('data-streetnumber')} ${this.getAttribute('data-streetname')}, ${this.getAttribute('data-subdivision')}, ${this.getAttribute('data-barangay')}, ${this.getAttribute('data-city')}, ${this.getAttribute('data-province')}`;
            document.getElementById('viewRequirements').textContent = `Form 137: ${this.getAttribute('data-form137')}, Report Card: ${this.getAttribute('data-reportcard')}, Diploma: ${this.getAttribute('data-diploma')}, Completion Certificate: ${this.getAttribute('data-completioncert')}, Transcript: ${this.getAttribute('data-transcript')}, Birth Certificate: ${this.getAttribute('data-birthcert')}, Marriage Certificate: ${this.getAttribute('data-marriagecert')}, ID Photo: ${this.getAttribute('data-idphoto')}`;

            const attachedFiles = this.getAttribute('data-attachedFiles').split(',').filter(file => file.trim() !== '');
            if (attachedFiles.length > 0) {
                const attachedFileLinks = attachedFiles.map(file => `<a href="view_file.php?file=${encodeURIComponent(file.trim())}" target="_blank">${file.trim()}</a>`).join('<br>');
                document.getElementById('viewAttached').innerHTML = attachedFileLinks;
            } else {
                document.getElementById('viewAttached').innerHTML = 'No attached files.';
            }
        });
    });
});
</script>
      

    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 5000); 
        }
    };
    </script>
  
</body>
</html>
<!-- CODE FOR EDITIN STUDEN INFORMATIONS -->
<?php include 'edit_student.php'; include 'view_file.php';?>