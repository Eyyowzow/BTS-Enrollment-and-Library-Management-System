<?php
include '../Database/Database.php';
include 'encryption.php';

if (isset($_POST['program_id'])) {
    $program_id = $_POST['program_id'];
    $query = "SELECT DISTINCT t.trainor_id, t.first_name, t.last_name,
              CONCAT(t.first_name, ' ', t.last_name) AS trainor_name 
              FROM trainors t 
              JOIN schedules s ON t.trainor_id = s.trainor_id 
              WHERE s.program_id = ?
              AND s.is_deleted = 0";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $program_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $options = '<option value="">Select Trainor</option>';
    while ($row = $result->fetch_assoc()) {
        $options .= '<option value="' . $row['trainor_id'] . '">' . decryptData($row['first_name']) . " " . decryptData($row['last_name']) .'</option>';
    }
    echo $options;
}
?>
