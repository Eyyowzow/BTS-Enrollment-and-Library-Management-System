<?php
session_start();

include 'header.php';
include 'sidebar.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>


</head>

<body>
       <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Student List per Assessment</h4>
                            <span class="ml-1">Records and Reports</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                        <h5 for="assessment_search">Search Assessment:</h5>
                            <input type="text" id="assessment_search" class="form-control" name="assessment_search" autocomplete="off">
                            <ul id="assessment_list" style="list-style-type: none;"></ul>
                        </ol>
                    </div>
                </div>
                <!-- row -->

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Name</th>
                                                <th>Gender</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="students_body">
                                        
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>ULI</th>
                                                <th>Name</th>
                                                <th>Gender</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    

<!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>

    <script>
    $(document).ready(function() {
        $('#assessment_search').on('keyup', function() {
            let query = $(this).val().trim(); 
            if (query !== '') {
                $.ajax({
                    url: 'search_assessments.php',
                    method: 'POST',
                    data: {query: query},
                    success: function(data) {
                        $('#assessment_list').fadeIn();
                        $('#assessment_list').html(data);
                    },
                    error: function() {
                        console.error("Failed to fetch trainers"); 
                    }
                });
            } else {
                $('#assessment_list').fadeOut();  
            }
        });

        // Dropdown
        $(document).on('click', '#assessment_list li', function() {
        let assessment_id = $(this).data('assessment_id');
        let assessment_name = $(this).text();
        $('#assessment_search').val(assessment_name);
        $('#assessment_list').fadeOut();

        console.log("Selected Trainor ID: ", assessment_id); 

        $.ajax({
            url: 'fetch_assessmentlist.php',
            method: 'GET',
            data: {assessment_id: assessment_id},
            success: function(data) {
                $('#students_body').html(data);
            },
            error: function() {
                console.error("Failed to fetch student list");
            }
        });
    });

    });
    </script>




</body>

</html>