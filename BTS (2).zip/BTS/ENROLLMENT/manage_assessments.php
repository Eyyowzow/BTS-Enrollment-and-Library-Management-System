<?php
session_start();
include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';

if (isset($_POST['addAssessment'])) {
    $assessment_name = encryptData(mysqli_real_escape_string($conn,$_POST['assessment_name']));
    $assessment_level = encryptData(mysqli_real_escape_string($conn,$_POST['assessment_level']));
    $assessment_date = encryptData(mysqli_real_escape_string($conn,$_POST['assessment_date']));
    $competency_title = encryptData(mysqli_real_escape_string($conn,$_POST['competency_title']));
    $assessor = encryptData(mysqli_real_escape_string($conn,$_POST['assessor']));
    $location = encryptData(mysqli_real_escape_string($conn,$_POST['location']));

    $sql = "INSERT INTO assessments (assessment_name, assessment_level, assessment_date, competency_title, assessor, location) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("ssssss", $assessment_name, $assessment_level, $assessment_date, $competency_title, $assessor, $location);
        if ($stmt->execute()) {
            $success_message = 'Asessment Added Successfully!';
        } else {
            $error_message = 'Error Adding Assessment!';
        }
        $stmt->close();
    } 
}
if (isset($_POST['editAssessment'])) {
    $assessment_id = $_POST['assessment_id'];
    $assessment_name = encryptData($_POST['assessment_name']);
    $assessment_level = encryptData($_POST['assessment_level']);
    $assessment_date = encryptData($_POST['assessment_date']);
    $competency_title = encryptData($_POST['competency_title']);
    $assessor = encryptData($_POST['assessor']);
    $location = encryptData($_POST['location']);

    $sql = "UPDATE assessments SET assessment_name=?, assessment_level=?, assessment_date=?, competency_title=?, assessor=?, location=? WHERE assessment_id=?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ssssssi", $assessment_name, $assessment_level, $assessment_date, $competency_title, $assessor, $location, $assessment_id);
        if ($stmt->execute()) {
            $success_message = 'Asessment Updated Successfully!';
        } else {
            $error_message = 'Error Updating Asessment!';
        }
        $stmt->close();
    } else {
        echo "<script>alert('Database error: " . $conn->error . "');</script>";
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <!-- Datatable -->
</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>Assessment Masterlist</h4>
                            <p class="mb-0">Data Entry</p>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <!-- Add New Assessment Button -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addAssessmentModal">Add New Assessment
                                </button>
                        </ol>
                    </div>
                </div>
                <?php if ($success_message): ?>
                    <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                        <span><i class="mdi mdi-check"></i></span>
                        <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                            <span><i class="mdi mdi-close"></i></span>
                        </button> 
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class='alert alert-danger'><?php echo $error_message; ?></div>
                <?php endif; ?>
                <!-- row -->


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Assessment Name</th>
                                                <th>Assessment Level</th>
                                                <th>Assessor Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $sql = "SELECT * FROM assessments WHERE is_deleted = 0";
                                            $result = $conn->query($sql);
                                            $count = 1;
                                            if (!$result) {
                                                echo "<tr><td colspan='6'>Error fetching assessments: " . $conn->error . "</td></tr>";
                                            } else {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . decryptData($row['assessment_name']) . "</td>";
                                                    echo "<td>" . decryptData($row['assessment_level']) . "</td>";
                                                    echo "<td>" . decryptData($row['assessor']) . "</td>";
                                                    echo "<td>
                                                    <a href='edit_assessment_modal.php' class=' edit-btn'
                                                        data-id='{$row['assessment_id']}'
                                                        data-name='" . decryptData($row['assessment_name']) . "' 
                                                        data-level='" . decryptData($row['assessment_level']) . "' 
                                                        data-date='" . decryptData($row['assessment_date']) . "'
                                                        data-title='" . decryptData($row['competency_title']) . "' 
                                                        data-assessor='" . decryptData($row['assessor']) . "'
                                                        data-location='" . decryptData($row['location']) . "'  
                                                        data-toggle='modal' data-target='#editAssessmentModal'>
                                                        <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>

                                                    <a href='view_assessment.php' class='view-btn'
                                                        data-id='{$row['assessment_id']}'
                                                        data-assessment_name='" . decryptData($row['assessment_name']) . "' 
                                                        data-assessment_level='" . decryptData($row['assessment_level']) . "' 
                                                        data-assessment_date='" . decryptData($row['assessment_date']) . "'
                                                        data-competency_title='" . decryptData($row['competency_title']) . "' 
                                                        data-assessor='" . decryptData($row['assessor']) . "'
                                                        data-location='" . decryptData($row['location']) . "'  
                                                        data-toggle='modal' data-target='#viewAssessmentModal'>
                                                        <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>

                                                    <a href='delete_assessment.php?assessment_id={$row['assessment_id']}' 
                                                        data-toggle='tooltip' data-placement='top' title='Delete' 
                                                        onclick=\"return confirm('Are you sure you want to delete this assessment?')\">
                                                        <i class='fa fa-trash' style='color: red; font-size: 15px;'></i> <!-- Blue -->
                                                    </a>
                                                    </td>";
                                                    echo "</tr>";
                                                }
                                            }
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>Assessment Name</th>
                                                <th>Assessment Level</th>
                                                <th>Assessor Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                </table>
                                <!-- Add Assessment Modal -->
                                <div class="modal fade" id="addAssessmentModal" tabindex="-1" aria-labelledby="addAssessmentodalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="manage_assessments.php" method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addAssessmentModalLabel">Add New Assessment</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="assessmentName">Assessment Name</label>
                                                        <input type="text" class="form-control" name="assessment_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="assessmentLevel">Level</label>
                                                        <input type="text" class="form-control" name="assessment_level" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="assessment_date">Assessment Date</label>
                                                        <input type="date" class="form-control" name="assessment_date" id="assessment_date" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="competencyTitle">Competency Title</label>
                                                        <input type="text" class="form-control" name="competency_title" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="assessor">Assessor Name</label>
                                                        <input type="text" class="form-control" name="assessor" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="location">Location</label>
                                                        <input type="text" class="form-control" name="location" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="addAssessment" class="btn btn-primary">Add Assessment</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    


    <!-- Datatable -->
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('assessment_date').setAttribute('min', today);
        const assessmentDateInput = document.getElementById('assessment_date');
    </script>
    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 5000); 
        }
    };
    </script>
    
</body>
</html>
<?php
    include 'edit_assessment_modal.php';
    include 'view_assessment.php';
?>