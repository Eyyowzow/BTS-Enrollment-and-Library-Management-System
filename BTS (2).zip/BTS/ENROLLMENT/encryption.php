<?php
define('ENCRYPTION_KEY', 'your-256-bit-secret-key'); 
define('ENCRYPTION_METHOD', 'AES-256-CBC');

function encryptData($data) {
    $key = ENCRYPTION_KEY;
    $ivLength = openssl_cipher_iv_length(ENCRYPTION_METHOD); 
    $iv = openssl_random_pseudo_bytes($ivLength); 
    $encrypted = openssl_encrypt($data, ENCRYPTION_METHOD, $key, 0, $iv);
    
    return base64_encode($encrypted . '::' . $iv);
}

function decryptData($data) {
    $key = ENCRYPTION_KEY;
    $decoded = base64_decode($data);

    if (strpos($decoded, '::') === false) {
        return false;
    }
    list($encrypted_data, $iv) = explode('::', $decoded, 2);
    if (strlen($iv) !== openssl_cipher_iv_length(ENCRYPTION_METHOD)) {
        return false; 
    }

    return openssl_decrypt($encrypted_data, ENCRYPTION_METHOD, $key, 0, $iv);
}

?>
