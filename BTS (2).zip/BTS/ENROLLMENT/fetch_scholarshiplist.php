<?php
include '../Database/Database.php';
include_once 'encryption.php';
if (isset($_GET['scholarship_id'])) {
    $scholarship_id = $_GET['scholarship_id'];
    
    if (!empty($scholarship_id)) {
        // Debugging log
        error_log("Fetching students for Scholarship ID: " . $scholarship_id);
        
        $sql = "SELECT e.id, s.ULI,
        s.first_name, 
        s.last_name,
        s.gender,
        e.student_status 
        FROM enrollments e
        JOIN students s ON e.student_id = s.student_id  
        JOIN scholarships sc ON sc.scholarship_id = sc.scholarship_id
        WHERE sc.scholarship_id = ?
        ";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $scholarship_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $counter = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $counter++ . "</td>";
                echo "<td>" . decryptData($row['ULI']) . "</td>";
                echo "<td>" . decryptData($row['first_name']) . " " . decryptData($row['last_name']) . "</td>";
                echo "<td>" . decryptData($row['gender']) . "</td>";
                echo "<td>" . htmlspecialchars($row['student_status']) . "</td>";
                echo "<td><a href='edit_student.php?id=" . $row['id'] . "'>
                <i class='fa fa-eye color-muted'></i></a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No students found for this assessment</td></tr>"; 
        }
    } else {
        echo "<tr><td colspan='7'>Assessment ID is empty</td></tr>";  
    }
}
?>
