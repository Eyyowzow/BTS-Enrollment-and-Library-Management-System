<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$success_message = '';
$error_message = '';

if (isset($_POST['addUser'])) {
    $first_name = encryptData(mysqli_real_escape_string($conn,$_POST['first_name']));
    $middle_name = encryptData(mysqli_real_escape_string($conn,$_POST['middle_name']));
    $last_name = encryptData(mysqli_real_escape_string($conn,$_POST['last_name']));
    $username = $_POST['username'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (first_name, middle_name, last_name, username, role, user_password) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("ssssss", $first_name, $middle_name, $last_name, $username, $role, $password);
        if ($stmt->execute()) {
            $success_message = 'User Added Successfully!';
        } else {
            $error_message = 'Error Adding User!';
        }
        $stmt->close();
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System - User Management</title>
</head>
<body>
    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4>User Masterlist</h4>
                        <span class="ml-1">Records and Reports</span>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">Add New User
                    </button>
                </div>
            </div>
            <?php if ($success_message): ?>
                <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                    <span><i class="mdi mdi-account-search"></i></span>
                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                        <span><i class="mdi mdi-close"></i></span>
                    </button> 
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($error_message)): ?>
                <div class='alert alert-danger'><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="display" style="min-width: 845px">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Account Name</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $sql = "SELECT * FROM users";
                                            $result = $conn->query($sql);
                                            $count = 1;

                                            if (!$result) {
                                                echo "<tr><td colspan='5'>Error fetching users: " . $conn->error . "</td></tr>";
                                            } else {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . decryptData($row['first_name']) . ' ' . decryptData($row['middle_name']) . ' ' . decryptData($row['last_name']) . "</td>";
                                                    echo "<td>" . $row['role'] . "</td>";
                                                    echo "<td>
                                                        <span>
                                                        <a href='user_settings.php' class='mr-4 edit-btn'
                                                            data-id='{$row['user_id']}'
                                                            data-firstname='" . decryptData($row['first_name']) . "'                           
                                                            data-middlename='" . decryptData($row['middle_name']) . "'
                                                            data-lastname='" . decryptData($row['last_name']) . "'
                                                            data-username='" . $row['username'] . "'
                                                            data-userrole='" . $row['role'] . "'
                                                            data-toggle='modal' data-target='#editUserModal'>
                                                            <i class='fa fa-edit' style='color: blue; font-size: 15px;'></i>
                                                        </a>

                                                        <a href='delete_user.php?user_id={$row['user_id']}' 
                                                            data-toggle='tooltip' data-placement='top' title='Delete' 
                                                            onclick=\"return confirm('Are you sure you want to delete this user?')\">
                                                            <i class='fa fa-trash' style='color: red; font-size: 15px;'></i>
                                                        </a>
                                                        </span>
                                                    </td>";
                                                    echo "</tr>";
                                                }
                                            }
                                        ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>#</th>
                                            <th>Account Name</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>

                                <!-- Add User Modal -->
                                <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="user_settings.php" method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="firstname">First Name</label>
                                                        <input type="text" class="form-control" name="first_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="middlename">Middle Name</label>
                                                        <input type="text" class="form-control" name="middle_name">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="lastname">Last Name</label>
                                                        <input type="text" class="form-control" name="last_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username">Username</label>
                                                        <input type="text" class="form-control" name="username" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="password">Password</label>
                                                        <input type="password" class="form-control" name="password" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="role">Role</label>
                                                        <select class="form-control" name="role" required>
                                                            <option class="admin" id="admin" value="Administrator">Administrator</option>
                                                            <option class="registrar" id="registrar" value="Registrar">Registrar</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="addUser" class="btn btn-primary">Add User</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
    <script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 3000); 
        }
    };
    </script>
</body>
</html>
<?php

include 'edit_user.php';
if (isset($_POST['editUser'])) {
    $user_id = $_POST['user_id'];
    $first_name = encryptData($_POST['first_name']);
    $middle_name = encryptData($_POST['middle_name']);
    $last_name = encryptData($_POST['last_name']);    
    $username = encryptData($_POST['username']);
    $role = encryptData($_POST['role']);

    if (!empty($_POST['user_password'])) {
        $password = password_hash($_POST['user_password'], PASSWORD_BCRYPT);

        // Update with new password
        $sql = "UPDATE users SET first_name = ?, middle_name = ?, last_name = ?, username = ?, role = ?, user_password = ? WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssi", $first_name, $middle_name, $last_name, $username, $role, $password, $user_id);
    } else {
        // Update pass without changing it
        $sql = "UPDATE users SET first_name = ?, middle_name = ?, last_name = ?, username = ?, role = ? WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssi", $first_name, $middle_name, $last_name, $username, $role, $user_id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('User updated successfully'); window.location='user_settings.php';</script>";
    } else {
        echo "<script>alert('Error updating user: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}
?>