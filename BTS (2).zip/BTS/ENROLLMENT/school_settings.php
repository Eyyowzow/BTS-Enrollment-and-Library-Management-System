<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$schoolId = $_SESSION['schoolId'] ?? '';
$school = $_SESSION['school'] ?? '';
$region = $_SESSION['region'] ?? '';
$division = $_SESSION['division'] ?? '';
$address = $_SESSION['address'] ?? '';

if (isset($_POST['save'])) {
    $schoolId = $_POST['schoolId'] ?? '';
    $school = $_POST['school'] ?? '';
    $region = $_POST['region'] ?? '';
    $division = $_POST['division'] ?? '';
    $address = $_POST['address'] ?? '';

    $_SESSION['schoolId'] = $schoolId;
    $_SESSION['school'] = $school;
    $_SESSION['region'] = $region;
    $_SESSION['division'] = $division;
    $_SESSION['address'] = $address;

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $query = "SELECT * FROM school_settings WHERE id = 1";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $sql = "UPDATE school_settings SET 
                schoolId = '$schoolId', 
                school = '$school', 
                region = '$region', 
                division = '$division', 
                address = '$address' 
                WHERE id = 1";
    } else {
        $sql = "INSERT INTO school_settings (schoolId, school, region, division, address) 
                VALUES ('$schoolId', '$school', '$region', '$division', '$address')";
    }
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Record saved successfully');</script>";
    }
}
$query = "SELECT * FROM school_settings WHERE id = 1"; 
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $schoolId = $row['schoolId'];
    $school = $row['school'];
    $region = $row['region'];
    $division = $row['division'];
    $address = $row['address'];
}
mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <!-- Form step -->
    <link href="../bootstrap/vendor/jquery-steps/css/jquery.steps.css" rel="stylesheet">


</head>

<body>
        <div class="content-body">
            <div class="container-fluid">
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card">
                            <div class="card-header">
                            </div>
                            <div class="card-body">
                            <form action="school_settings.php" method="POST">
                                <div>
                                    <div class="row">
                                        <div class="col-lg-12 mb-12">
                                            <center><h6 class="text-primary">SCHOOL SETTING</h6></center>
                                            <hr>
                                        </div>
                                        <div class="col-lg-4 mb-12">
                                            <div class="form-group">
                                                <label class="text-label">School ID</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="schoolId" placeholder="" value="<?php echo htmlspecialchars($schoolId); ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-8 mb-12">
                                            <div class="form-group">
                                                <label class="text-label">School Name</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="school" value="<?php echo htmlspecialchars($school); ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-12">
                                            <div class="form-group">
                                                <label class="text-label">Region</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="region" value="<?php echo htmlspecialchars($region); ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-12">
                                            <div class="form-group">
                                                <label class="text-label">Division</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="division" value="<?php echo htmlspecialchars($division); ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-12">
                                            <div class="form-group">
                                                <label class="text-label">Address</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($address); ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-12">
                                            <center><button type="submit" name="save" class="btn btn-primary">Update School Setting</button><center>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    


    <script src="../bootstrap/vendor/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="../bootstrap/vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Form validate init -->
    <script src="../bootstrap/js/plugins-init/jquery.validate-init.js"></script>



    <!-- Form step init -->
    <script src="../bootstrap/js/plugins-init/jquery-steps-init.js"></script>


</script>
</body>

</html>