<?php 
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System </title>
    <style>
        table.dataTable {
            table-layout: fixed;
            width: 100%;
        }
    </style>
</head>

<body>
<div class="content-body">
            <div class="container-fluid">
                <!-- row -->
                <div class="row">
<div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">List Tab</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-list-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-xl-2">
                                            <div class="list-group mb-4 " id="list-tab" role="tablist">
                                                <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-student" role="tab">Home</a> 
                                                <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-enrolled" role="tab">Profile</a> 
                                                <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-assessment" role="tab">Messages</a>
                                                <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-program" role="tab">Settings</a>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-10">
                                            <div class="tab-content" id="nav-tabContent">
                                                <div class="tab-pane fade show active" id="list-student">
                                                    <h4 class="mb-4">Home Tab Content</h4>
    <!-- 0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000-->
    <div class="card">
                                <div class="table-responsive">
                                    <table class="table table-bordered verticle-middle table-responsive-sm">
                                        <thead>
                                            <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">ULI</th>
                                                        <th scope="col">Student Name</th>
                                                        <th scope="col">Gender</th>
                                                        <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                                $sql = "SELECT student_id, ULI, first_name, last_name, gender, status 
                                                        FROM students 
                                                        WHERE is_deleted = 1";

                                                $result = mysqli_query($conn, $sql);

                                                if (!$result) {
                                                    echo '<tr><td colspan="5">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                    exit();
                                                }

                                                $count = 1;

                                                if (mysqli_num_rows($result) > 0) {
                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                        $uli = decryptData($row['ULI']);
                                                        $fullName = decryptData($row['first_name']) . ' ' . decryptData($row['last_name']);
                                                        $gender = decryptData($row['gender']);
                                                        $status = decryptData($row['status']);
                                                        $action = '<a href="restore_student.php?student_id=' . $row['student_id'] . '" 
                                                                    class="btn btn-primary">
                                                                    <i class="fa fa-undo"></i> Restore
                                                                </a>';
                                                        echo "
                                                        <tr>
                                                            <td>{$count}</td>
                                                            <td>{$uli}</td>
                                                            <td>{$fullName}</td>
                                                            <td>{$gender}</td>
                                                            <td>{$action}</td>
                                                        </tr>";
                                                        $count++;
                                                    }
                                                }
                                                ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>




                                                    <!-- 00000000000000000000000 -->


                                                </div>
                                                
                                            <div class="tab-content" id="nav-tabContent">
                                                <div class="tab-pane fade" id="list-enrolled">
                                                    <h4 class="mb-4">Home Tab Content</h4>
                                                    <div class="table-responsive">
                                        <table id="list-enrolled" class="display table-responsive-sm" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>ULI</th>
                                                    <th>Student Name</th>
                                                    <th>Gender</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $sql = "SELECT e.id,
                                                        s.ULI,
                                                        s.first_name, 
                                                        s.last_name, 
                                                        CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                                                        CONCAT(p.program_name, ' ', p.level) AS tesda_program, 
                                                        CONCAT(t.first_name, ' ', t.last_name) AS trainor_name, 
                                                        sched.batch_no,
                                                        CONCAT(sched.starts_date, ' - ', sched.end_date) AS date_span, 
                                                        e.student_status 
                                                    FROM enrollments e
                                                    JOIN students s ON e.student_id = s.student_id
                                                    JOIN programs p ON e.program_id = p.program_id
                                                    JOIN trainors t ON e.trainor_id = t.trainor_id
                                                    JOIN schedules sched ON e.schedule_id = sched.schedule_id
                                                    WHERE (e.is_deleted = 1)";

                                            $result = mysqli_query($conn, $sql);

                                            if (!$result) {
                                                echo "<tr><td colspan='5'>Error executing query: " . mysqli_error($conn) . "</td></tr>";
                                                exit;
                                            }

                                            $count = 1;

                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    $uli = decryptData($row['ULI']);
                                                    $student_name = decryptData($row['first_name']) . ' ' . decryptData($row['last_name']);
                                                    $batch = htmlspecialchars($row['batch_no']);
                                                    $action = '<a href="restore_enrollee.php?id=' . $row['id'] . '" class="btn btn-primary"><i class="fa fa-undo"></i></a>';

                                                    echo "<tr>
                                                            <td>{$count}</td>
                                                            <td>{$uli}</td>
                                                            <td>{$student_name}</td>
                                                            <td>{$batch}</td>
                                                            <td>{$action}</td>
                                                        </tr>";
                                                    $count++;
                                                }
                                            } else {
                                                echo "<tr><td colspan='5'>No deleted students found.</td></tr>";
                                            }
                                            ?>

                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>#</th>
                                                    <th>ULI</th>
                                                    <th>Student Name</th>
                                                    <th>Gender</th>
                                                    <th>Action</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="list-assessment">
                                                    <h4 class="mb-4">Message Tab Content</h4>
                                                </div>
                                    <div class="tab-pane fade" id="Assessment" role="tabpanel">
                                        <div class="table-responsive">
                                            <table id="list-assessment" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Assessment Name</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    // Query to fetch deleted assessments
                                                    $sql = "SELECT * FROM assessments WHERE is_deleted = 1";
                                                    $result = $conn->query($sql);

                                                    // Error handling
                                                    if (!$result) {
                                                        echo '<tr><td colspan="3">Error: ' . mysqli_error($conn) . '</td></tr>';
                                                        exit;
                                                    }

                                                    $count = 1;

                                                    if (mysqli_num_rows($result) > 0) {
                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            $assessmentName = decryptData($row['assessment_name']);
                                                            
                                                            $action = '<a href="restore_assessment.php?assessment_id=' . $row['assessment_id'] . '" 
                                                                    class="btn btn-primary">
                                                                    <i class="fa fa-undo"></i> Restore
                                                                    </a>';

                                                            echo "
                                                            <tr>
                                                                <td>{$count}</td>
                                                                <td>{$assessmentName}</td>
                                                                <td>{$action}</td>
                                                            </tr>";
                                                            $count++;
                                                        }
                                                    } else {
                                                        echo '
                                                        <tr>
                                                            <td colspan="3" class="text-center">No deleted assessments found.</td>
                                                        </tr>';
                                                    }
                                                    ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Assessment Name</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                                </div>

                                                
                                                <div class="tab-pane fade" id="list-program">
                                                    <h4 class="mb-4">Settings Tab Content</h4>
                                                    <table id="list-program" class="display table-responsive-sm" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Code</th>
                                                        <th>Program Name</th>
                                                        <th>Level</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
        <?php
        $sql = "SELECT * FROM programs WHERE is_deleted = 1";
        $result = mysqli_query($conn, $sql);

        // Error handling
        if (!$result) {
            echo '<tr><td colspan="5">Error: ' . mysqli_error($conn) . '</td></tr>';
            exit;
        }

        $count = 1;

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $programCode = decryptData($row['program_code']);
                $programName = decryptData($row['program_name']);
                $level = decryptData($row['level']);

                $action = '<a href="restore_program.php?program_id=' . $row['program_id'] . '" 
                           class="btn btn-primary">
                           <i class="fa fa-undo"></i> Restore
                           </a>';

                echo "
                <tr>
                    <td>{$count}</td>
                    <td>{$programCode}</td>
                    <td>{$programName}</td>
                    <td>{$level}</td>
                    <td>{$action}</td>
                </tr>";
                $count++;
            }
        } else {
            echo '
            <tr>
                <td colspan="5" class="text-center">No deleted programs found.</td>
            </tr>';
        }
        ?>
    </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Code</th>
                                                        <th>Program Name</th>
                                                        <th>Level</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        <!-- Required vendors -->
                        <script>
    $(document).ready(function () {
    $('#list-student, #list-enrolled, #list-assessment, #list-program').DataTable({
        scrollY: "42vh",
        scrollCollapse: true,
        paging: false,
        autoWidth: false, 
        responsive: true,  
        createdRow: function (row, data, index) {
            $(row).addClass('selected');
        }
    }).columns.adjust().draw(); 

    $(window).on('resize', function () {
        $('#list-student, #list-enrolled, #list-assessment, #list-program')
            .DataTable().columns.adjust();
    });
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
    });
});
</script>
<script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>


</body>
</html>