<?php
include '../Database/Database.php';
include 'encryption.php';
if (isset($_POST['query'])) {
    $query = trim($_POST['query']);  

    if (!empty($query)) {
        $sql = "SELECT program_id, program_name, level,
                CONCAT(program_name, ' ', level) 
                AS tesda_program 
                FROM programs 
                WHERE program_name LIKE ? OR level LIKE ? 
                 AND is_deleted = 0
                 LIMIT 10";
        $stmt = $conn->prepare($sql);
        $search_query = "%".$query."%";
        $stmt->bind_param('ss', $search_query, $search_query);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li data-program_id='".$row['program_id']."'>" . decryptData($row['program_name']) . " " . decryptData($row['level']) . "</li>";
            }
        } else {
            echo "<li>No programs found</li>";
        }
    } else {
        echo "<center><li>Please enter a program to search</li><center>";  
    }
}
?>
