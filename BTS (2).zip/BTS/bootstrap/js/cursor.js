const studentInput = document.getElementById('student_name');
const studentList = document.getElementById('studentList');
let currentFocus = -1;  // Track currently focused item

// Simulate fetching students from server (replace with actual AJAX call)
studentInput.addEventListener('input', function () {
    const query = studentInput.value;
    if (query.length > 0) {
        displaySuggestions(students);
    } else {
        studentList.style.display = 'none';  // Hide when input is empty
    }
});

// Display student suggestions
function displaySuggestions(students) {
    studentList.innerHTML = '';  // Clear previous suggestions
    studentList.style.display = 'block';  // Show the list

    students.forEach((student, index) => {
        const li = document.createElement('li');
        li.textContent = student.name;
        li.classList.add('student-item');
        li.setAttribute('data-id', student.id);
        li.style.padding = '10px';
        li.style.cursor = 'pointer';

        // Handle click selection
        li.addEventListener('click', function () {
            studentInput.value = student.name;
            document.getElementById('student_id').value = student.id;
            studentList.style.display = 'none';  // Hide list after selection
        });

        studentList.appendChild(li);
    });
}

// Handle arrow key navigation
studentInput.addEventListener('keydown', function (e) {
    const items = studentList.getElementsByClassName('student-item');
    if (e.key === 'ArrowDown') {
        currentFocus++;
        highlightItem(items);
    } else if (e.key === 'ArrowUp') {
        currentFocus--;
        highlightItem(items);
    } else if (e.key === 'Enter') {
        e.preventDefault();  // Prevent form submission
        if (currentFocus > -1 && items[currentFocus]) {
            items[currentFocus].click();  // Trigger click on selected item
        }
    }
});

// Highlight the currently focused item
function highlightItem(items) {
    if (!items) return;
    removeHighlight(items);
    if (currentFocus >= items.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = items.length - 1;
    items[currentFocus].classList.add('highlight');
}

// Remove highlight from all items
function removeHighlight(items) {
    for (let item of items) {
        item.classList.remove('highlight');
    }
}
