(function($) {
    "use strict";



    // Morris bar chart
    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y: '2018',
            a: 5,
            b: 0
        }, {
            y: '2019',
            a: 5,
            b: 0
        }, {
            y: '2020',
            a: 0,
            b: 0
        }, {
            y: '2021',
            a: 0,
            b: 0
        }, {
            y: '2022',
            a: 0,
            b: 0
        }, {
            y: '2023',
            a: 0,
            b: 0
        }, {
            y: '2024',
            a: 0,
            b: 0
        }],
        xkey: 'y',
        ykeys: ['a', 'b'],
        labels: ['Dropped Students', 'Enrolled Students'],
        barColors: ['#6482AD', '#7FA1C3'],
        hideHover: 'auto',
        gridLineColor: '#eef0f2',
        resize: true
    });


    $('.year-calendar').pignoseCalendar({
        theme: 'blue' // light, dark, blue
    });

})(jQuery);