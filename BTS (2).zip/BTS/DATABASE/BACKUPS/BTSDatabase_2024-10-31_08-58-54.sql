-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: BTSDatabase
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assessments`
--

DROP TABLE IF EXISTS `assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assessments` (
  `assessment_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `assessment_name` text NOT NULL,
  `assessment_level` text DEFAULT NULL,
  `assessment_date` text DEFAULT NULL,
  `competency_title` text DEFAULT NULL,
  `assessor` text DEFAULT NULL,
  `location` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`assessment_id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  CONSTRAINT `assessments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `assessments_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessments`
--

LOCK TABLES `assessments` WRITE;
/*!40000 ALTER TABLE `assessments` DISABLE KEYS */;
INSERT INTO `assessments` VALUES (1,NULL,NULL,'UE42VXRLMThFakJqMmpUZTJFUDVncTYzZ1h2Z3NuS2dYdmxmSmNRWmhqUT06Ooed7w8WL+FtbvPp6Bwb8KY=','RzVFYW1QeWVSMG1KVklRemN4ZGUrUT09Ojq8SDZyJH27jGdPwwH2Is74','Z0xhdks5M013WFRBOFVjWVN1V3JBQT09OjpqDi7bHoMNAblWlj/ELItp','SHZ6RjgrOGRLZzM1YzU3eDZDZkl0UT09OjrpUrH1HcovjXeVaWbxlKo9','akZpT2dHNkxvTXg5WEh3NXozY29EZz09OjpjfMrwe7iBSPx0zaVCF28Y','KzQ1M0dJVUEvSmR5MTRNM3p6M0dWZz09Ojp02kP3WwPrNuI8kLR59VY+',0,NULL);
/*!40000 ALTER TABLE `assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `books_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_received` date DEFAULT NULL,
  `class` varchar(50) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title_of_book` varchar(255) DEFAULT NULL,
  `edition` varchar(50) NOT NULL,
  `volumes` varchar(50) NOT NULL,
  `pages` text DEFAULT NULL,
  `source_of_fund` varchar(50) NOT NULL,
  `cost_Price` text NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `location` varchar(50) NOT NULL,
  `year` text DEFAULT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`books_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'2024-10-31','BSIT','Kenneth','Cinderella','4','2','25','Donation','50','Charisse','Baguio','2020','New');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `books_id` int(11) DEFAULT NULL,
  `date` text DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `course` varchar(255) NOT NULL,
  `status` enum('borrowed','returned') DEFAULT 'borrowed',
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `books_id` (`books_id`),
  CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `borrow_ibfk_2` FOREIGN KEY (`books_id`) REFERENCES `books` (`books_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow`
--

LOCK TABLES `borrow` WRITE;
/*!40000 ALTER TABLE `borrow` DISABLE KEYS */;
/*!40000 ALTER TABLE `borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dropped_students`
--

DROP TABLE IF EXISTS `dropped_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dropped_students` (
  `dropped_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `assessment_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `scholarship_id` int(11) DEFAULT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` text DEFAULT NULL,
  `phone` text DEFAULT NULL,
  `dropped_reason` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`dropped_id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `scholarship_id` (`scholarship_id`),
  CONSTRAINT `dropped_students_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `dropped_students_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `dropped_students_ibfk_3` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`),
  CONSTRAINT `dropped_students_ibfk_4` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`assessment_id`),
  CONSTRAINT `dropped_students_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`),
  CONSTRAINT `dropped_students_ibfk_6` FOREIGN KEY (`scholarship_id`) REFERENCES `scholarships` (`scholarship_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dropped_students`
--

LOCK TABLES `dropped_students` WRITE;
/*!40000 ALTER TABLE `dropped_students` DISABLE KEYS */;
/*!40000 ALTER TABLE `dropped_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `assessment_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `scholarship_id` int(11) DEFAULT NULL,
  `educational_attainment` text DEFAULT NULL,
  `employment` text DEFAULT NULL,
  `enrollment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `student_status` enum('enrolled','dropped','passed','failed') NOT NULL DEFAULT 'passed',
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `scholarship_id` (`scholarship_id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `enrollments_ibfk_3` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`),
  CONSTRAINT `enrollments_ibfk_4` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`assessment_id`),
  CONSTRAINT `enrollments_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`),
  CONSTRAINT `enrollments_ibfk_6` FOREIGN KEY (`scholarship_id`) REFERENCES `scholarships` (`scholarship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
INSERT INTO `enrollments` VALUES (29,12,10,9,NULL,1,2,'Tertiary Education',NULL,'2024-10-31 03:43:38','enrolled',1,NULL);
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_school_settings`
--

DROP TABLE IF EXISTS `library_school_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `library_school_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(255) NOT NULL,
  `school_address` text NOT NULL,
  `school_contact` varchar(100) NOT NULL,
  `school_email` varchar(100) NOT NULL,
  `school_logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_school_settings`
--

LOCK TABLES `library_school_settings` WRITE;
/*!40000 ALTER TABLE `library_school_settings` DISABLE KEYS */;
INSERT INTO `library_school_settings` VALUES (1,'Example School','123 Main St, Example City','123-456-7890','info@example.com','logo.png');
/*!40000 ALTER TABLE `library_school_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_users`
--

DROP TABLE IF EXISTS `library_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `library_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('Administrator','Librarian') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_users`
--

LOCK TABLES `library_users` WRITE;
/*!40000 ALTER TABLE `library_users` DISABLE KEYS */;
INSERT INTO `library_users` VALUES (1,'Admin','$2y$10$04.IW/UZlokktVpt/Jf5L./XRKPbBBPh7xhwGPADtsCNV1/2/cXOi','Admin User','Administrator'),(2,'Librarian','$2y$10$6XJjc6ZP0zavRjNuvYF/MuRN8kQVv/hv11m7c8oYcMXsDYBaCezbe','Librarian','Librarian');
/*!40000 ALTER TABLE `library_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` text NOT NULL,
  `program_code` text DEFAULT NULL,
  `level` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,'Agricultural Crops Production','P001','NC I','Training for agricultural crops production, covering fundamental techniques and practices.',1,NULL,'2024-10-29 13:07:38'),(2,'Agricultural Crops Production','P002','NC II','Advanced training for agricultural crops production, including more complex techniques and management.',1,NULL,'2024-10-29 13:07:38'),(3,'Automotive Servicing','P003','NC I','Training for basic automotive servicing, focusing on standard repair and maintenance tasks.',1,NULL,'2024-10-29 13:07:38'),(4,'Bread and Pastry Production','P004','NC II','Training in the production of bread and pastries, including techniques and best practices.',1,NULL,'2024-10-29 13:07:38'),(5,'Hairdressing','P005','NC II','Advanced training in hairdressing, including cutting, coloring, and styling techniques.',1,NULL,'2024-10-29 13:07:38'),(6,'Dressmaking','P006','NC II','Training in dressmaking, focusing on designing and creating custom garments.',1,NULL,'2024-10-29 13:07:38'),(7,'Tailoring','P007','NC II','Advanced tailoring training, including techniques for creating and altering various types of clothing.',1,NULL,'2024-10-29 13:07:38'),(8,'Japanese Language and Culture','P008','NC I','Comprehensive training in Japanese language and cultural practices.',1,NULL,'2024-10-29 13:07:38'),(9,'Driving','P009','NC II','Training for driving skills and techniques, focusing on road safety and vehicle operation.',1,NULL,'2024-10-29 13:07:38'),(10,'cE1ycTZBbnN0YmlQQ2tma0UxVy9sRzFndmFBUm1URU9NTjFueStpa1ZJRT06Oq843nOmLguosgKTDVM/CCE=','UjZQN2hGQ0NYZTFNOFdWdllXSHNnUT09OjqJbP8iv6mggLP0ibENlbh5','UlJ3aWkzcGg3cDJTSWREVjVtcHAzQT09Ojq2ZW8oujc1+nt5TOrdN+Mb','aTBTcldkZnBtV1REMjZkR0NiTkZYaW5XMkZ6Um04dXNrRTlSb0kyamZJTT06OhCUqbk2r9O2ZwMiHj6zCh8=',1,NULL,'2024-10-29 13:10:58'),(11,'WWMyZ2k2L0Z4WDUvSW1PNlFlYlh0akpZeFJDdEpBTDlKSDNLeEF4c1BaVT06OpwV2HbmD1rNyE84mEP0jak=','b3p0VldCeFlJamRYdmRxaHFDcS92Zz09OjrLEpikN3Am2hdGARd4VIgJ','Q2s2eEs3S0lDVTNSRDZVNDZ4R3F2UT09OjqU+VtlHUkkT61DbzpInZNI','OWVlWTFYZnY3L0M1QThTTk5UL3ZXdz09OjrRZwEd6S4/dNgsjGhz+MZ9',1,NULL,'2024-10-30 13:17:43'),(12,'TXZLUEhTUVpWYkZtb2VMeFJMSFloc3VxcmlpV2ttb2Fmd1V5b1g2SitnRT06OunJeg0rikzmCCP6DBza7yQ=','bjF5VVZ4QVpDMXdhN1JJZVJ2a2pvdz09OjpRdLgGygopgJe3oomEUogv','NWJ3UVBkbEc0bTM3b1F5cWpJWngyZz09OjrY3+wn5h/Y1FQ2XaCQ6dc3','YVpqMHozQ0V1czJXclhsZHBTWWhDZz09OjpW1IxVbquxTtkIV2BT8kh4',1,NULL,'2024-10-30 13:18:10'),(13,'RlVIZjVJMFRvcEVBRmdPeGo3WTF1UU5qZ3ArL2xjTTJ5Z1cvMGpXRm01ST06OlwZutE/xsD6fD4Nw1h7nqo=','K0lEdU12Q0Q3MXVIZW5KYUtyR3VxQT09Ojq0++BijtNoXOf0UzRxooPT','MXBuZGU3SzlBQ1UrZWRtQUlWbFJOdz09OjoLylPPAilWDsw/dKfmzr7U','bEhiMnlScStRZmIvR09vYmZSMk5jZz09Ojq79NmKJJi++Ns4Pg/M5zfh',0,NULL,'2024-10-30 13:18:30');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_code` text DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `batch_no` text DEFAULT NULL,
  `starts_date` text DEFAULT NULL,
  `end_date` text DEFAULT NULL,
  `days` text DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,NULL,10,'1','2024-10-29','2024-11-13','5',9,0,NULL);
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scholarships`
--

DROP TABLE IF EXISTS `scholarships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scholarships` (
  `scholarship_id` int(11) NOT NULL AUTO_INCREMENT,
  `scholarship_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `amount` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`scholarship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scholarships`
--

LOCK TABLES `scholarships` WRITE;
/*!40000 ALTER TABLE `scholarships` DISABLE KEYS */;
INSERT INTO `scholarships` VALUES (1,'Training for Work Scholarship Program (TWSP)','Training for Work Scholarship Program (TWSP)','5000.00',1,NULL),(2,'UWhJQlloeDR1WXNLWkI1T2VLd2xNQ2UvWlZCNW9OVEdJQXRjZW1WWS84d1BDcXBWVGlVT2ZLN0FJU0VmaXFoVjo6NRWAJwBmNaZg7VxPay2sog==','TEM5TFlhSWJwbTNrVFlyY3BCL2Q5MUZTbFIyYVk3WmhBYURDWWNDWldJdVpoeVNPcnRISmllbUdLK0Z4alBUUDo6HLO793iIIrtdQs9lNeE0EA==','bkp6Y3JVZUpERmZPUGxyNmlXQmhOUT09OjrP7NFig6K4seEbLVsCzjaE',0,NULL);
/*!40000 ALTER TABLE `scholarships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_settings`
--

DROP TABLE IF EXISTS `school_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schoolId` text NOT NULL,
  `school` text NOT NULL,
  `region` text NOT NULL,
  `division` text NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_settings`
--

LOCK TABLES `school_settings` WRITE;
/*!40000 ALTER TABLE `school_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `school_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `ULI` text NOT NULL,
  `first_name` text NOT NULL,
  `middle_name` text DEFAULT NULL,
  `last_name` text NOT NULL,
  `suffix` text DEFAULT NULL,
  `birth_place` text NOT NULL,
  `birth_date` text NOT NULL,
  `gender` text NOT NULL,
  `marital_status` text NOT NULL,
  `citizenship` text NOT NULL,
  `email` text DEFAULT NULL,
  `fb_account` text DEFAULT NULL,
  `phone_number` text NOT NULL,
  `parent_firstname` text NOT NULL,
  `parent_lastname` text NOT NULL,
  `parent_middlename` text NOT NULL,
  `parent_phone` text DEFAULT NULL,
  `street_number` text DEFAULT NULL,
  `street_name` text DEFAULT NULL,
  `subdivision` text DEFAULT NULL,
  `barangay` text NOT NULL,
  `city` text NOT NULL,
  `province` text NOT NULL,
  `form_137` tinyint(1) DEFAULT 0,
  `report_card` tinyint(1) DEFAULT 0,
  `diploma` tinyint(1) DEFAULT 0,
  `completion_cert` tinyint(1) DEFAULT 0,
  `transcript_records` tinyint(1) DEFAULT 0,
  `birth_cert` tinyint(1) DEFAULT 0,
  `marriage_cert` tinyint(1) DEFAULT 0,
  `id_photo` tinyint(1) DEFAULT 0,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `attached` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'ekk0STYwQVR5NEFja1ZVUXRFM1lmZz09OjqozFledcIlrvx4ldwJjPLt','RnJyckUwMTZSWkhWbS9PY3AvODdJZz09OjomliHkqihTLQEKWu93JWrI','QnNBaW9DTkg1MjcvOWFYVzNTZHpLQT09OjoKTVt84+T2YFZ3kfHZAEoX','RWpoMEFVUEgzOVlaOHh6Si9KUTJsUT09OjocNzkam+FgH9CXRdYCKMx7',NULL,'TjhoTm50ZENwcm5uTktlQnBWeHJ4QT09OjouHDgGJS2yc94cUO7OS0mU','b3FxS3FQOElFU08xVENhNWpybzc1Zz09OjoRN2fVU6YlGYqIwixJx4f2','c0xUdnRZUWNTb3ZXbWtndktTTHRWQT09OjqzCy8EOLj7xLZ8ocublF1/','VmdhbFV0cjZuVm9yWlNncTRXV3N2UT09Ojq9uF4Pcl0IxzNkd8lq9Lib','Qjl5ZnZ1T3BpOEd3RGpvS2VJaGJudz09Ojpxg5quJ7vLybxOqWzipjDD','bDVVYWh3MG1XZ0xGbk4xOWttc1RTUT09Ojo6mVW3J+3xOO+rFK7vsXLR','S1MzY1BnL0FESWQrcXoxL24rVmtOUT09OjqBMoVrzc5WX5UkGFdcuEHk','cWhlWUVLd3VvdDhWQXhlcjBVVW5HQT09OjrFHcvOTEslnNma7PvuiVoj','L3Rvb09qWHE4RkJrdkw0UUZTNDl5QT09OjpxMzIl8/SVqts9Y/HuNUwN','VWdnSDIvWldVSFV0cFNxdjBkRDJwQT09Ojqjo1L8Ox3MoufhGQpsbUDV','N2JtdW10K2dVRkR0NDNBbmNOMm95QT09Ojr/O2exnJbMwLmKr0L4KDUN','dzVkM3VEN0tFcmVHaDc0ZW5VN1RPUT09OjqszaGzoE9pV8ryaf2FvMZN','RFVsZEo5Nlc4d1FyMUJYMDFoUlN2UT09OjoNLhskhkjLfZF3VqMbkrPT','SkoyUTFpejBEQ25jNG01YUdSNU9ZQT09OjoxCCo3fwvAY0LxeFM8JYEf','NFkrRk5kYkl1MWJNQ0RUOUNQRU43Zz09Ojp8MzSLxTWZQi3q5/x6dQCa','ZzhsZXllWmRjWmoxSHFlZ0NkeFd0dz09OjrX9m2kCgaLKx65o3nqY4c8','MGhab0tHWTFMOHp1MnZTODFlcWRVUT09OjoMNFiFjCqZ3Zv4gXLgLQgK','Rk9idzRsaDFZQnZCMFpiUk1JU2ZpQT09OjprwV5aNmexMeQzrKye2EdN',1,0,0,0,0,0,0,0,'',NULL,0,NULL,'2024-10-29 13:12:31'),(2,'ZytpRklPU09pQ1lkb1VwV2Y5SWJOQT09OjpKD6FqJeeAxAiF2jKlPiQx','akk5MWRnRGpPVEFwMGlxS1oxTmlOUT09Ojokghtco1LCVM/Vq5bzmdZE','eDdvY3ZuSnRPUS8yQ2FSZlQwSjNkUT09OjpLQ8oI3TTvj9O24IUqMpXD','NUdJeXlGWEE5a0taNjluaDhsYXBHdz09Ojp3KXNJio6PcNRWkB6Ag0Cg',NULL,'ajYySnNBY05uV2pjZ0tEYmJ6aUR2Zz09OjoW2TXj0w3vMNRnJGPXAdz+','Z1l2YjlEbmw4YUtKL2lEeDVvMURkUT09OjrV1FXxgMz0i46knJYhYeHe','RU40OGV0UWlraWFhZXRPMEJJWDRJZz09Ojoxkc/0CYPTgLD+Eljw3x2g','aWpPeXZ4REJCWmZZZm05cGJ3d0FjZz09OjoRxZFc+LdsVsafEQWuiPYc','aDJNSEozTFdnR09sK3dFUXUzR2I0Zz09Ojrvkbn6GivxHU0qKMMdnbX3','Zk14OEZCelF5bjh3WEVsaTByd1RmUT09Ojr16cUJuSdJDCrkimpbsojX','U2VjQkNjMzBoYjh2WG00Q0JwNzR3UT09OjpOTqXHf1nh0zFOowTQboK0','MDV1Q0pMd2lMbklzTFErdU05Q1pQZz09OjpDmVlMJm+LOSK1I1ieo3Tu','R0MrSWEvOE5ORUFpMlUwTG8rakJSUT09OjrWrmJ4TvS8VqyBWSMr5Cv1','Q0xmZVYxa3ZKVHdKdTcvemFabXh4UT09Ojq1309/njmK9z6CN3JIv/VM','NGFtazVPVnhNQUV3ei9kRHN0and5UT09OjpBxT7L54646Rr6Wgtvrl1B','aXBWZEs3VTF1akQwNzhoUXF5MDJnUT09OjqesS5eYbIXFjk5euk2l5E/','OXNYUXh2eTN2NDA2Y0ZhTzdET3BqZz09OjpIaLbKHe6fCCL+oPv7Z6jd','S0hvWDJMUWtMMjVnbUFFaUVmYzljZz09OjoRCdr/V6R414AgCDi1yPcN','ZHhSd0dJQUU2U0xjd2o5cW5xZXhwdz09Ojq2XKbEH83SQEIK0EU21GNe','RE1RaW5RWDZzRHB4cVUvU1lKT2tDZz09OjqdDFKk3c8V52+CgZr/c1hk','SmxWdDZCYTAvejRhbUVFQWxtVHdmUT09Ojqfe1/gemHCFkLb4flWaQ9S','SUNsbjllODM5aUloajRHSUdHS2RqUT09Ojqmq1yATJ9W+sQ8gtpe69OV',0,0,0,0,0,0,0,1,'','',1,NULL,'2024-10-29 16:49:40'),(3,'Q3F0MzJtYlNqZ2VudDNoMDROdnJiUT09Ojonx6MthctSKvT0vNtYV/2k','STkzYUdBVmwva20rUUkvU0VESDVsQT09OjrHBzQ69bFuKhfqNlVgV3iB','c2drSndxaW1lSkw5a1I2UGY3MDNBQT09OjoEQojX7nAlq7PcMaVaWmir','RzUyWm1sTGNLOVZYbk5pdEFBTmhBdz09Ojo4gSh5Qqw99ENXoky49Exc',NULL,'THJ6YlZXS09YSy9Va3BZYnZESE4vdz09OjpYsnkyb8NYumtYCQYT8kZM','T290bkZBdzFUL2R1ZllMWGVJTURxZz09OjotzSyCpJKTFb+8957zfvua','em51L3NHbjVrWHJXZE5TNFdXbllBdz09Ojqegp1t+OjEiMps7nlTn4de','N1c3RnRoeFpHUlJwd3BkOEpTbnhFUT09Ojqy7unB1wmixhrXEGZg97x4','am1SVytsaTQ1UzhLdG5kczRDcVd4dz09OjplrZoHsXekn6TJSCAWFX+L','UEQvb1lqQWlsRGNjRmlLSzhEbk1Jdz09OjoayXzFbGc4Pkby3HxfAd55','TUx0VlI1TkhsZVhtVmxMa21zZWJlUT09Ojo4TOGl5HD+rVnSCK6/MkBq','aWpiQU8zdGpMcGVBWEJZT2NXQWNrQT09OjpPPF49WTBzbtQmhZ3oLR0w','YTFPMUJNVGNnUW10eTE1dHg1ZWVhZz09Ojqw2aZYeTSMUot4DouEZKST','ak42R05yaSt5YkhRMnBqUzdNSVpqUT09Ojp65PjpPKbHOyBIj+RzPBIB','Y0dQRnRmNUQrV2lISHlyRWdBV3Bodz09OjrUmy9zAnKlzdlgHN9me7qR','RTlMK013R2x1UGVVcm1wSG5hK2lTdz09OjqfPfqvh1WM5UTe1oBjxgYP','WlAwcXZ0NjdjdHdRdWVtT1RUaUpPdz09Ojqs9PGPPPUCeUdbbnmXC5nG','K0c5ekRiVmdPektiMysvdzZ0SXJWZz09OjrLz2SzXBuH3u/QPAHj5kML','a0V3ZmREUHVZWE1MUEIvTjczVDlwdz09OjrHXCtw1XzZQ67nDvGg3c4z','aW9zcHFGN25WdW9UVWdrcHNNdUpHQT09Ojr1X/nFWtsyzJ+gy+lw2lGH','S3VoRFdYOXhuYVQvNm14Z0lsS05hQT09Ojp/wZDm6jRqW0LS9lQg/Iln','MVdtOHUyd1lTRWZmY2I3b21DQVFPZz09OjpS82BT9jD0A5NHviVmL7C/',0,0,0,0,0,0,0,1,'','',1,NULL,'2024-10-29 16:52:56'),(4,'UU5HbnZRYWlId2F4STByei9zV3lvdz09OjorJt4Qz1rqG0Vvd4dnsHr4','TUZMZ05hWCtsQUVDUFJNdkltMVdaUT09OjoJlQw4xFYym4OuARnIzAb3','cHBZemIxVmhYS05MZ0lsYTBwKzZuUT09OjoydDzErXEHfVopBoWY80gN','NnlYa2FHMUlSWlROaXNEMFUwNGFZdz09Ojo3elmHYox1UVHO4+7VJCM0',NULL,'Sjk5SnVucVl5VHloRy9ibGp4cDdmZz09OjpwdvYoHfLSjYSvBx3SDfpz','enRWTmlFUDAzYWJkcDJmV1h0NEE3QT09Ojp3KAYMyE1OxYmCdwGj4XhD','UnlKdHpVYVhkSjIzMDI0aXRMd2Zrdz09OjqnlvIEZHno5kWwjOq0he/4','OStQRDdjSVlIa2ppWHVFMVhmem42Zz09Ojp1q/lCcai0BIO/Jtjtq3KO','K2xCdUQ1WWwrT0c1ZWNmRWR6RjN4Zz09OjqFucj1P3KsJjZGXvKq/cK0','dGZ4OHY3U3EvNnFFQjFvMHJrb09Jdz09OjrzsXUP1PvS+pTDrD9hS2Qy','MjFETEZDMTFVdGM5NTEwM0l4S2R5dz09Ojq3/LgB0SvUUD3H4ljdVidO','VHBSVUtOUUlmbWpjVkNuZGxzMjhqdz09OjqAxs8O0JpLej4zENaDT4Sg','NFdCaVZaQkVwWW1JMEFqUWJtQWRjQT09OjpNfSd4SGWRDO+MsYO/dgev','ZVR2U0NmR0R4STJLT2VkYUFvQzFhZz09OjrEG3HNzhtSqeSCdwWbym1f','MUFjRlJWN0cwa3lpY3U1Qzh6bUpkdz09OjoF5F7aH3W2+RFynWJp9+zO','OFUySDMyY2wrUDJNRmRDV3ZZOEFMUT09OjrRBoAY0IxgT+Xt5VX64Qoc','NzJrZm9Gay9VblJQWW5xOG0vYzVpUT09OjqsunGjY1LetCoveA9c5hg8','a1hwWU9EY2FsbUJON21Fdm0reldUdz09OjoOfkCzA+V8Jy0hXf1WBX73','RkFldkgwalV1U0JzZGhmZWVyQnpuQT09OjqznTKYexaMy85YA7xyf1/T','eHJRRXRYRTkrOElSSUwyYnpBTmpuUT09OjqYnob9kNQbdMbZH6We6IqZ','NHl0bVRXSHdJbFVQeTk5ajczZXQ2dz09OjpkRTdRCM6NymAxpLuIrI8F','N1AydUcxdDNuME5GTE5iSXg3QUQvdz09OjpBYUYlnD8DgXYzePQlu6Ac',0,0,0,0,0,0,0,1,'','',0,NULL,'2024-10-29 17:02:36'),(5,'ZlYxOUtsRVlMY2JMaklXR0xyU2Zxdz09OjoD7Qo7z8f9T7/MOQY6Rdax','V29DbUZTVGRoanE4Rnlkd2dPRFNlQT09OjpaoUYSzC0lRsq2tqxfqFKS','a3RPY3QrZjB2Ynp5YjFISlRpb2NhQT09OjrvDjqvj25WlynZK+eAXeNz','eFl5SlJqT0E5eWZ6aXZ3YlhQc2xNQT09OjpNjUUwgehcLMxCUcLmd5w1',NULL,'OEVBa215aVlBbWgvYVdVczIyYk1vZz09OjrBF5YTt0NRdbgwcf2JzYdV','OWJzdUc2RTl5L2NUSnN4YXhnSXhCUT09OjrHRsGAm5WZiez5kMnctMk3','ZnRIMmxyTDBvM0hjS1NEMzNKeldRUT09OjoXWYyU4EX3Sue1h8bLmt7R','bVVsT00wSmNkWDRYNStoN2NodTRDQT09OjrY+UpitkoeSKMwV1E4wR8R','Qy95R2Y2MTYvRGdOV3drV0NtdHdCUT09OjpaXIUZT3C3+nnD76qNhgo+','VVRWTUNHb290YjZvZWdJdElEd1ZhUT09Ojq7VAfngv1Wx0hLcsW1VFaI','SjBZZlpRb1BFckYxNzQxTzRXaDBGQT09Ojovm5V7Zw/sM4YHf67O6EWB','OVZ3UEdUN0RlOUFsV3loK1hKV3hYdz09OjpKGMTEPpSTHMU6dksJ8ue3','dkQySFpIL3BabTNpdjFmSkFBVVNwdz09OjpGaKmIlyPFibfyICbBmHWo','ZVZuakZHeDNOWEthaVp6SW53NUdFdz09OjoMNtyUWF2k4zU5dAftHOM0','WURZRHVaUkVqcHA0UVgzeERpbFY4QT09OjpEZZQv8n1oJvl2eiJMkwLx','d0RGUGlqRXdyWHBKTkZsNFV1R3dtQT09Ojpjjm1yX5vQJqMYiRXVo6uR','MXdWaWhOQ2dWcnphbnM3NVRHTHhqUT09OjosgcM0PSjUKrYeoH739hbR','c0EzYXZSVU4xSnlEbmhRcjA3SVJGQT09OjpizEAKPHi9yCSwmDeCRXbn','VjZ5cCtuMTB3YVRRSFRsakQ2NSs1Zz09OjqfkLin5U9ok7yCTEBSv9ZU','aUJpQUJpOWxCOXJKSmVGUTI0d0RCUT09OjrW0GHNm2AYx8t9XD9YIy+p','NWlBRHNLV3IwNlVzaS9QRTQ0RWNWZz09Ojr7Wso98x0fMURo5FgIVMdT','UnVvK3JKSkVod05laFRha3ZmU1lUZz09OjpMRuzlZgn0XAjjxBDoWcLT',0,0,0,0,0,0,0,1,'','',0,NULL,'2024-10-29 17:03:41'),(6,'aVFFdEwwWDd6UXF2S1lsV2s3a3QwQT09OjqwSckIHk/dokUREyT71aE4','cHNnUGVVbC9oMzJkMUc2TzhmWEJldz09OjoC8c95Q66EsMpoSanMwmDd','SVR2Rm8zYktrTHZuMU4rR1JLdGRVZz09OjrTZXxPydmpPkBU6lyreSlT','Y2Qza2hMR2dNbTNpcUlVQ1dhSFR3UT09OjqUj2YVA4NkD6SNNe5tcTjl',NULL,'UTdyaXNLRlJCZjBxY0RlQm9EVFFGdz09OjpmS0ovaNA13B112/WdgmSK','V1lSS2FvNnU3Vnhndy82TE04aXQ3QT09Ojo4IGPAXAyuxH0eO51HkK9t','blArZm1hU1V6SXdDOGtPa3lzanNSUT09OjqqJ6BS7kKs5r4G7jkP4UTZ','K3F2bVdlbERPcEZvN2RsaUtlQVUzdz09Ojp2okl0RrgDgnNmWMkdxxe9','cktUOHdyOXRRU1ZodXVCZkRwemtjUT09OjqdYH+YsRSkby7Zb9CZbP2/','MFg4dzc2SkFGUWVaTnl3ZHlLcWU2UT09Ojojf4wj67OVXhTB4m7uIp+2','REJuZGV5KzJ5OThDanQzL2tsdWszZz09Ojq1KMLcOU/uIFYXDVzGHEe1','dDAxZENtKzN5YVVhRlBSRllROU9wUT09Ojo48mOCnBQGwdtsbfDzHmKT','UnV3TFh1YW5rMGlEWkpsZzF5a3Fhdz09OjosysTwjmfUo8eA4xAG7BEO','Y2pFQkhIN2pvWUhra2REVXJDenk3UT09Ojo1H43++O3O3Dyh/B3bf3v4','RkY4bFMyVmgza1BFS05YVEdLK3d4UT09OjrtvzB7q5U/MerBlvkFN7Ii','N1EvSjRZckhIeWJ5eWZBYUhjcStEZz09Ojrd0r2AZzYAp5FX7G0UbhWh','eVJuOGQzM1JsbS9Bb0dXekY5OEM0Zz09OjqgUsajuLF6R5+0q4BgGyFJ','WnpCR0MvMndVeVJ0ZUZVRTlPQiswQT09OjpTHaxZReWwzykVW7ziBqdx','ZlpyTXlZOG1pTnJVVGoxV2QrSCsrUT09OjpGEwB65NVFp7Wn+M3NVwZc','Z0pJeUxmQWI0UTIwTEtFRkFvVnBGQT09Ojombb1aqq1pyprYSLBoix49','QTMxTXFheEdYOGg0YXI2cGVYSFNndz09OjqGQHGy7X/1JffxRsBdo7Di','SGUyOEVtR0IwNzlPZ0oxYlI3TEY4dz09OjrzMp6idOlD+QP23fBYTcAf',0,0,0,0,0,0,0,1,'','',0,NULL,'2024-10-29 17:04:59'),(7,'VkpHSmI0dkFrRTBUV1k2clhWcHRjQT09OjrP8hhPNpcLgpZpueXPDCgp','VW1CUSs5OTlPK1VOL0MzNXhKM2JtQT09OjrJWkhQzl6c8pigKLHwsUIh','d05CNGN1cllhVklkTUlOelRqdkhPUT09OjoGr4d/YF6ouNgmaItWqB4q','VzJxdWRTRG11T0xvY1Z2cXdsNDR2dz09OjrpP0peqQOHcfjoQBoyicTu',NULL,'VVRLY0VsdEo1bFBLWW1BcXUrRXJaQT09OjqbQ5aOMKsk4hb7uXzGkIM/','enFrR05ubWZjZEkzQmoxcnhOYklKdz09Ojrdu0bcEtYOIK2Sh0BjHTwi','WTQzNGJuckhLQlBMK1l6WjNpTmxvUT09OjrWd3xfBHJyH62xbBCoK+Eq','UXlDNERYVDhycEhSZ0JMR0phS1Q3Zz09OjqruzKrR6GjI+A3AC5IUp2p','dXJ0WjhOZzZBZXZNT1RkUjhVUFdjQT09Ojrq6a7UxGmxMdCzygr6TYJe','S2tQcmYxeFhkbGtUS2VYdG1SZUJRUT09OjqI92yL3kuZdWfVhtMUzQeT','eStRQTJKcTRpMU9QSUswaWp6ak1Ndz09OjrnRWbhgGPTN0Al0GpFb9Hp','YUxETGFZM1V3TlNWRVdRUTNoR2h6QT09OjoPR+j3nMLf6CzOs0JbB+Sr','WEt6b3U4YmxEMDhSNUgzQ3B2aTU0Zz09OjrpXhLkG/Ke8LDrRKzuJ5wk','OXB3eVJQZm9GeTZpQWtmOGZ3dE9GQT09OjrLm2XDCQPwxjxlVE1+bhSJ','UHM3cE5FL25ucVhBSStoWHZSNHdtdz09OjpMqND9CUo0PvlIEGnT8Hoq','TnhwWGVrRUZUc3JOWS81Vk5OeUYxZz09OjoCCC7OB5/nWLvKPQeDMuaO','WENsc2RmUHVjcVBhSE1EblZjSjBIUT09OjqzYr3958bVP7FhNpGbe6d7','UXJGUkorSFlXU1VEWVJvaVJYWVNwdz09OjqxGA5lX4Z+2wonEDbCi21G','dTlhMnhtczhKUlpBZmtpWmRyaTVidz09OjpzbFkRynLBwGo52ydW1Z1R','YWV0OC9aWW5wbjJZekdIWHdNM29GQT09OjqKyqvTy/GAwX+V/QAtebKM','em9GWmIybFhSODJINnd0WWRVUS9Mdz09Ojob+yRKHuDcVAZ3gXM7bvG6','VjNKVitBVzNtMS9zWVdyWFJidjJhdz09Ojr7EF2vaE5Ov+Zq9ElPF1MK',0,0,0,0,0,0,0,1,'','BTS.png',0,NULL,'2024-10-29 17:19:31'),(8,'VFdTVG0xb1ZNWFZMZjRCbVFNTjU4UT09OjqGtNNwcjbunIf1kJntSyDL','OVEyRDNGcHNud1dvbnVHTW9EeUFMZz09Ojq9EKD1TVNMQrSO2LDqnTRT','RVllREhJTnhvQmlSYUtBT3BnOWNBUT09OjpX9WRWeBwhzNoqgG4bpah7','MVlXRmROTUZndWd3Q0lHcE5DYWRJdz09Ojq/kv3ynalv2jzGIWWIOyIg',NULL,'VXdHa1RrT3p1WVJLOTJMcnd1aTIzUT09OjrpBTCpNjp3r9SUuhwQPgbM','bGNTd0QzTTZTV3psVnE5OU9pTzNvQT09OjqyileEVL1RXfLcauwjtF18','OWNUQThmOGd0YXFsNU0zYnRoRjZCQT09OjplOdCTqdWGhgvGEgt7RDzz','V2ZCR3RwdllXOTdBeDQydnp3bzFFZz09OjpIXdxDuOBkJp18B2iuzzzp','TFVqOWhCWVpBc3JBOCtFazlCNXpCdz09OjrduPD8q30oaVtWtgOCtZGB','WTIzK2FsSUcwOXY0Mnp5UlVmd0ZEUT09Ojqb0W31jZg1Z8hYeBsCq/+j','YzVCcm9GZC9tRklVTS9jRDl6WDlWQT09OjphE2KtxLNb9QjXfzgUC9eO','Qm5oaXhTUjBxQzBIUXFwSXNFdjVlQT09OjpAuoSpoFkeX+VmrmNIKFtv','dDRrdTVtc3pHRnJsUEpSdGxNWVQ0QT09Ojo2ghnTRCnq0xQrJrs376H+','bGppWlRuQjIzeVArbXhHNWt5ZmhVUT09OjqOoJfBLcqVPBs6485APG5b','SENkK1pDK05VbTVVTVFOTG9CdS9Rdz09OjoaYkAEHiWC5kvexrJazmNB','dWFTN0Q5UU1UcWpuL2JiZmVZY1Nkdz09OjrqXkmDAl4mnRYj0H/RxPVm','d2kyMHc0eHROVmhvUWxreWFmQTFmdz09Ojp3Crve/up5X61u9zHFIZi2','TUJKWWpXa2tGSFY5cDloaFdRUGN5Zz09OjpgLGHL1iGdyGh1fa4PACW0','TU9yR1ZjejdYK0k0K1FyRmEwV2t1UT09OjqPXggXJ/IgNC42EdF1bj4m','bStOenpib0xZeE9wa1Zwek1QZVJwZz09OjpeQeLBl7Y8ComeSpKMFnOV','aGozSmE4djNFeDVRbGpSbmFFVTllQT09OjpnDkN947SSYmIrRGX6HmSs','ZTRTNkRnZE1CKzRmUkpoeXRDVEtZQT09OjopXd6LlofEG5GoPOGPs5dH',0,0,0,0,0,0,0,1,'','BTS.png',0,NULL,'2024-10-29 17:38:03'),(9,'RnpnVGZXRWwxejdtdTA2UGhUSDRHZz09OjprvwXqSG/L8QZekSLC7lQh','cUxrMWtFdVpFQXBlY2ZJdVAzRDBFdz09OjpH6SH+zmAmsFxtCvt17dlE','L3RsOEUreWJYMWYwSXhWRHJqRVYvUT09OjpSbFhj1bjbFpz/srbYUS2T','WlhIZUZUZ2hIdkt0Rm9LTFR1akNRZz09Ojqg/yuR0U4fhVlYdtHZGEbs',NULL,'c0lhQUFwVG1sV1hEbVl3dk9memRhZz09OjpBkI+0TqZQe8Re4CVhZ/qx','c3R5azNkeG9idTIyQ1FaL3lRcTF0Zz09OjrzPQI4BAYL26vl6bnxUop9','UzZBNmMvTmRnR3d5Y1gxdDh5QjZiZz09OjrgH4ZJcZ8mQXDvMMWPLcCU','NzFOZVpLWkFUVzRDdU80RWRDVGZ1dz09OjpBlkbRjmQD6OIrzA6TPP3Z','N1FTcXNKMDhqS3pQL05nb1lrVzRJZz09Ojomc9i2MAHNNhjoEKkfoFtW','M0xQZklmT29mUFZTeTVBZXo0eDE1dz09OjqTI1xpAE2gXN6+8lqJ7wWO','VWgwWTFsUGZiUDB2OEpCRWJDTUFkQT09Ojo2YknzT7j0fZS83LiprC7O','YkJJQXFqaTNTNjBqQmxsRUJpL3dKdz09OjrCSyW9vptBWZGZH7mpi6v0','bjlLWDF6Uk1mNG9zTWhFcm1rRkZLQT09Ojr0PJDg4h/+9cs09CmO2OU+','YTlLMlZFaFlwek9PUW5ieFBZYncvQT09Ojq/qo8ypa6cxODtrueVEMfi','dWFDa3ZYMDBvL0hrUHZKVzlJcG4xUT09Ojo4Gt62SKq4Z2C/MRP17FR8','VGhia2R4Z0JvOWFxbmMxM1FXeTFRdz09Ojq5pJeautkWemiAtBoUTmXq','OXFYNXNJOEZWRmhnM0s1U3JVSXZndz09OjouEqI1fteN7wmqkH8DAqgg','TkZXOVVaQ1NObE5hZXBLWG12VFhLQT09OjqWueugJNCpFMLc16H4/dI/','aG5ISjVnWVpDWlpycVNGOTYybWJ3UT09OjonHQ7GtNaNhs4q+Zw+hBaP','TzFMdE9HWTB5cHgyNC9vWGpUUVFyZz09OjrZ1MYTkD3kjnQ2uhCGHZu/','QVZLQWhUYm1IZjlRelJwRXpWcGhudz09Ojq7ZVq/jbezbcmXoo4xNRMQ','N29qUU9hRnJXY0c0cTVFa09Bd3Zjdz09Ojq9B5KjEXRnTYxTvio3EHwT',0,0,0,0,0,0,0,1,'','BTS.png',0,NULL,'2024-10-29 17:39:50'),(10,'UHpHQ1lzdEdmaVNPNDdvc3VpVGljdz09OjpYfwbxbUkrIi24QR1swWLK','eHI1NDdBY2dLT0dHM2x4RllvUUlJUT09OjqTxWGSD9feHCLN8qSIpZIk','VGtxaHQ0M1J6TUlUOGthZ2JwOXI3Zz09OjpAaLGtTMBj2KxItZAMsTCk','NUNjR0ZEdWQ5NDg2Tm1VOG83NmVqQT09OjqSqIIYiy+K8AB+7F5JP7XF',NULL,'OXk5MWc3Y0IrTDFzR24yLzNhZkhydz09OjrJdbe66K1U4oaTqp2Y1Wm0','N0x5ZjdXeURGVnlBb2xJTjNuQjJuZz09Ojr6IPZsNfqYRumokbuaFPTn','VzB5eUU1ZnkyTFg1VVVVVGZwSGlpQT09OjrsRl9GOqlFalFMN7btIKu6','bkl4Z3dDZmRvTWxiZk5EVWo3Z3R6Zz09OjraknAZRjzvcyO8rY/yFAYF','OXVvUThnbGpLazN6MUR1TTh1a0xrZz09OjrUyrCtJVW6p0MdAWALiYUx','Yll4cEhMcDg0WmdXQ1NqSXRjdzUzUT09OjrqnfG+eNXMrBhYpf00z6Ke','bEFoNDZ6OG9iaEZqbDF5a1NzRTkxUT09OjoouGVaT+hekBV1okL+ryDt','NmsxTGFpdWxLY0wxSGZNQ1ZYUEdzUT09OjomJJ40Efm52pnfaYx9fS/x','djF3ellqd1g4Vm9GNXJ2N0g5Z0swZz09OjoX49ba6GMnzutuGQoS4zoj','Z1hmWlZoQTY1MmUwcjRVdXdJZmdJUT09Ojr5kT/NsrXdY/TjBldF00vI','OGdnREdxcGhReE9kN2RabW9iWmg0UT09OjooN7w2JKbvbbeMYCNgti49','NGQ5cmdxbmo5ZDVrU010dmJtaUU0Zz09Ojpc5Ps0F9l8m6UkhGq7UbbV','Yk5OUWM2ZFVOL05HakZZT0xnZEN6UT09OjpbIlliXtyTeO9M9NCD8n+D','RzdhRnhWTGFXY0RJWDk0cTJPamY1Zz09Ojoj7+XySp5y7ziegbp37OrF','YmFaZzJWK3U0bm8xU2psbkRJWERvQT09OjpdOG/MineFJhrB+6KW57hX','QVZLTndvVnNjTjdVeDB2TVZnNkRuZz09OjrMZ4mMLYls9Og497DCZ/fF','bnRyV3pxQ05yMk55RldRS0p3c1FTUT09OjoNRTNKWUBj0L5xZWgsA1FW','cXROdTc3T0N1akh5TmRCcllIajk3UT09Ojq1FgBxgEhEmftE2fhAvwEv',0,0,0,0,0,0,0,1,'','BTS.png',0,NULL,'2024-10-29 17:41:36'),(11,'L3cvL3NRUmN3d2tDbmhQQThsUXJLdz09OjqnS0PBrklPEROqUg0twhV5','Smh5c3k1WmRzb050aFFqK1NZbDJWQT09OjrjkWUSIQEY0Qau9LpRDIY2','MzNxTXVtVFhrLzBBSWtEb1FmeHBPZz09OjoWgwBo114+Vwd9Pf5jVlR0','c3pFVFdCZDVDRExuQS9Iai9EV1JmQT09OjpZ6oz5EcHM8yw3y0d9yxTI',NULL,'Y1VZbFkzczM1SWZaOVNZclFMUGRldz09OjpYedrc77hm38MvrXyaYtta','ejFmWnZCOG13anJaUGRLTUdqb0tyZz09OjoeBTzvEEeguHsak1e7AgGL','a0dmdm5xcWxLS21pREdySnVFY3RUdz09OjpDeshAWx1LnO4yPUI00Ml0','TjdydHZFdDBMK01pMERQblVYazVSUT09Ojoq1iayRcnfPrKzWSAqB2ne','Mm9kY2tQMXpYdUNPZWtWazZaMWE0QT09OjpX8VhfXLShfgXazfeFEXK1','MzhGOVV0YUROTWdESjdWdjY5VlpLdz09OjpNkMqeaSwTICFFsMqq0n+p','cXhjcUVtSFMwVllZRHBEaThaNU1Jdz09OjruVVNjmzAqqd8eb6vXDuIm','NVNUOTgrUnIwK01JMkxuY3JRWVlmdz09Ojod3Qs6sy9TPAt6iRpGOnbT','cWIvNkkyM1VuZjRDcnFFcGFsczg2UT09OjpHHXB1UkZa93GpqTnWIIjL','Y1B4SFdObFJCSVhobUM3TUVMWjhXdz09OjowxDEvgYE+QcRAEFkynTmE','bkN0ZUxUTzhWaHl6Z0lIQkY3RTBIdz09OjrAZnakwHzTwYJewOAWSQ5h','R1BJeG9SbFZqZjFSWU1GYmxUZ0dyZz09OjoGz3Hspfw1pPLUo3HqOSx9','VnMzMi9Dcy9wNk9GTXpkU3c4V09iUT09Ojp0b8ztjS5kRD92ZL5Fz1FA','MmVZMVJlNjQ4Y2ZkeHBZU2tQUUlaZz09Ojp+EG2PwTcP64zBrbyvAjco','cGpleXlSdEw2bGE2QWp6b0hYZUZuZz09OjoSREjDoWI6q/5oHysKuDQA','alFHTW9UMDNZUTd4TjJkaVZlVHpSdz09OjopdGIerOkYOd9oTtFq3qP1','dlRVSmJ2bWw1Y1NvRVY3ZllvS082Zz09Ojp9GUAiSGVZp8+1lMPGEAQX','VmJvZTQvZjZ6WlltVXhiaStrOUYvUT09OjoXwFwZyVJl3NntkS7jNzcu',0,0,0,0,0,0,0,1,'','BTS.png',0,NULL,'2024-10-29 17:42:03'),(12,'ZmY2a21ia09GVmMvWk9XWGhtd3RlQT09OjqCSZH3Lm0BSCxOdg2bJBR8','eFdsYXBMcnk2bG5tUE8zS04vUk5jQT09Ojq3F6H2KI5Z+cH9+M63iQZ0','eUl4MWE2blZ1bFViaU5XeEh5SGIzUT09OjpBsNhzmPf4IzWxvHrYOBvc','LzlXVTd3b3RlT1BUR3RGdmJsc1hWdz09OjrZ8Tf3SgdFOigw+aY2CSSk',NULL,'U1I5bXBkUEJxbGtNM3VNNVlTd0UrZz09Ojohlz703Skz6pQ3LnvSfM7R','NFVTcVBITHQwQi8yTWNkY0NUZjJSQT09OjqvvxEyaWAIgGb1efBgQi+R','UG5aRHFtUHRmZElkck51d0JBaHNuQT09OjqKX9rnpZ7wdQhFqo4etNzP','bTBrVUd5YW03b2tyM3o4T1VJWTZTQT09Ojp61prk2I/BsAiUZcGIRb6O','eTFTaGN2SWt0VUh0SmFJRnU2YWFBUT09OjqRYrj7cyVjS7yKEoL3XfXG','NGQvMzVJcXpRMlM1ZnNqbE9zb1hCdz09OjqSIo8PXNN9wu/JsrkUySXm','N2l2TTUzM1paTUhpbWNaNjFuSUZTZz09OjpzF8s2N7yL/zyH80CO7Uov','QkNZVGpGZXV3SkZ2eWVHd3RneTJSUT09OjrMmivWas6oWR6r/ZKi83eD','WDNtcjV1ZStnNFhXUXlUcllNL2xGUT09OjoA3t1AKakvcv4t2Bbl5Mlw','a01KM0xQS0ZWczhCaURhdEZYR2E0dz09OjpAl69x42f5y0XwrepHdv9z','S2lsaVh4UWhkOG1waHhuSER4ajRGQT09OjpUNH/AkiRoI+/Z6zpu7fP/','Z2NiWVh5em8rWG1ZZ2pseFhHQXlDdz09Ojox3ji4ZeHsU/C80roepBE8','MVo5VW9aR2tTVEhLWWtJZlUyOEtnQT09Ojp/scZ2ysXCYCDYJVws8bCO','WmE0TGJuaVdTdEJDbXV3dVo5dnNkZz09Ojp6hmkXksqIrUbPHnZ7dCy5','OHJ3cXRmekJocGZhcEJXZE9kbnJ3UT09OjrcmF7X4NX2rrt/r+CAM0iW','aEhJQURNanpvUmt5bnJjUHJBMGNIUT09OjozxxtLKoVcx1TDSotGuMeq','eXFSY0FVLzhhQ2tzZFpWVlpWVmNwZz09OjqfAUyuVXWkWaLhsDH6Jh4I','MlJESzNSYlQ1Zlo1V1hNM2cwWVJUQT09OjrpQz2LLm/BUqYwQmEB/K0P',0,0,0,0,0,0,0,1,'','Login.png',0,NULL,'2024-10-30 11:43:40');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trainors`
--

DROP TABLE IF EXISTS `trainors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainors` (
  `trainor_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `middle_name` text DEFAULT NULL,
  `last_name` text NOT NULL,
  `contact_number` text DEFAULT NULL,
  `email` text NOT NULL,
  `tesda_accreditation_no` text DEFAULT NULL,
  `expertise` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`trainor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainors`
--

LOCK TABLES `trainors` WRITE;
/*!40000 ALTER TABLE `trainors` DISABLE KEYS */;
INSERT INTO `trainors` VALUES (1,'Rene','Mazaredo','Sanque','09171234567','renes@example.com','T001','Automotive',1,NULL,'2024-10-29 13:07:38'),(2,'Marion','Abat','Pedrito','09281234567','marionp@example.com','T002','Bread and Pastry',1,NULL,'2024-10-29 13:07:38'),(3,'Apple','Rodriguez','Nillo','09391234567','applen@example.com','T003','Hairdressing',1,NULL,'2024-10-29 13:07:38'),(4,'Magdalena','Anong','Problema','09401234567','magdap@example.com','T004','Dressmaking',1,NULL,'2024-10-29 13:07:38'),(5,'Hyacent','Shahanie','Muripaga','09511234567','hyacentm@example.com','T005','Tailoring',1,NULL,'2024-10-29 13:07:38'),(6,'Sergei','Ghost','Sison','09621234567','sergeis@example.com','T006','Japanese Language',1,NULL,'2024-10-29 13:07:38'),(7,'Adah','Moo','Luken','09731234567','adahl@example.com','T007','Driving',1,NULL,'2024-10-29 13:07:38'),(8,'U3Y0bEZtOUJYMklIaHV0ZTY0aUJaZz09OjqnfzfAwaZNcYoQE21whx8B','dGpXZVdYVGxrVURHVUVpcE42NzB3QT09OjrM+qUGAUiOmFMur2u9Y1sN','eEhmS293bEtGRFI0OUN6UkVEYlArQT09Ojon6czbmm/sxOoUYGhahQRc','MlYrNzV5L0xEeDhPTEE4NWtUaU5UZz09Ojqn8HYMOzeLR+zU0LFNQnX2','ZCtrOUFlN2VJbnk3aTQ1TFFCQ3ZpUT09OjqA57ic4ezzX4eu5YRVJbOb','TUlKcmtaMTZpWWNyUEJ6SmhGc0Nudz09OjofcmRVkmG+GILQFWLsom2x','R0tldnVtcW5iY2Q4NUV0OFlERWUrUT09Ojri3mVn6NxHIn9aqgoMERPE',1,NULL,'2024-10-29 13:10:20'),(9,'TmFsRGlFZ3JEQUhORGVNVlI3WFQxZz09OjotjkwJUHxw01aZ+ly8A1ZQ','UW5vbkZNODNCK3B6ZWNlZXNETTNJUT09OjreaQbcHyVk0FeZueO6hVGi','UGJKOFU1cVlxL2RvSzFPUzdvZm5nUT09OjrIV3zzyiOFZvWY+r7DcE59','N29xTmo3U2k5MVJGdXZkS29pZCtOUT09OjplYaDA+IAzRxec8eFpEmAX','eVVlZDd5TlNwalJxTUpZUmVJd1E0ZVBzNTduN3NqWkIzZzNIdmZuYlYzVT06Op+CSJPcs4fE0wBTDUa2NPY=','ZldwTmRTMVlpR05rYllGYUgxOURjdz09Ojq5nr2gnhkZYe2CSo3fw/Xh','WFNUeGNQeHptL2FMdW4xWFBaWVBPdDNJQU01R0xGc1ozZnNIM04vVlhuST06Oh0kPj6oHsF5InruO+tR2eM=',0,NULL,'2024-10-30 12:02:47');
/*!40000 ALTER TABLE `trainors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `middle_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` text NOT NULL,
  `role` enum('Administrator','Registrar') NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'VnhFQUpSL3NrMjZsNUk3UmVqRGpkUT09OjpU4/Wy+eOQR/UyPMrh8DSr','MXhxaUxoRHpXT0VDU2svRFZmNGxmQT09Ojrr4ELlykarElIKlozM9c02','dHlGWTF5ejYzRWY2NkFhK1FmRVhaQT09Ojpt0kuh5Uwmh7kVuMoMAR4E','Admin','Administrator','$2y$10$cvXdLVSceAzv2GCN43FAcOqBYtxTF//BHLvgqV1d/of4ZU.gF5MHu','2024-10-29 13:43:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-31 15:58:56
