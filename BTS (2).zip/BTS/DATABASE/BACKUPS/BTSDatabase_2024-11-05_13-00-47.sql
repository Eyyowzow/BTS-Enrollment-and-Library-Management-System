-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: BTSDatabase
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assessments`
--

DROP TABLE IF EXISTS `assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assessments` (
  `assessment_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `assessment_name` text NOT NULL,
  `assessment_level` text DEFAULT NULL,
  `assessment_date` text DEFAULT NULL,
  `competency_title` text DEFAULT NULL,
  `assessor` text DEFAULT NULL,
  `location` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`assessment_id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  CONSTRAINT `assessments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `assessments_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessments`
--

LOCK TABLES `assessments` WRITE;
/*!40000 ALTER TABLE `assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `books_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_received` date DEFAULT NULL,
  `class` varchar(50) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title_of_book` varchar(255) DEFAULT NULL,
  `edition` varchar(50) NOT NULL,
  `volumes` varchar(50) NOT NULL,
  `pages` text DEFAULT NULL,
  `source_of_fund` varchar(50) NOT NULL,
  `cost_Price` text NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `location` varchar(50) NOT NULL,
  `year` text DEFAULT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`books_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `books_id` int(11) DEFAULT NULL,
  `date` text DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `course` varchar(255) NOT NULL,
  `status` enum('borrowed','returned') DEFAULT 'borrowed',
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `books_id` (`books_id`),
  CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `borrow_ibfk_2` FOREIGN KEY (`books_id`) REFERENCES `books` (`books_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow`
--

LOCK TABLES `borrow` WRITE;
/*!40000 ALTER TABLE `borrow` DISABLE KEYS */;
/*!40000 ALTER TABLE `borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dropped_students`
--

DROP TABLE IF EXISTS `dropped_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dropped_students` (
  `dropped_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `assessment_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `scholarship_id` int(11) DEFAULT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` text DEFAULT NULL,
  `phone` text DEFAULT NULL,
  `dropped_reason` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`dropped_id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `scholarship_id` (`scholarship_id`),
  CONSTRAINT `dropped_students_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `dropped_students_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `dropped_students_ibfk_3` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`),
  CONSTRAINT `dropped_students_ibfk_4` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`assessment_id`),
  CONSTRAINT `dropped_students_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`),
  CONSTRAINT `dropped_students_ibfk_6` FOREIGN KEY (`scholarship_id`) REFERENCES `scholarships` (`scholarship_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dropped_students`
--

LOCK TABLES `dropped_students` WRITE;
/*!40000 ALTER TABLE `dropped_students` DISABLE KEYS */;
/*!40000 ALTER TABLE `dropped_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `assessment_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `scholarship_id` int(11) DEFAULT NULL,
  `educational_attainment` text DEFAULT NULL,
  `employment` text DEFAULT NULL,
  `enrollment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `student_status` enum('enrolled','dropped','passed','failed') NOT NULL DEFAULT 'passed',
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `scholarship_id` (`scholarship_id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `enrollments_ibfk_3` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`),
  CONSTRAINT `enrollments_ibfk_4` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`assessment_id`),
  CONSTRAINT `enrollments_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`),
  CONSTRAINT `enrollments_ibfk_6` FOREIGN KEY (`scholarship_id`) REFERENCES `scholarships` (`scholarship_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_school_settings`
--

DROP TABLE IF EXISTS `library_school_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `library_school_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(255) NOT NULL,
  `school_address` text NOT NULL,
  `school_contact` varchar(100) NOT NULL,
  `school_email` varchar(100) NOT NULL,
  `school_logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_school_settings`
--

LOCK TABLES `library_school_settings` WRITE;
/*!40000 ALTER TABLE `library_school_settings` DISABLE KEYS */;
INSERT INTO `library_school_settings` VALUES (1,'Example School','123 Main St, Example City','123-456-7890','info@example.com','logo.png');
/*!40000 ALTER TABLE `library_school_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_users`
--

DROP TABLE IF EXISTS `library_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `library_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('Administrator','Librarian') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_users`
--

LOCK TABLES `library_users` WRITE;
/*!40000 ALTER TABLE `library_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` text NOT NULL,
  `program_code` text DEFAULT NULL,
  `level` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,'Agricultural Crops Production','P001','NC I','Training for agricultural crops production, covering fundamental techniques and practices.',0,NULL,'2024-11-05 11:58:40'),(2,'Agricultural Crops Production','P002','NC II','Advanced training for agricultural crops production, including more complex techniques and management.',0,NULL,'2024-11-05 11:58:40'),(3,'Automotive Servicing','P003','NC I','Training for basic automotive servicing, focusing on standard repair and maintenance tasks.',0,NULL,'2024-11-05 11:58:40'),(4,'Bread and Pastry Production','P004','NC II','Training in the production of bread and pastries, including techniques and best practices.',0,NULL,'2024-11-05 11:58:40'),(5,'Hairdressing','P005','NC II','Advanced training in hairdressing, including cutting, coloring, and styling techniques.',0,NULL,'2024-11-05 11:58:40'),(6,'Dressmaking','P006','NC II','Training in dressmaking, focusing on designing and creating custom garments.',0,NULL,'2024-11-05 11:58:40'),(7,'Tailoring','P007','NC II','Advanced tailoring training, including techniques for creating and altering various types of clothing.',0,NULL,'2024-11-05 11:58:40'),(8,'Japanese Language and Culture','P008','NC I','Comprehensive training in Japanese language and cultural practices.',0,NULL,'2024-11-05 11:58:40'),(9,'Driving','P009','NC II','Training for driving skills and techniques, focusing on road safety and vehicle operation.',0,NULL,'2024-11-05 11:58:40');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_code` text DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `batch_no` text DEFAULT NULL,
  `starts_date` text DEFAULT NULL,
  `end_date` text DEFAULT NULL,
  `days` text DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scholarships`
--

DROP TABLE IF EXISTS `scholarships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scholarships` (
  `scholarship_id` int(11) NOT NULL AUTO_INCREMENT,
  `scholarship_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `amount` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`scholarship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scholarships`
--

LOCK TABLES `scholarships` WRITE;
/*!40000 ALTER TABLE `scholarships` DISABLE KEYS */;
INSERT INTO `scholarships` VALUES (1,'Training for Work Scholarship Program (TWSP)','Training for Work Scholarship Program (TWSP)','5000.00',0,NULL);
/*!40000 ALTER TABLE `scholarships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_settings`
--

DROP TABLE IF EXISTS `school_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schoolId` text NOT NULL,
  `school` text NOT NULL,
  `region` text NOT NULL,
  `division` text NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_settings`
--

LOCK TABLES `school_settings` WRITE;
/*!40000 ALTER TABLE `school_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `school_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `ULI` text NOT NULL,
  `first_name` text NOT NULL,
  `middle_name` text DEFAULT NULL,
  `last_name` text NOT NULL,
  `suffix` text DEFAULT NULL,
  `birth_place` text NOT NULL,
  `birth_date` text NOT NULL,
  `gender` text NOT NULL,
  `marital_status` text NOT NULL,
  `citizenship` text NOT NULL,
  `email` text DEFAULT NULL,
  `fb_account` text DEFAULT NULL,
  `phone_number` text NOT NULL,
  `parent_firstname` text NOT NULL,
  `parent_lastname` text NOT NULL,
  `parent_middlename` text NOT NULL,
  `parent_phone` text DEFAULT NULL,
  `street_number` text DEFAULT NULL,
  `street_name` text DEFAULT NULL,
  `subdivision` text DEFAULT NULL,
  `barangay` text NOT NULL,
  `city` text NOT NULL,
  `province` text NOT NULL,
  `form_137` tinyint(1) DEFAULT 0,
  `report_card` tinyint(1) DEFAULT 0,
  `diploma` tinyint(1) DEFAULT 0,
  `completion_cert` tinyint(1) DEFAULT 0,
  `transcript_records` tinyint(1) DEFAULT 0,
  `birth_cert` tinyint(1) DEFAULT 0,
  `marriage_cert` tinyint(1) DEFAULT 0,
  `id_photo` tinyint(1) DEFAULT 0,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `attached` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'NnBtZWlNbGwveXJuN2lCcTlLNDRVZz09Ojrmb7udbZSWCzLmyAdltKrm','MUc4b1VLYUkwT1pGMWl5UG9Nd25XUT09OjoTOiAEerG4uYmGaxIesN4/','T2RkcXpQODlTN2xGQ0h0M3FGcXA4UT09OjofilqVeJvMD8fnAlVuZyWW','OUdDb3FLa2xTUTJxd1BZMkI5SXdHZz09OjrWmuIdvE2AvM7qTqhUiXwf',NULL,'Y1d2dnJGeXp0ZU1FYzZtWHo0QnVzUT09OjqhZG2Pi9ckYLDZhihv/eAR','NlZLTTlaV1FrZ21RM0MxVTJPMDRsUT09Ojrb48/REeu6/2MqL8AQEU6v','NTZnYlFXOVZrTUFzTTdTZ29EYjc1dz09Ojq6XJexvgwC1bURf9ePvBq2','UitQUnlwdFlxdFlqWmFSRnJWQXVQQT09OjrrkLonZE83TclXpw6LbOvo','NFptWlIyYjk3WFRtTndsaUpaWXdmdz09OjrxmwuFQGwSt6nd4WPwbNPm','ajFub2tqd094RStZd0FFV3EyeVIrZz09OjquwHMDnF23zOx2Zfj1Vcgs','NXQ4Z3JUTE5IaUlnbDRWYUxRai9rUT09OjrqN2LjsmFZf4sLrPIG3HIc','bTdOaGNWS3RlWis5NVNQdjJWd2UwZz09OjrB4yF8jVeamn4T3yy/dMIR','eFlRSWpCWDdiQXBWNlFZUXdpVk1SZz09OjpF+b/+hdgWLeN8u4Hr0Lav','N2ZoTnI4bjdQK1hQR2dQY0w0dGZmZz09OjpXzRuJpWgSfMTQLCSRXqto','eFhsU1FYTnQwU3FZT1FjTHJCd01ZUT09OjqGcdgcQw+oLuhKyhINivjI','Mmo0Y3ZiTlRvVThxSmt2Tjhvb3d3UT09OjqvYuq6i1ZDDhUWjpEwB7+Q','Nnl5NFoxTE0rTFJXdGdlZEdSR3NpQT09OjrsS0hup2DgAtNOpxblbOqk','YTlCUC9zMkIxT2pnelNJVzRCa1FYZz09OjoLAEiv/fX1Ty//SNGpEdWB','eFB1SHh2K2dEazgySVBMV2Rqa2JpZz09OjrlV70nMv5nJmnkgWhWmBCq','N1pkZHdpVGF3czk4WHNoSHUrTWRhQT09OjpXr02KA0xLJyuuywxLK8p9','ZFRrRmZ2bktSeGh3V2dZMzZUK0pOZz09Ojqh/91hJPTplnzHOmTZkLNG','VXFlaW45TzlaYTVQVWh0OEZlZlhXdz09OjpX3SjHhwscN+GAdzjt/V3I',0,0,0,0,0,1,0,0,'','',0,NULL,'2024-11-05 12:00:18');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trainors`
--

DROP TABLE IF EXISTS `trainors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainors` (
  `trainor_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `middle_name` text DEFAULT NULL,
  `last_name` text NOT NULL,
  `contact_number` text DEFAULT NULL,
  `email` text NOT NULL,
  `tesda_accreditation_no` text DEFAULT NULL,
  `expertise` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`trainor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainors`
--

LOCK TABLES `trainors` WRITE;
/*!40000 ALTER TABLE `trainors` DISABLE KEYS */;
INSERT INTO `trainors` VALUES (1,'Rene','Mazaredo','Sanque','09171234567','renes@example.com','T001','Automotive',0,NULL,'2024-11-05 11:58:40'),(2,'Marion','Abat','Pedrito','09281234567','marionp@example.com','T002','Bread and Pastry',0,NULL,'2024-11-05 11:58:40'),(3,'Apple','Rodriguez','Nillo','09391234567','applen@example.com','T003','Hairdressing',0,NULL,'2024-11-05 11:58:40'),(4,'Magdalena','Anong','Problema','09401234567','magdap@example.com','T004','Dressmaking',0,NULL,'2024-11-05 11:58:40'),(5,'Hyacent','Shahanie','Muripaga','09511234567','hyacentm@example.com','T005','Tailoring',0,NULL,'2024-11-05 11:58:40'),(6,'Sergei','Ghost','Sison','09621234567','sergeis@example.com','T006','Japanese Language',0,NULL,'2024-11-05 11:58:40'),(7,'Adah','Moo','Luken','09731234567','adahl@example.com','T007','Driving',0,NULL,'2024-11-05 11:58:40');
/*!40000 ALTER TABLE `trainors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `middle_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` text NOT NULL,
  `role` enum('Administrator','Registrar') NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'cm56NUx0aVdIY3IwOEdvV1l3L21oQT09OjoJ0No0zDFUxiKZ1iQKClgR','cURXRklxcDJNazNTK1hJR2ltV01LQT09OjqdAMWGNrnKE4dUo6P7lyae','RUxpQ3JpV3psSFhCNjVxRXdSbnI4UT09OjoLIi4awv1HSazMa6v8Ei0z','Admin','Administrator','$2y$10$mQKKysAX5f/7NL1CPbQR.OJ7wcyqen3QILVD0L6qFkjQ7utUAqU3q','2024-11-05 11:59:02');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-05 20:01:13
