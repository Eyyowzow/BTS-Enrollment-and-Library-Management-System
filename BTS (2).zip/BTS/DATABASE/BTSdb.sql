CREATE DATABASE BTSDatabase;
USE BTSDatabase;

-- ***** DATABASE TABLE FOR ENROLLMENT SYSTEM ***** 

-- Table for storing students
CREATE TABLE students (
    -- Personal Details
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    ULI TEXT NOT NULL,
    first_name TEXT NOT NULL, 
    middle_name TEXT,
    last_name TEXT NOT NULL,
    suffix TEXT,
    birth_place TEXT NOT NULL,
    birth_date TEXT NOT NULL,  
    gender TEXT NOT NULL,
    marital_status TEXT NOT NULL,
    citizenship TEXT NOT NULL,

    -- Personal Contact Information
    email TEXT,
    fb_account TEXT, 
    phone_number TEXT NOT NULL, 

    -- Parent/Guardian Information
    parent_firstname TEXT NOT NULL, 
    parent_lastname TEXT NOT NULL,
    parent_middlename TEXT NOT NULL,
    parent_phone TEXT,

    -- Current Address
    street_number TEXT,
    street_name TEXT,
    subdivision TEXT,
    barangay TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT NOT NULL,

    -- Requirements Checkboxes
    form_137 BOOLEAN DEFAULT 0,
    report_card BOOLEAN DEFAULT 0,
    diploma BOOLEAN DEFAULT 0,
    completion_cert BOOLEAN DEFAULT 0,
    transcript_records BOOLEAN DEFAULT 0,
    birth_cert BOOLEAN DEFAULT 0,  
    marriage_cert BOOLEAN DEFAULT 0,
    id_photo BOOLEAN DEFAULT 0,

    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    attached TEXT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Table for storing programs
CREATE TABLE programs (
    program_id INT AUTO_INCREMENT PRIMARY KEY,
    program_name TEXT NOT NULL,
    program_code TEXT,
    level TEXT,
    description TEXT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for storing trainors
CREATE TABLE trainors (
    trainor_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name TEXT NOT NULL,
    middle_name TEXT,
    last_name TEXT NOT NULL,
    contact_number TEXT,
    email TEXT NOT NULL,
    tesda_accreditation_no TEXT,
    expertise TEXT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for storing assessments
CREATE TABLE assessments (
    assessment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    program_id INT,
    assessment_name TEXT NOT NULL,
    assessment_level TEXT,
    assessment_date TEXT,
    competency_title TEXT,
    assessor TEXT,
    location TEXT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (program_id) REFERENCES programs(program_id)
);

-- Table for storing schedules
CREATE TABLE schedules (
    schedule_id INT AUTO_INCREMENT PRIMARY KEY,
    schedule_code TEXT,
    program_id INT,
    batch_no TEXT,
    starts_date TEXT,
    end_date TEXT,
    days TEXT,
    trainor_id INT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (program_id) REFERENCES programs(program_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (trainor_id) REFERENCES trainors(trainor_id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table for storing scholarships
CREATE TABLE scholarships (
    scholarship_id INT AUTO_INCREMENT PRIMARY KEY,
    scholarship_name TEXT,
    description TEXT,
    amount TEXT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL
);

-- Table for storing enrollments
CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    program_id INT,
    trainor_id INT,
    assessment_id INT,
    schedule_id INT NULL,
    scholarship_id INT,
    educational_attainment TEXT,
    employment TEXT,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    student_status ENUM('enrolled', 'dropped', 'passed', 'failed') NOT NULL DEFAULT 'passed',
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (program_id) REFERENCES programs(program_id),
    FOREIGN KEY (trainor_id) REFERENCES trainors(trainor_id),
    FOREIGN KEY (assessment_id) REFERENCES assessments(assessment_id),
    FOREIGN KEY (schedule_id) REFERENCES schedules(schedule_id),
    FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id)
);

CREATE TABLE enroll_assessment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    assessment_id INT,
    student_status ENUM('enrolled', 'dropped', 'passed', 'failed') NOT NULL DEFAULT 'passed',
    educational_attainment TEXT,
    employment TEXT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (assessment_id) REFERENCES assessments(assessment_id)
);

-- Table for archiving students
CREATE TABLE dropped_students (
    dropped_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    program_id INT,
    trainor_id INT,
    assessment_id INT,
    schedule_id INT,
    scholarship_id INT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    dropped_reason TEXT,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (program_id) REFERENCES programs(program_id),
    FOREIGN KEY (trainor_id) REFERENCES trainors(trainor_id),
    FOREIGN KEY (assessment_id) REFERENCES assessments(assessment_id),
    FOREIGN KEY (schedule_id) REFERENCES schedules(schedule_id),
    FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id)
);

-- Table for user_setting
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name TEXT NOT NULL,
    middle_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    username TEXT NOT NULL,
    role ENUM('Administrator', 'Registrar') NOT NULL, 
    user_password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for school_settings
CREATE TABLE school_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    schoolId TEXT NOT NULL,
    school TEXT NOT NULL,
    region TEXT NOT NULL,
    division TEXT NOT NULL,
    address TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ********************************************
-- ***** DATABASE TABLE FOR LIBRAY SYSTEM ***** 
-- ********************************************

CREATE TABLE books (
  books_id INT AUTO_INCREMENT PRIMARY KEY,
  date_received date NULL,
  class VARCHAR(50) NOT NULL,
  author VARCHAR(255) NOT NULL,
  title_of_book VARCHAR(255),
  edition VARCHAR(50) NOT NULL,
  volumes VARCHAR(50) NOT NULL,
  pages TEXT,
  source_of_fund VARCHAR(50) NOT NULL,
  cost_Price TEXT NOT NULL,
  publisher VARCHAR(255) NOT NULL,
  location VARCHAR(50) NOT NULL,
  year TEXT,
  remarks TEXT NOT NULL
);

-- Dumping structure for table library_inventory.borrow
CREATE TABLE borrow (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT, 
  books_id INT,
  date TEXT NULL,
  name VARCHAR(255) NULL,
  author VARCHAR(255) NULL,
  course VARCHAR(255) NOT NULL,
  status ENUM('borrowed', 'returned') DEFAULT 'borrowed',
  FOREIGN KEY (id) REFERENCES enrollments(id),
  FOREIGN KEY (books_id) REFERENCES books(books_id)
);
-- Create library_school_settings table
CREATE TABLE IF NOT EXISTS `library_school_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_name` VARCHAR(255) NOT NULL,
  `school_address` TEXT NOT NULL,
  `school_contact` VARCHAR(100) NOT NULL,
  `school_email` VARCHAR(100) NOT NULL,
  `school_logo` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create library_users table
CREATE TABLE IF NOT EXISTS `library_users` (
  `user_id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(255) NOT NULL,
  `role` ENUM('Administrator', 'Librarian') NOT NULL, 
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `library_school_settings` (`school_name`, `school_address`, `school_contact`, `school_email`, `school_logo`) 
VALUES ('Example School', '123 Main St, Example City', '123-456-7890', 'info@example.com', 'logo.png');

-- Programs
INSERT INTO programs (program_code, program_name, level, description) VALUES
('P001', 'Agricultural Crops Production', 'NC I', 'Training for agricultural crops production, covering fundamental techniques and practices.'),
('P002', 'Agricultural Crops Production', 'NC II', 'Advanced training for agricultural crops production, including more complex techniques and management.'),
('P003', 'Automotive Servicing', 'NC I', 'Training for basic automotive servicing, focusing on standard repair and maintenance tasks.'),
('P004', 'Bread and Pastry Production', 'NC II', 'Training in the production of bread and pastries, including techniques and best practices.'),
('P005', 'Hairdressing', 'NC II', 'Advanced training in hairdressing, including cutting, coloring, and styling techniques.'),
('P006', 'Dressmaking', 'NC II', 'Training in dressmaking, focusing on designing and creating custom garments.'),
('P007', 'Tailoring', 'NC II', 'Advanced tailoring training, including techniques for creating and altering various types of clothing.'),
('P008', 'Japanese Language and Culture', 'NC I', 'Comprehensive training in Japanese language and cultural practices.'),
('P009', 'Driving', 'NC II', 'Training for driving skills and techniques, focusing on road safety and vehicle operation.');

-- Trainors
INSERT INTO trainors (first_name, middle_name, last_name, contact_number, email, tesda_accreditation_no, expertise) VALUES
('Rene', 'Mazaredo', 'Sanque', '09171234567', 'renes@example.com', 'T001', 'Automotive'),
('Marion', 'Abat', 'Pedrito', '09281234567', 'marionp@example.com', 'T002', 'Bread and Pastry'),
('Apple', 'Rodriguez', 'Nillo', '09391234567', 'applen@example.com', 'T003', 'Hairdressing'),
('Magdalena', 'Anong', 'Problema', '09401234567', 'magdap@example.com', 'T004', 'Dressmaking'),
('Hyacent', 'Shahanie', 'Muripaga', '09511234567', 'hyacentm@example.com', 'T005', 'Tailoring'),
('Sergei', 'Ghost', 'Sison', '09621234567', 'sergeis@example.com', 'T006', 'Japanese Language'),
('Adah', 'Moo', 'Luken', '09731234567', 'adahl@example.com', 'T007', 'Driving');

-- Scholarships
INSERT INTO scholarships (scholarship_name, description, amount) VALUES
('Training for Work Scholarship Program (TWSP)', 'Training for Work Scholarship Program (TWSP)', 5000.00);
