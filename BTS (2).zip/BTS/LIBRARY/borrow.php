<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit();
}

$success_message = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addBorrow'])) {
    $date = $_POST['date'];
    $name = $_POST['name'];
    $title_of_book = $_POST['title_of_book'];

    $stmt = $conn->prepare(
        "INSERT INTO borrow (date, name, title_of_book) 
         VALUES (?, ?, ?)"
    );
    $stmt->bind_param("sss", $date, $name, $title_of_book,);

    if ($stmt->execute()) {
        $success_message = "Book added successfully!";
    } else {
        $error_message = "Error: " . $conn->error;
    }
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Book</title>
</head>
<body>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Borrowed Books List</h4>
                    <p class="mb-0">List of Borrowers</p>
                </div>
            </div>
        </div>
        <?php if ($success_message): ?>
                <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                    <span><i class="mdi mdi-account-search"></i></span>
                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                        <span><i class="mdi mdi-close"></i></span>
                    </button> 
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($error_message)): ?>
                <div class='alert alert-danger'><?php echo $error_message; ?></div>
            <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Book Title</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM borrow";
                                    $result = mysqli_query($conn, $sql);

                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['title_of_book']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                                            echo "<td>
                                                <a class='btn btn-primary btn-sm' href='update_borrow.php?id=" . $row['id'] . "' 
                                                    onclick='return confirm(\"Are you sure you want to update this record?\");'>
                                                    <i class='fa fa-edit' style='color: green; font-size: 15px;'></i> <!-- Blue -->
                                                </a>
                                                <a class='btn btn-success btn-sm' href='return_borrow.php?id=" . $row['id'] . "' 
                                                    onclick='return confirm(\"Are you sure this book is being returned?\");'>                                                                
                                                    <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i> 
                                                </a>
                                                <a class='btn btn-danger btn-sm' href='delete_borrow.php?id=" . $row['id'] . "' 
                                                    onclick='return confirm(\"Are you sure you want to delete this record?\");'>
                                                    <i class='fa fa-trash' style='color: red; font-size: 15px;'></i>                                          
                                                </a>
                                            </td>";
                                            echo "</tr>";
                                        }
                                    } 
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Name</th>
                                        <th>Book Title</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 3000); 
        }
    };
    </script>
<script src="../bootstrap/vendor/global/global.min.js"></script>
<script src="../bootstrap/js/quixnav-init.js"></script>
<script src="../bootstrap/js/custom.min.js"></script>
<script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="../bootstrap/js/plugins-init/datatables.init.js"></script>


</body>
</html>
