<!DOCTYPE html>
<body>
<div class="quixnav">
    <div class="quixnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li><a href="./Dashboard.php"><i class="icon icon-home"></i>
                <span class="nav-text">Dashboard</span></a>
            </li> 
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-form"></i><span class="nav-text">Data Entry</span></a>
                <ul aria-expanded="false">
                    <li><a href="./add_book.php">Add New Book</a></li>
                    <li><a href="./add_borrow.php">Add Borrower</a></li>
                </ul>
            </li>
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-layout-25"></i><span class="nav-text">Book Lists</span></a>
                <ul aria-expanded="false">
                    <li><a href="./book.php">Book Masterlist</a></li>
                    <li><a href="./borrow.php">Borrower</a></li>
                </ul>
            </li>
            <?php if ($_SESSION['role'] === 'Administrator') : ?>
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-settings"></i>
                <span class="nav-text">Settings</span></a>
                <ul aria-expanded="false">
                    <li><a href="./user_settings.php">User Settings</a></li>
                    <li><a href="./school_settings.php">School Settings</a></li>
                    <li><a href="./backup.php">Back Up</a></li>
                </ul>
            </li>
            <?php endif; ?>
            <li><a href="./login.php" aria-expanded="false">
                <i class="icon icon-plug"></i><span class="nav-text">Logout</span></a>
            </li>
        </ul>
    </div>
</div>
<!--Sidebar end-->
