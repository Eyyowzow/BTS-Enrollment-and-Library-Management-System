<?php
session_start();

include 'header.php';
include 'sidebar.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit();
}

$success_message = '';
$error_message = '';

// Handle form submission for adding a book
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addBook'])) {
    // Collect form data
    $title_of_book = $_POST['title_of_book'];
    $author = $_POST['author'];
    $edition = $_POST['edition'];
    $volumes = $_POST['volumes'];
    $source_of_fund = $_POST['source_of_fund'];
    $publisher = $_POST['publisher'];
    $year = $_POST['year'];
    $pages = $_POST['pages'];
    $cost_Price = $_POST['cost_Price'];
    $date_received = $_POST['date_received'];
    $location = $_POST['location'];
    $class = $_POST['class'];
    $remarks = $_POST['remarks'];

    // Prepare and execute the SQL query to add the book
    $stmt = $conn->prepare(
        "INSERT INTO books (title_of_book, author, edition, volumes, source_of_fund, publisher, year, pages, cost_Price, date_received, location, class, remarks) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        "sssssssssssss", 
        $title_of_book, $author, $edition, $volumes, $source_of_fund, 
        $publisher, $year, $pages, $cost_Price, $date_received, $location, 
        $class, $remarks
    );

    if ($stmt->execute()) {
        $success_message = "Book added successfully!";
    } else {
        $error_message = "Error: " . $conn->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
</head>
<body>

<!-- Display alert message if available -->
<?php if (!empty($alert_message)) : ?>
    <div class="alert alert-info"><?php echo $alert_message; ?></div>
<?php endif; ?>

<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Book Masterlist</h4>
                    <p class="mb-0">Book Lists</p>
                </div>
            </div>
        </div>
        <?php if ($success_message): ?>
                <div class="alert alert-primary solid alert-right-icon alert-dismissible fade show" id="alertMessage"> 
                    <span><i class="mdi mdi-account-search"></i></span>
                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                        <span><i class="mdi mdi-close"></i></span>
                    </button> 
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($error_message)): ?>
                <div class='alert alert-danger'><?php echo $error_message; ?></div>
            <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Add Book</h5>
                    </div>

                    <div class="card-body">
                        <!-- Book List Table -->
                        <div class="table-responsive">
                            <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Author</th>
                                        <th>Title of Book</th>
                                        <th>Publisher</th>
                                        <th>Year</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Fetch books from the database
                                    $sql = "SELECT * FROM books";
                                    $result = mysqli_query($conn, $sql);
                                    $count = 1;

                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<tr>";
                                            echo "<td>" . $count++ . "</td>";
                                            echo "<td>" . htmlspecialchars($row['author']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['title_of_book']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['publisher']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['year']) . "</td>";
                                            echo "<td>
                                                <a class=' btn-sm' href='update.php?books_id=" . $row['books_id'] . "' 
                                                    onclick='return confirm(\"Are you sure you want to update this book?\");'>
                                                    <i class='fa fa-edit' style='color: green; font-size: 15px;'></i>
                                                </a>
                                                <a class='btn-sm' href='view.php?books_id=" . $row['books_id'] . "'>
                                                <i class='fa fa-eye' style='color: blue; font-size: 15px;'></i>
                                                </a>
                                                <a class='btn-sm' href='delete.php?books_id=" . $row['books_id'] . "' 
                                                    onclick='return confirm(\"Are you sure you want to delete this book?\");'>
                                                    <i class='fa fa-trash' style='color: red; font-size: 15px;'></i>

                                                </a>
                                                
                                            </td>";
                                            echo "</tr>";
                                        }
                                    } 
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Author</th>
                                        <th>Title of Book</th>
                                        <th>Publisher</th>
                                        <th>Year</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    window.onload = function() {
        const alert = document.getElementById('alertMessage');
        if (alert) {
            setTimeout(() => {
                alert.style.display = 'none'; 
            }, 3000); 
        }
    };
    </script>s
<!-- Required JS Scripts -->
<script src="../bootstrap/vendor/global/global.min.js"></script>
<script src="../bootstrap/js/quixnav-init.js"></script>
<script src="../bootstrap/js/custom.min.js"></script>
<script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="../bootstrap/js/plugins-init/datatables.init.js"></script>


</body>
</html>
