<?php
require_once "../Database/Database.php"; 
$return = '';

if (isset($_POST['query']) && isset($_POST['search_type'])) {
    $search = "%" . $_POST['query'] . "%";
    $search_type = $_POST['search_type'];

    if ($search_type == 'books') {
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT * FROM books 
                                WHERE books_id LIKE ? 
                                OR author LIKE ? 
                                OR title_of_book LIKE ? 
                                OR publisher LIKE ? 
                                OR year LIKE ?");
        $stmt->bind_param("sssss", $search, $search, $search, $search, $search);
    } elseif ($search_type == 'users') {
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT * FROM users 
                                WHERE user_id LIKE ? 
                                OR name LIKE ? 
                                OR email LIKE ?");
        $stmt->bind_param("sss", $search, $search, $search);
    } elseif ($search_type == 'borrowers') {
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT * FROM borrow 
                                WHERE student_id LIKE ? 
                                OR number LIKE ? 
                                OR title_of_book LIKE ? 
                                OR name LIKE ?");
        $stmt->bind_param("ssss", $search, $search, $search, $search);
    }

    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Default query to fetch all books
    $query = "SELECT * FROM books";
    $result = mysqli_query($conn, $query);
}

if ($result->num_rows > 0) {
    $return .= '
    <table border="1" width="100%" id="table">
    <tr style="background:rgba(0, 148, 50,1.0); color:#fff">';
    
    if ($search_type == 'books') {
        $return .= '
        <th align="left">Book Title</th>
        <th align="left">Author</th>
        <th align="left">Publisher</th>
        <th align="left">Year</th>
        <th align="right">Actions</th>
        </tr>';
    } elseif ($search_type == 'users') {
        $return .= '
        <th align="left">User ID</th>
        <th align="left">Name</th>
        <th align="left">Email</th>
        <th align="right">Actions</th>
        </tr>';
    } elseif ($search_type == 'borrowers') {
        $return .= '
        <th align="left">Date</th>
        <th align="left">Student ID</th>
        <th align="left">Book Number</th>
        <th align="left">Book Title</th>
        <th align="left">Name</th>
        <th align="right">Actions</th>
        </tr>';
    }

    while ($row = $result->fetch_assoc()) {
        $return .= '<tr>';
        if ($search_type == 'books') {
            $return .= '
            <td>' . htmlspecialchars($row['title_of_book']) . '</td>
            <td>' . htmlspecialchars($row['author']) . '</td>
            <td>' . htmlspecialchars($row['publisher']) . '</td>
            <td>' . htmlspecialchars($row['year']) . '</td>
            <td>
                <a class="btn btn-primary btn-sm" href="update.php?number=' . urlencode($row['number']) . '">Update</a>
                <a class="btn btn-danger btn-sm" href="delete.php?number=' . urlencode($row['number']) . '" onclick="return confirm(\'Are you sure you want to delete this book?\')">Delete</a>
                <a class="btn btn-info btn-sm" href="view.php?number=' . urlencode($row['number']) . '">View</a>
            </td>';
        } elseif ($search_type == 'users') {
            $return .= '
            <td>' . htmlspecialchars($row['user_id']) . '</td>
            <td>' . htmlspecialchars($row['name']) . '</td>
            <td>' . htmlspecialchars($row['email']) . '</td>
            <td>
                <a class="btn btn-primary btn-sm" href="update_user.php?user_id=' . urlencode($row['user_id']) . '">Update</a>
                <a class="btn btn-danger btn-sm" href="delete_user.php?user_id=' . urlencode($row['user_id']) . '" onclick="return confirm(\'Are you sure you want to delete this user?\')">Delete</a>
                <a class="btn btn-info btn-sm" href="view_user.php?user_id=' . urlencode($row['user_id']) . '">View</a>
            </td>';
        } elseif ($search_type == 'borrowers') {
            $return .= '
            <td>' . htmlspecialchars($row['date']) . '</td>
            <td>' . htmlspecialchars($row['student_id']) . '</td>
            <td>' . htmlspecialchars($row['number']) . '</td>
            <td>' . htmlspecialchars($row['title_of_book']) . '</td>
            <td>' . htmlspecialchars($row['name']) . '</td>
            <td>
                <a class="btn btn-primary btn-sm" href="update_borrow.php?id=' . urlencode($row['id']) . '">Update</a>
                <a class="btn btn-danger btn-sm" href="delete_borrow.php?id=' . urlencode($row['id']) . '" onclick="return confirm(\'Are you sure you want to delete this record?\')">Delete</a>
            </td>';
        }
        $return .= '</tr>';
    }

    $return .= '</table>';
} else {
    $return = '<p>No results found matching your search criteria.</p>';
}

// Close statement if used
if (isset($stmt)) {
    $stmt->close();
}

// Close database connection
$conn->close();

echo $return;
?>