<?php
include '../Database/Database.php'; // DB connection

// Check if 'id' is provided in the query string
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Option 1: Delete the borrow record (if you want to remove it from the borrow table)
    $stmt = $conn->prepare("DELETE FROM borrow WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Book returned successfully!'); window.location.href = 'borrow.php';</script>";
    } else {
        echo "<script>alert('Error returning book: " . $stmt->error . "'); window.location.href = 'borrow.php';</script>";
    }

    // Option 2: Mark the book as returned (if you want to keep a record but mark it as returned)
     $stmt = $conn->prepare("UPDATE borrow SET status = 'returned' WHERE id = ?");
     $stmt->bind_param("i", $id);
     if ($stmt->execute()) {
         echo "<script>alert('Book marked as returned!'); window.location.href = 'borrow.php';</script>";
     } else {
         echo "<script>alert('Error marking book as returned: " . $stmt->error . "'); window.location.href = 'borrow.php';</script>";
     }

    $stmt->close();
}

// Close the connection
$conn->close();
?>
