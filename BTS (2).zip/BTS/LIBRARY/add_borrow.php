<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit();
} 

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Book</title>
</head>

<body>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Add Book</h4>
                    <p class="mb-0">Adding of Book Form</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Add Book</a></li>
                    <li class="breadcrumb-item active"><a href="./Dashboard.php">Home</a></li>
                </ol>
            </div>
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <form method="POST" action="borrow.php" >
                            <div>
                                <div class="row">
                                    <div class="col-lg-12 mb-12">
                                    <center><h4 ID="addBorrow">ADD BOOK BORROWER FORM</h4></center>
                                    <hr>
                                </div>
                                <div class="col-lg-9 mb-12">
                                    <div class="form-group">
                                        <label class="text-label" for="student_name">Student's Name</label>
                                        <span class="text-danger">*</span>
                                        <div class="input-group">
                                        <input type="text" id="student_name" class="form-control" name="student_name" placeholder="Search Student Name" autocomplete="off" required>
                                        <input type="hidden" name="student_id" id="student_id" value="">

                                        <div class="input-group">
                                                <ul id="studentList" style="list-style-type: none;"></ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3 mb-12">
                                    <div class="form-group">
                                    <label for="date">Date:</label>
                                        <span class="text-danger">*</span>
                                        <div class="input-group">
                                        <input type="date" id="date" name="date" class="form-control" required>
                                        <div class="input-group"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-10 mb-12">
                                    <div class="form-group">
                                    <label for="title_of_book">Book Title:</label>
                                        <span class="text-danger">*</span>
                                        <div class="input-group">
                                        <input type="text" id="book_title" name="book_title" class="form-control" autocomplete="off" placeholder="Enter Book Title" required>
                                        <div id="bookSuggestions" class="list-group"></div>
                                        <div class="input-group"></div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-lg-12 mb-12">
                                <center><button type="submit" class="btn btn-primary" name="addBorrow">Add Borrower</button></center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include your JS or Bootstrap scripts -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>

    <script src="../bootstrap/vendor/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="../bootstrap/vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Form validate init -->
    <script src="../bootstrap/js/plugins-init/jquery.validate-init.js"></script>
    <!-- Form step init -->
    <script src="../bootstrap/js/plugins-init/jquery-steps-init.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
    $('#student_name').keyup(function() {
        let query = $(this).val();
        if (query != '') {
            $.ajax({
                url: "fetch_student.php",
                method: "POST",
                data: { query: query, type: 'student' },
                success: function(data) {
                    $('#studentList').fadeIn();
                    $('#studentList').html(data);
                }
            });
        } else {
            $('#studentList').fadeOut();
        }
    });

    //ULI
    $(document).on('click', '#studentList li', function() {
        $('#student_name').val($(this).text());
        $('#uli').val($(this).data('uli'));
        $('#studentList').fadeOut();
    }); 

    $(document).click(function(event) {
        if (!$(event.target).closest('#student_name, #studentList').length) {
            $('#studentList').fadeOut();
        }
    });
});
</script>


<script>
    
document.getElementById('book_title').addEventListener('input', function() {
    const query = this.value;
    if (query.length < 2) {
        document.getElementById('bookSuggestions').innerHTML = '';
        return;
    }

    fetch(`fetch_books.php?query=${query}`)
        .then(response => response.json())
        .then(data => {
            let suggestions = '';
            data.forEach(book => {
                suggestions += `<a href="javascript:void(0);" class="list-group-item list-group-item-action" onclick="selectBook('${book}')">${book}</a>`;

            });
            document.getElementById('bookSuggestions').innerHTML = suggestions;
        });
});

function selectBook(book) {
    document.getElementById('book_title').value = book;
    document.getElementById('bookSuggestions').innerHTML = '';
}
</script>
</body>

</html>

<?php
$conn->close();
?>
