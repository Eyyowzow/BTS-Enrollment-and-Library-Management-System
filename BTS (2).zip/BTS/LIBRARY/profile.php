<?php 
include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php"); 
    exit();
}

// FETCH USERS
$user_id = $_SESSION['user_id'];
$query = "SELECT full_name, username, password FROM library_users WHERE user_id = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die('MySQL prepare error: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// After fetching user data
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $full_name = $user['full_name'];
    $username = $user['username'];
    $hashed_password = $user['password'];

    // Set the full_name in the session if needed
    $_SESSION['full_name'] = $full_name; // Make sure you have this line
} else {
    echo "User not found.";
    exit();
}

$success_message = "";
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Removed the "Form submitted!" message
    $new_account_name = trim($_POST['full_name']);
    $new_username = trim($_POST['username']);
    $new_password = $_POST['new_password'];
    $current_password = $_POST['current_password']; 
    
    if (password_verify($current_password, $hashed_password)) { 
        $update_query = "UPDATE library_users SET full_name = ?, username = ? WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_query);

        if ($update_stmt === false) {
            die('MySQL prepare error: ' . htmlspecialchars($conn->error));
        }

        $update_stmt->bind_param("ssi", $new_account_name, $new_username, $user_id);
        $update_stmt->execute();

        // Update hashed password if provided
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_password_query = "UPDATE library_users SET password = ? WHERE user_id = ?";
            $update_password_stmt = $conn->prepare($update_password_query);

            if ($update_password_stmt === false) {
                die('MySQL prepare error: ' . htmlspecialchars($conn->error));
            }
            $update_password_stmt->bind_param("si", $hashed_password, $user_id);
            $update_password_stmt->execute();
        }

        // Set success message and update the displayed variables
        $success_message = "Profile updated successfully!";
        // Update displayed variables with new data
        $full_name = $new_account_name; // use updated account name
        $username = $new_username; // use updated username
    } else {
        echo "<script>alert('Current password is incorrect.');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Library Management System</title>
</head>
<body>
    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4>Hi <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h4>
                        <p class="mb-0">This is your profile.</p>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Profile</a></li>
                        <li class="breadcrumb-item active"><a href="./Dashboard.php">Back</a></li>
                    </ol>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="profile-tab">
                            <div class="custom-tab-1">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a href="#about-me" data-toggle="tab" class="nav-link active">Account Setting</a></li>
                                </ul>
                                <div class="pt-4 border-bottom-1 pb-4">
                                    <h5 class="text-primary">Change Password</h5>
                                    <form action="profile.php" method="POST">
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="full_name">Account Name</label>
                                                <input type="text" id="account_name" name="full_name" placeholder="Account Name" class="form-control" value="<?php echo htmlspecialchars($full_name); ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="username">Username</label>
                                            <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" required>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="current_password">Current Password</label>
                                                <input type="password" id="current_password" name="current_password" placeholder="Current Password" class="form-control" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="new_password">New Password</label>
                                                <input type="password" id="new_password" name="new_password" placeholder="New Password" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input" id="gridCheck" required>
                                                <label for="gridCheck" class="form-check-label">Confirm the above information is correct.</label>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                        <?php if (!empty($success_message)): ?>
                                            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($error_message)): ?>
                                            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
                                        <?php endif; ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>                
        </div>
    </div>
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
</body>
</html>
