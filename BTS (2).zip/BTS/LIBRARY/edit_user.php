
<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
    <form method="POST" action="user_settings.php">
        <div class="modal-header">
        <h5 class="modal-title" id="editUserLabel">Edit User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
        <input type="hidden" name="user_id" id="editUserId">
        <div class="form-group">
            <label for="editAccountName">Account Name</label>
            <input type="text" class="form-control" id="editAccountName" name="full_name" required>
        </div>
        <div class="form-group">
            <label for="editUsername">Username</label>
            <input type="text" class="form-control" id="editUsername" name="username" required>
        </div>
        <div class="form-group">
            <label for="editPassword">Password (Leave blank if not changing)</label>
            <input type="password" class="form-control" id="editPassword" name="password">
        </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" name="editUser" class="btn btn-primary">Save Changes</button>
        </div>
    </form>
    </div>
</div>
</div>
<script>
 $(document).on('click', '.edit-btn', function() {
    var userId = $(this).data('id');
    var accountName = $(this).data('accountname');
    var username = $(this).data('username');

    $('#editUserId').val(userId);
    $('#editAccountName').val(accountName);
    $('#editUsername').val(username);

    $('#editPassword').val(''); 
    });
</script>
