<?php
include '../Database/Database.php';
    if (isset($_GET["books_id"])) {
        $books_id = $_GET["books_id"];
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "DELETE FROM books WHERE books_id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $books_id); 
        if ($stmt->execute()) {
            echo "<script>alert('Deleted Successfully!'); window.location.href = 'book.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        $stmt->close();
        $conn->close();
    }
?>

    