<?php
include 'session_start.php';
include '../Database/Database.php';
$user_full_name = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'Guest';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Benguet Technical School Library System </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../bootstrap/images/logo.png">
    <link rel="stylesheet" href="../bootstrap/vendor/owl-carousel/css/owl.carousel.min.css">
    <link href="../bootstrap/vendor/jquery-steps/css/jquery.steps.css" rel="stylesheet">
    <link href="../bootstrap/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../bootstrap/vendor/owl-carousel/css/owl.theme.default.min.css">
    <link href="../bootstrap/vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">    
    <link href="vendor/jquery-steps/css/jquery.steps.css" rel="stylesheet">
    <link href="../bootstrap/css/style1.css" rel="stylesheet">
<style>

.profile-name {
    font-size: 14px;            
    color: #2f3542;          
    letter-spacing: 0.3px;     
    font-family: 'Segoe UI', Tahoma, Geneva, sans-serif; 
    white-space: nowrap;        
}

.profile-link:hover .profile-name {
    color: #4b7bec;            
}
.profile-icon-wrapper {
    position: relative; 
    display: inline-block;
}

.pulse-css {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 60px; 
    height: 60px; 
    border-radius: 50%; 
    background: rgba(0, 150, 255, 0.5); 
    transform: translate(-50%, -50%); 
    animation: pulse-animation 2s infinite;
    z-index: 0;
}

@keyframes pulse-animation {
    0% {
        transform: translate(-50%, -50%) scale(0.5); 
        opacity: 1; 
    }
    50% {
        transform: translate(-50%, -50%) scale(1); 
        opacity: 0; 
    }
    100% {
        transform: translate(-50%, -50%) scale(0.5);
        opacity: 1; 
    }
}

.mdi-account {
    position: relative; 
    z-index: 1; 
}

</style>
</head>

<body>
    <div id="main-wrapper">
        <div class="nav-header">
            <a href="Dashboard.php" class="brand-logo">
                <img class="logo-abbr" src="../bootstrap/images/logo.png" alt="">
                <img class="logo-compact" src="../bootstrap/images/logo-text.png" alt="">
                <img class="brand-title" src="../bootstrap/images/logo-text.png" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>        
                </div>
            </div>
        </div>
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="search_bar dropdown">
                                <span class="search_icon p-3 c-pointer" data-toggle="dropdown">
                                </span>

                                <div class="dropdown-menu p-0 m-0">
                                    <form>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <ul class="navbar-nav header-right">
                            <li class="nav-item dropdown header-profile">
                                <div class="profile-icon-wrapper">
                                    <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                        <i class="mdi mdi-account">
                                        <span class="profile-name">&nbsp<?php echo htmlspecialchars($user_full_name); ?></span>

                                        </i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a href="profile.php" class="dropdown-item">
                                            <i class="icon-user"></i>
                                            <span class="ml-2">Profile</span>
                                        </a>
                                        <a href="login.php" class="dropdown-item">
                                            <i class="icon-key"></i>
                                            <span class="ml-2">Logout</span>
                                        </a>
                                    </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>