<?php
include '../Database/Database.php';

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    $delete_sql = "DELETE FROM library_users WHERE user_id = $user_id";
    
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('User deleted successfully');</script>";
    } else {
        echo "<script>alert('Error deleting user: " . $conn->error . "');</script>";
    }
}

header("Location: user_settings.php");
exit();
?>
