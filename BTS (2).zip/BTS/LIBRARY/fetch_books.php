<?php
include '../Database/Database.php'; 
if (isset($_GET['query'])) {
    $search_term = mysqli_real_escape_string($conn, $_GET['query']);

    $sql = "SELECT title_of_book FROM books WHERE title_of_book LIKE '%$search_term%' LIMIT 5";
    $result = mysqli_query($conn, $sql);

    $book_titles = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $book_titles[] = $row['title_of_book'];
    }

    // Return as JSON
    echo json_encode($book_titles);
}
?>