<?php
include 'header.php';
include 'sidebar.php';

if (isset($_GET['books_id'])) {
    $books_id = $_GET['books_id'];

    $sql = "SELECT * FROM books WHERE books_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $books_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Populate variables with book data.
        $title_of_book = $row['title_of_book'];
        $author = $row['author'];
        $edition = $row['edition'];
        $volumes = $row['volumes'];
        $source_of_fund = $row['source_of_fund'];
        $publisher = $row['publisher'];
        $year = $row['year'];
        $pages = $row['pages'];
        $cost_Price = $row['cost_Price'];
        $date_received = $row['date_received'];
        $class = $row['class'];
        $remarks = $row['remarks'];
    } else {
        echo "<script>alert('Book not found!'); window.location.href='book.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('No book ID provided!'); window.location.href='book.php';</script>";
    exit();
}

// Handle form submission to update book details.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $books_id = $_POST['books_id'];
    $title_of_book = $_POST['title_of_book'];
    $author = $_POST['author'];
    $edition = $_POST['edition'];
    $volumes = $_POST['volumes'];
    $source_of_fund = $_POST['source_of_fund'];
    $publisher = $_POST['publisher'];
    $year = $_POST['year'];
    $pages = $_POST['pages'];
    $cost_Price = $_POST['cost_Price'];
    $date_received = $_POST['date_received'];
    $class = $_POST['class'];
    $remarks = $_POST['remarks'];

    // Update query with correct data binding.
    $sql = "
        UPDATE books 
        SET title_of_book = ?, author = ?, edition = ?, volumes = ?, 
            source_of_fund = ?, publisher = ?, year = ?, pages = ?, 
            cost_Price = ?, date_received = ?, class = ?, remarks = ? 
        WHERE books_id = ?
    ";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error in SQL: " . $conn->error);
    }

    $stmt->bind_param(
        "sssissiidsssi", 
        $title_of_book, $author, $edition, $volumes, 
        $source_of_fund, $publisher, $year, $pages, 
        $cost_Price, $date_received, $class, $remarks, $books_id
    );

    if ($stmt->execute()) {
        echo "<script>alert('Book updated successfully!'); window.location.href = 'book.php';</script>";
    } else {
        echo "<script>alert('Update failed: " . $stmt->error . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Book - Benguet Technical School Library</title>
</head>
<body>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Update Book</h4>
                    <p class="mb-0">Modify book details</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Books</a></li>
                    <li class="breadcrumb-item active"><a href="./Dashboard.php">Home</a></li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="books_id" value="<?php echo $books_id; ?>">

                            <h4 class="text-center">UPDATE BOOK FORM</h4>
                            <hr>

                            <div class="form-group">
                                <label>Book Title</label>
                                <input type="text" name="title_of_book" class="form-control" 
                                       value="<?php echo $title_of_book; ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Author</label>
                                <input type="text" name="author" class="form-control" 
                                       value="<?php echo $author; ?>">
                            </div>

                            <div class="form-group">
                                <label>Edition</label>
                                <input type="text" name="edition" class="form-control" 
                                       value="<?php echo $edition; ?>">
                            </div>

                            <div class="form-group">
                                <label>Volumes</label>
                                <input type="text" name="volumes" class="form-control" 
                                       value="<?php echo $volumes; ?>">
                            </div>

                            <div class="form-group">
                                <label>Source of Fund</label>
                                <input type="text" name="source_of_fund" class="form-control" 
                                       value="<?php echo $source_of_fund; ?>">
                            </div>

                            <div class="form-group">
                                <label>Publisher</label>
                                <input type="text" name="publisher" class="form-control" 
                                       value="<?php echo $publisher; ?>">
                            </div>

                            <div class="form-group">
                                <label>Year</label>
                                <input type="number" name="year" class="form-control" 
                                       value="<?php echo $year; ?>">
                            </div>

                            <div class="form-group">
                                <label>Pages</label>
                                <input type="number" name="pages" class="form-control" 
                                       value="<?php echo $pages; ?>">
                            </div>

                            <div class="form-group">
                                <label>Cost Price</label>
                                <input type="number" step="0.01" name="cost_Price" class="form-control" 
                                       value="<?php echo $cost_Price; ?>">
                            </div>

                            <div class="form-group">
                                <label>Date Received</label>
                                <input type="date" name="date_received" class="form-control" 
                                       value="<?php echo $date_received; ?>">
                            </div>

                            <div class="form-group">
                                <label>Class</label>
                                <input type="text" name="class" class="form-control" 
                                       value="<?php echo $class; ?>">
                            </div>

                            <div class="form-group">
                                <label>Remarks</label>
                                <input type="text" name="remarks" class="form-control" 
                                       value="<?php echo $remarks; ?>">
                            </div>
                            <div class="col-lg-12 mb-12">
                                <button type="submit" class="btn btn-primary">Update Book</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
</body>
</html>
