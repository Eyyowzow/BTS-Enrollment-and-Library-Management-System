

CREATE TABLE `assessments` (
  `assessment_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `assessment_name` text NOT NULL,
  `assessment_level` text DEFAULT NULL,
  `assessment_date` text DEFAULT NULL,
  `competency_title` text DEFAULT NULL,
  `assessor` text DEFAULT NULL,
  `location` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`assessment_id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  CONSTRAINT `assessments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `assessments_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO assessments VALUES("1","","","Ny8xd3BUVUxOWWVZTzVKdmgycmRWZz09Ojq30EhrN/feZpe9AEAVDB1M","bTg5L0RySUZVU1U5RHB4ZmxRWW9CQT09Ojp84hF2dBckJ5Pe86ucAlLh","SHJPNFEvdEVrVHM1MU1pbnI4RFB5UT09Ojrte1uWEjg61s39LWMi3+E0","ZDRST1hiZFNWc21aNTFVcmZJUnZndz09OjpxZrB2+Sc01TGAi2HiTtWm","clRmaFUvUXZNTkUybGl0M2V0RlJWdz09OjqUtAvONPnA2LO4BfBF/06P","SXl3Ykw3VFdYaWZVdTBQM3F0aElLdz09OjriEgh9ynbtn4F6fLOcD3/0","0","");



CREATE TABLE `books` (
  `books_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_received` date DEFAULT NULL,
  `class` varchar(50) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title_of_book` varchar(255) DEFAULT NULL,
  `edition` varchar(50) NOT NULL,
  `volumes` varchar(50) NOT NULL,
  `pages` text DEFAULT NULL,
  `source_of_fund` varchar(50) NOT NULL,
  `cost_Price` text NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `location` varchar(50) NOT NULL,
  `year` text DEFAULT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`books_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO books VALUES("1","0000-00-00","","A","cinderella","","","","","","","","","");



CREATE TABLE `borrow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `books_id` int(11) DEFAULT NULL,
  `date` text DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `course` varchar(255) NOT NULL,
  `status` enum('borrowed','returned') DEFAULT 'borrowed',
  PRIMARY KEY (`id`),
  KEY `books_id` (`books_id`),
  CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`id`) REFERENCES `enrollments` (`id`),
  CONSTRAINT `borrow_ibfk_2` FOREIGN KEY (`books_id`) REFERENCES `books` (`books_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `dropped_students` (
  `dropped_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `assessment_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `scholarship_id` int(11) DEFAULT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` text DEFAULT NULL,
  `phone` text DEFAULT NULL,
  `dropped_reason` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`dropped_id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `scholarship_id` (`scholarship_id`),
  CONSTRAINT `dropped_students_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `dropped_students_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `dropped_students_ibfk_3` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`),
  CONSTRAINT `dropped_students_ibfk_4` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`assessment_id`),
  CONSTRAINT `dropped_students_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`),
  CONSTRAINT `dropped_students_ibfk_6` FOREIGN KEY (`scholarship_id`) REFERENCES `scholarships` (`scholarship_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `enroll_assessment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `assessment_id` int(11) DEFAULT NULL,
  `student_status` enum('enrolled','dropped','passed','failed') NOT NULL DEFAULT 'passed',
  `educational_attainment` text NOT NULL,
  `employment` text NOT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `assessment_id` (`assessment_id`),
  CONSTRAINT `enroll_assessment_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `enroll_assessment_ibfk_2` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`assessment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `assessment_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `scholarship_id` int(11) DEFAULT NULL,
  `educational_attainment` text DEFAULT NULL,
  `employment` text DEFAULT NULL,
  `enrollment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `student_status` enum('enrolled','dropped','passed','failed') NOT NULL DEFAULT 'passed',
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `scholarship_id` (`scholarship_id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`),
  CONSTRAINT `enrollments_ibfk_3` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`),
  CONSTRAINT `enrollments_ibfk_4` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`assessment_id`),
  CONSTRAINT `enrollments_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`),
  CONSTRAINT `enrollments_ibfk_6` FOREIGN KEY (`scholarship_id`) REFERENCES `scholarships` (`scholarship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO enrollments VALUES("1","1","","","","","","Tertiary Education","","2024-11-11 22:05:32","enrolled","0","");
INSERT INTO enrollments VALUES("2","1","","","","","","Tertiary Education","","2024-11-11 22:11:16","enrolled","0","");
INSERT INTO enrollments VALUES("3","1","","","","","","Tertiary Education","","2024-11-11 22:11:27","enrolled","0","");
INSERT INTO enrollments VALUES("4","1","","","","","","Tertiary Education","","2024-11-11 22:11:54","enrolled","0","");
INSERT INTO enrollments VALUES("5","1","","","","","","Tertiary Education","","2024-11-11 22:13:08","enrolled","0","");
INSERT INTO enrollments VALUES("6","1","","","","","","Tertiary Education","","2024-11-11 22:13:16","enrolled","0","");
INSERT INTO enrollments VALUES("7","1","","","","","","Tertiary Education","","2024-11-11 22:14:51","enrolled","0","");
INSERT INTO enrollments VALUES("8","1","","","","","","Tertiary Education","","2024-11-11 22:16:29","enrolled","0","");
INSERT INTO enrollments VALUES("9","1","","","","","","Tertiary Education","","2024-11-11 22:16:54","enrolled","0","");
INSERT INTO enrollments VALUES("15","1","1","1","","1","1","Tertiary Education","","2024-11-11 22:25:28","enrolled","0","");
INSERT INTO enrollments VALUES("16","1","1","1","","1","1","Primary Education","","2024-11-11 22:58:25","enrolled","0","");
INSERT INTO enrollments VALUES("18","1","1","1","","1","","Tertiary Education","","2024-11-12 00:15:40","","0","");
INSERT INTO enrollments VALUES("19","1","1","1","","1","","Tertiary Education","","2024-11-12 00:16:57","","0","");
INSERT INTO enrollments VALUES("20","1","1","1","","1","","Tertiary Education","","2024-11-12 00:20:38","","0","");
INSERT INTO enrollments VALUES("21","1","1","1","","1","","Tertiary Education","","2024-11-12 00:21:38","","0","");
INSERT INTO enrollments VALUES("22","1","1","1","","1","1","Tertiary Education","","2024-11-12 00:22:01","","0","");
INSERT INTO enrollments VALUES("23","1","1","1","","1","1","Tertiary Education","","2024-11-12 00:25:08","enrolled","0","");
INSERT INTO enrollments VALUES("24","1","1","1","","1","","Tertiary Education","","2024-11-12 00:25:49","enrolled","0","");
INSERT INTO enrollments VALUES("25","1","1","1","","1","","Tertiary Education","","2024-11-12 00:39:01","enrolled","0","");
INSERT INTO enrollments VALUES("26","1","1","1","","1","","Tertiary Education","","2024-11-12 00:39:59","enrolled","0","");
INSERT INTO enrollments VALUES("27","1","1","1","","1","","Tertiary Education","","2024-11-12 00:42:10","enrolled","0","");
INSERT INTO enrollments VALUES("28","1","1","1","","1","","Tertiary Education","","2024-11-12 00:42:45","enrolled","0","");
INSERT INTO enrollments VALUES("29","1","1","1","","1","1","Post-Secondary Education","","2024-11-12 00:45:42","enrolled","0","");
INSERT INTO enrollments VALUES("30","1","1","1","","1","1","Post-Secondary Education","","2024-11-12 00:52:42","enrolled","0","");
INSERT INTO enrollments VALUES("31","1","1","1","","1","","Tertiary Education","","2024-11-12 00:53:20","enrolled","0","");
INSERT INTO enrollments VALUES("32","1","1","1","","1","","Tertiary Education","","2024-11-12 00:53:31","enrolled","0","");
INSERT INTO enrollments VALUES("33","1","1","1","","1","","Tertiary Education","","2024-11-12 00:57:27","enrolled","0","");
INSERT INTO enrollments VALUES("34","1","1","1","","1","","Tertiary Education","","2024-11-12 00:58:02","enrolled","0","");
INSERT INTO enrollments VALUES("35","1","1","1","","1","","Tertiary Education","","2024-11-12 01:08:17","enrolled","0","");
INSERT INTO enrollments VALUES("36","1","1","1","","1","1","Tertiary Education","","2024-11-12 01:11:22","enrolled","1","");
INSERT INTO enrollments VALUES("37","1","1","1","","1","","Tertiary Education","","2024-11-12 01:11:52","enrolled","0","");
INSERT INTO enrollments VALUES("38","1","1","1","","1","","Tertiary Education","","2024-11-12 01:20:44","enrolled","0","");
INSERT INTO enrollments VALUES("39","1","1","1","","1","","Tertiary Education","","2024-11-12 01:21:45","enrolled","0","");
INSERT INTO enrollments VALUES("40","1","1","1","","1","","Tertiary Education","","2024-11-12 01:21:56","enrolled","0","");
INSERT INTO enrollments VALUES("41","1","1","1","","1","","Tertiary Education","","2024-11-12 01:27:07","enrolled","0","");
INSERT INTO enrollments VALUES("42","1","1","1","","1","","Tertiary Education","","2024-11-12 01:30:10","enrolled","0","");
INSERT INTO enrollments VALUES("43","1","1","1","","1","","Tertiary Education","","2024-11-12 01:31:52","enrolled","0","");
INSERT INTO enrollments VALUES("44","1","1","1","","1","","Tertiary Education","","2024-11-12 01:31:59","enrolled","0","");
INSERT INTO enrollments VALUES("45","1","1","1","","1","","Tertiary Education","","2024-11-12 01:33:09","enrolled","0","");
INSERT INTO enrollments VALUES("46","1","1","1","","1","","Tertiary Education","","2024-11-12 01:33:57","enrolled","0","");
INSERT INTO enrollments VALUES("47","1","1","1","","1","","Tertiary Education","","2024-11-12 01:34:32","enrolled","0","");
INSERT INTO enrollments VALUES("48","1","1","1","","1","","Tertiary Education","","2024-11-12 01:35:02","enrolled","0","");
INSERT INTO enrollments VALUES("49","1","1","1","","1","","Tertiary Education","","2024-11-12 01:35:38","enrolled","0","");
INSERT INTO enrollments VALUES("50","1","1","1","","1","","Tertiary Education","","2024-11-12 01:36:33","enrolled","0","");
INSERT INTO enrollments VALUES("51","1","1","1","","1","","Tertiary Education","","2024-11-12 01:36:58","enrolled","0","");
INSERT INTO enrollments VALUES("52","1","1","1","","1","","Tertiary Education","","2024-11-12 01:37:10","enrolled","0","");



CREATE TABLE `library_school_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(255) NOT NULL,
  `school_address` text NOT NULL,
  `school_contact` varchar(100) NOT NULL,
  `school_email` varchar(100) NOT NULL,
  `school_logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO library_school_settings VALUES("1","Example School","123 Main St, Example City","123-456-7890","info@example.com","logo.png");



CREATE TABLE `library_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('Administrator','Librarian') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO library_users VALUES("1","Admin","$2y$10$2lVOUd0fe2Db7Oj5188EjekeLJoigE2p/n8oY1bujLorkcpzgI4MS","Admin User","Administrator");



CREATE TABLE `programs` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` text NOT NULL,
  `program_code` text DEFAULT NULL,
  `level` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO programs VALUES("1","Agricultural Crops Production","P001","NC I","Training for agricultural crops production, covering fundamental techniques and practices.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("2","Agricultural Crops Production","P002","NC II","Advanced training for agricultural crops production, including more complex techniques and management.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("3","Automotive Servicing","P003","NC I","Training for basic automotive servicing, focusing on standard repair and maintenance tasks.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("4","Bread and Pastry Production","P004","NC II","Training in the production of bread and pastries, including techniques and best practices.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("5","Hairdressing","P005","NC II","Advanced training in hairdressing, including cutting, coloring, and styling techniques.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("6","Dressmaking","P006","NC II","Training in dressmaking, focusing on designing and creating custom garments.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("7","Tailoring","P007","NC II","Advanced tailoring training, including techniques for creating and altering various types of clothing.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("8","Japanese Language and Culture","P008","NC I","Comprehensive training in Japanese language and cultural practices.","0","","2024-11-11 21:00:48");
INSERT INTO programs VALUES("9","Driving","P009","NC II","Training for driving skills and techniques, focusing on road safety and vehicle operation.","0","","2024-11-11 21:00:48");



CREATE TABLE `schedules` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_code` text DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `batch_no` text DEFAULT NULL,
  `starts_date` text DEFAULT NULL,
  `end_date` text DEFAULT NULL,
  `days` text DEFAULT NULL,
  `trainor_id` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `program_id` (`program_id`),
  KEY `trainor_id` (`trainor_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`program_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`trainor_id`) REFERENCES `trainors` (`trainor_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO schedules VALUES("1","","1","1","2024-11-11","2024-11-11","1","1","0","");



CREATE TABLE `scholarships` (
  `scholarship_id` int(11) NOT NULL AUTO_INCREMENT,
  `scholarship_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `amount` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`scholarship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO scholarships VALUES("1","Training for Work Scholarship Program (TWSP)","Training for Work Scholarship Program (TWSP)","5000.00","0","");



CREATE TABLE `school_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schoolId` text NOT NULL,
  `school` text NOT NULL,
  `region` text NOT NULL,
  `division` text NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `ULI` text NOT NULL,
  `first_name` text NOT NULL,
  `middle_name` text DEFAULT NULL,
  `last_name` text NOT NULL,
  `suffix` text DEFAULT NULL,
  `birth_place` text NOT NULL,
  `birth_date` text NOT NULL,
  `gender` text NOT NULL,
  `marital_status` text NOT NULL,
  `citizenship` text NOT NULL,
  `email` text DEFAULT NULL,
  `fb_account` text DEFAULT NULL,
  `phone_number` text NOT NULL,
  `parent_firstname` text NOT NULL,
  `parent_lastname` text NOT NULL,
  `parent_middlename` text NOT NULL,
  `parent_phone` text DEFAULT NULL,
  `street_number` text DEFAULT NULL,
  `street_name` text DEFAULT NULL,
  `subdivision` text DEFAULT NULL,
  `barangay` text NOT NULL,
  `city` text NOT NULL,
  `province` text NOT NULL,
  `form_137` tinyint(1) DEFAULT 0,
  `report_card` tinyint(1) DEFAULT 0,
  `diploma` tinyint(1) DEFAULT 0,
  `completion_cert` tinyint(1) DEFAULT 0,
  `transcript_records` tinyint(1) DEFAULT 0,
  `birth_cert` tinyint(1) DEFAULT 0,
  `marriage_cert` tinyint(1) DEFAULT 0,
  `id_photo` tinyint(1) DEFAULT 0,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `attached` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO students VALUES("1","SkdGZUJ4SkFwaGlwcC90TWNFbkZ0dz09OjrGobHqkvkiX5uPD3S/81cT","RURzZEUrelBUUFRtUTdldjNNK0VHZz09OjqCp/GYZm95T4tR9kl4YIh2","emFQRmNPMEM4eDNwc0tHQ0NzM3FDUT09OjrgtY5vb9WAlGMpiS64MrUi","YzZzT2NRQ3lwSXI5RUFRWVlZL0ZjQT09Ojp7yR6Kzbt7+QxgNcE9Mdrv","","Z1N1TlplRFhCQkJzK05CUE9Kdy9BZz09OjqzLU/sDnvVox5YZ5D0EQfQ","RVNYUkFTQ2dmcjdWTlhuc2hJR0o4UT09OjoilD9XMkacehw2pK9/MSM0","ZlVFcTk5eTlqZi9DdUFpTjlUTmxkZz09Ojou5nNzng6nR+zbPgdHWUH9","b2FaVENqdTk5VWNJV3EzQXB2b2ZHZz09OjrLV4ttTzfLuKmF897/UfzP","cEJNWWVuckJld2JEV3ZzVnJaUDlJQT09OjrLjMOJet5/hkVvr8n+VqFr","TW5xR3p4MWs2RHB0ZUI0SlFzRFozUT09OjpYbVJ0KTVxlDwRuAxaioUS","di9qeUdBNEtCSGRpSUtGNEV5TzlGUT09Ojq3o57MKsnXuLnJ1FWrrgsW","YkNxeCtiWmxNcTBQMnRiQkR5THZ6Zz09OjoR+wibMbZu6vNCFSV9QoCp","bXJDQlNUUWdtUmhOcWxiSThpd2FtUT09OjpFEAJcA++F7x/rS3z1kahB","ZVA0RG5IOERSRE9BekQ5WWFsdFhJUT09OjrzHh0tJ0jGVSX07GFjm9/K","dTZ2c0x6bHBwbU9WdWlldW1VSHlHUT09OjqMKkXK2/N31LOh0Xz4BcQ7","bVpHSHFjcFIzSTJiQzJWL0FmenMydz09Ojo9DL50bn18Vt1EXr8haX9G","cU5Fdm96V253MVd5bll0enNpQXlTQT09OjrD4CQlFDE0Gxwzeacsjjp8","NmpMZVdISWdaU3VSWHExUzltbWUzZz09OjpKGbXGoMB8IC2TTG6a48Dw","RFpmSTRmT2FtbXNmbE1sbFgvNldkUT09OjogGdVUlKEnfuhUfcVNKSGt","T2NZb3dnVjhpSDRjZjMvbVB5WWJ5Zz09OjpX7yVSmaaNULzizCbm2itV","YVowbHlDQjg0d1MzS2ViTDluU1hoQT09OjrymQmDJAxxPzwx4MdNujDf","V1JmZXpVOWZYZFVPUjllRjZtS1h4QT09OjolF/F7NFoiKhyaTGOq+rLz","0","0","0","0","0","1","0","0","","","0","","2024-11-11 22:00:23");



CREATE TABLE `trainors` (
  `trainor_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `middle_name` text DEFAULT NULL,
  `last_name` text NOT NULL,
  `contact_number` text DEFAULT NULL,
  `email` text NOT NULL,
  `tesda_accreditation_no` text DEFAULT NULL,
  `expertise` text DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`trainor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO trainors VALUES("1","Rene","Mazaredo","Sanque","09171234567","renes@example.com","T001","Automotive","0","","2024-11-11 21:00:48");
INSERT INTO trainors VALUES("2","Marion","Abat","Pedrito","09281234567","marionp@example.com","T002","Bread and Pastry","0","","2024-11-11 21:00:48");
INSERT INTO trainors VALUES("3","Apple","Rodriguez","Nillo","09391234567","applen@example.com","T003","Hairdressing","0","","2024-11-11 21:00:48");
INSERT INTO trainors VALUES("4","Magdalena","Anong","Problema","09401234567","magdap@example.com","T004","Dressmaking","0","","2024-11-11 21:00:48");
INSERT INTO trainors VALUES("5","Hyacent","Shahanie","Muripaga","09511234567","hyacentm@example.com","T005","Tailoring","0","","2024-11-11 21:00:48");
INSERT INTO trainors VALUES("6","Sergei","Ghost","Sison","09621234567","sergeis@example.com","T006","Japanese Language","0","","2024-11-11 21:00:48");
INSERT INTO trainors VALUES("7","Adah","Moo","Luken","09731234567","adahl@example.com","T007","Driving","0","","2024-11-11 21:00:48");



CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `middle_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` text NOT NULL,
  `role` enum('Administrator','Registrar') NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO users VALUES("1","cC9uSzAzTTV5aUpNc1ZBT0RwUWhhZz09Ojr0dgLzu/hJMk03wUI9SkUj","bERkRjF1dVNuRXYxNGEvNS9LZG9qUT09Ojr9uFbR8Yj/j0OS42YnUtvN","SXdpRnpncUcwU1dMbS9LNEJ0YmZ5UT09Ojpps3N44HRnvuoq66DHWfgt","Admin","Administrator","$2y$10$GJQScMUJMHZTFjfdl9L33eXxvl05vHP57foZHlaqQUUT8sST.AyYG","2024-11-12 14:56:26");

