<?php

session_start();
include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit();
}

// FETCH USERS
$user_id = $_SESSION['user_id'];
$query = "SELECT full_name, username, password FROM library_users WHERE user_id = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die('MySQL prepare error: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// After fetching user data
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $full_name = $user['full_name'];

    $_SESSION['full_name'] = $full_name; 
} else {
    echo "User not found.";
    exit();
}

$limit = 10; // Number of books per page
$page_no = isset($_GET['page_no']) && $_GET['page_no'] !== "" ? (int)$_GET['page_no'] : 1;
$offset = ($page_no - 1) * $limit; // Calculate the offset for SQL

// Get the total number of books for pagination
$total_books_sql = "SELECT COUNT(*) as total_books FROM books";
$total_books_result = mysqli_query($conn, $total_books_sql);
$total_books_row = mysqli_fetch_assoc($total_books_result);
$total_books = $total_books_row['total_books'];

// Calculate total number of pages
$total_no_of_pages = ceil($total_books / $limit);
$previous_page = $page_no - 1;
$next_page = $page_no + 1;

// Fetch the books for the current page
$sql = "SELECT * FROM books LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// Fetch total borrowers
$total_borrowers_sql = "SELECT COUNT(DISTINCT name) as total_borrowers FROM borrow";
$total_borrowers_result = mysqli_query($conn, $total_borrowers_sql);
$total_borrowers_row = mysqli_fetch_assoc($total_borrowers_result);
$total_borrowers = $total_borrowers_row['total_borrowers'];

// Fetch recent books added (latest 5)
$recent_books_sql = "SELECT * FROM books ORDER BY date_received DESC LIMIT 5";
$recent_books_result = mysqli_query($conn, $recent_books_sql);

// Fetch recent borrowed books (latest 5)
$recent_borrowed_sql = "SELECT * FROM borrow ORDER BY date DESC LIMIT 5";
$recent_borrowed_result = mysqli_query($conn, $recent_borrowed_sql);
?>

<div class="content-body">
    <div class="container-fluid">
        
    <div class="row page-titles mx-0" id="hide">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                        <h4>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h4>
                        <?php
                            
                            // Admin Role
                            if ($_SESSION['role'] == 'Administrator') {
                                echo "<p class='mb-0'>This is Admin Panel</p>";

                            // Registrar Role
                            } elseif ($_SESSION['role'] == 'Librarian') {
                                echo "<p class='mb-0'>This is Librarian Panel</p>";
                            }
                            ?>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        </ol>
                    </div>
                </div>
        <div class="row">
            <div class="col-lg-6 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Total Books</div>
                            <div class="stat-digit"><?php echo $total_books; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Total Borrowers</div>
                            <div class="stat-digit"><?php echo $total_borrowers; ?></div>  
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Books Added Section -->
        
        <div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="card-header">
                            </div>
                            <div class="card-body">
                                
        <div class="col-lg-12 mb-12">
                                                <center><h6 class="text-primary">RECENT BOOKS ADDED</h6></center>
                                            </div>
                                <div class="table-responsive">
                                    <table id="example" class="display table-responsive-sm" style="min-width: 845px">
                                        <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Publisher</th>
                    <th>Date Received</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($recent_books_result->num_rows > 0) {
                    while ($row = $recent_books_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['title_of_book'] . "</td>";
                        echo "<td>" . $row['author'] . "</td>";
                        echo "<td>" . $row['publisher'] . "</td>";
                        echo "<td>" . $row['date_received'] . "</td>";
                        echo "</tr>";
                    }
                } 
                ?>
            </tbody>
        </table>

       
    </div>
</div>

<!-- Required vendors -->
<script src="../bootstrap/vendor/global/global.min.js"></script>
<script src="../bootstrap/js/quixnav-init.js"></script>
<script src="../bootstrap/js/custom.min.js"></script>

<script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
<script>
        document.addEventListener("DOMContentLoaded", function() {
            setTimeout(function() {
                var message = document.getElementById("hide");
                if (message) {
                    message.style.display = "none"; 
                }
            }, 10000);
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>