<?php
session_start();
include 'header.php';
include 'sidebar.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit();
}
if (isset($_POST['addUser'])) {
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO library_users (full_name, username, role, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ssss", $full_name, $username, $role, $password);
        if ($stmt->execute()) {
            echo "<script>alert('User added successfully'); window.location='user_settings.php';</script>";
        } else {
            echo "<script>alert('Error adding user: " . $stmt->error . "');</script>";
        }
    } else {
        echo "<script>alert('Statement preparation failed: " . $conn->error . "');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Library Management System - User Management</title>
</head>
<body>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Book Masterlist</h4>
                    <p class="mb-0">Book Lists</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">Add New User
                </button>
            </div>
        </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="display" style="min-width: 845px">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Account Name</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $sql = "SELECT * FROM library_users"; // Ensure you're using the correct table
                                            $result = $conn->query($sql);
                                            $count = 1;
                                            
                                            if (!$result) {
                                                echo "<tr><td colspan='4'>Error fetching users: " . $conn->error . "</td></tr>";
                                            } else {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . $row['full_name'] . "</td>";  
                                                    echo "<td>" . $row['username'] . "</td>";
                                                    echo "<td>" . $row['role'] . "</td>";
                                                    echo "<td>
                                                            <span>
                                                            <a href='edit_user.php' class='mr-4 edit-btn'
                                                                data-id='{$row['user_id']}'
                                                                data-accountname='{$row['full_name']}'
                                                                data-username='{$row['username']}'
                                                                 data-userrole='{$row['role']}'
                                                                data-toggle='modal' data-target='#editUserModal'>
                                                                <i class='fa fa-edit' style='color: green; font-size: 15px;'></i>
                                                            </a>
                                                            <a href='delete_user.php?user_id={$row['user_id']}' 
                                                                data-toggle='tooltip' data-placement='top' title='Delete' 
                                                                onclick=\"return confirm('Are you sure you want to delete this user?')\">
                                                                <i class='fa fa-trash' style='color: red; font-size: 15px;'></i>                                                                </a>
                                                            </span>
                                                          </td>";
                                                    echo "</tr>";
                                                }
                                            }
                                            
                                        ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>#</th>
                                            <th>Account Name</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>

                                <!-- Add User Modal -->
                                <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="user_settings.php" method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="full_name">Account Name</label>
                                                        <input type="text" class="form-control" name="full_name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username">Username</label>
                                                        <input type="text" class="form-control" name="username" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="password">Password</label>
                                                        <input type="password" class="form-control" name="password" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="role">Role</label>
                                                        <select class="form-control" name="role" required>
                                                            <option class="admin" id="admin" value="Administrator">Administrator</option>
                                                            <option class="librarian" id="librarian" value="Librarian">Librarian</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="addUser" class="btn btn-primary">Add User</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Required vendors -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    <script src="../bootstrap/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../bootstrap/js/plugins-init/datatables.init.js"></script>
</body>
</html>
<?php

include 'edit_user.php';
if (isset($_POST['editUser'])) {
    $user_id = $_POST['user_id'];
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $role = $_POST['role'];

    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $sql = "UPDATE library_users SET full_name=?, username=?, role=?, password=? WHERE user_id=?";
        $stmt = $conn->prepare($sql);
        
        $stmt->bind_param("ssssi", $full_name, $username, $role, $password, $user_id);
    } else {
        // If password is not provided, don't update it
        $sql = "UPDATE library_users SET full_name=?, username=?, role=?, WHERE user_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $account_name, $username, $role, $user_id); 
    }

    // Execute the prepared statement
    if ($stmt->execute()) {
        echo "<script>alert('User updated successfully'); window.location='user_settings.php';</script>";
    } else {
        echo "<script>alert('Error updating user: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    var_dump($_POST); 
}
?>