<?php 
include '../Database/Database.php'; 
include 'header.php';
include 'sidebar.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $conn->prepare("SELECT * FROM borrow WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $borrow = $result->fetch_assoc();
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $id = $_POST['id'];  // Retrieve ID from the hidden input field
    $date = $_POST['date'];
    $name = $_POST['name'];
    $number = $_POST['number'];
    $title_of_book = $_POST['title_of_book'];
    $author = $_POST['author'];
    $course = $_POST['course'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("UPDATE borrow SET date = ?, name = ?, number = ?, title_of_book = ?, author = ?, course = ? WHERE id = ?");

    if (!$stmt) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("ssisssi", $date, $name, $number, $title_of_book, $author, $course, $id);

    // Execute the statement and handle the result
    if ($stmt->execute()) {
        echo "<script>alert('Borrow record updated successfully!'); window.location.href = 'borrow.php';</script>";
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Borrow Record</title>
</head>
<body>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Update Borrower Details</h4>
                    <p class="mb-0">Updating of Borrower Details</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Add Book</a></li>
                    <li class="breadcrumb-item active"><a href="./Dashboard.php">Home</a></li>
                </ol>
            </div>
        </div>
    <div class="row">
        <div class="col-xl-12 col-xxl-12">
            <div class="card">
                <div class="card-header"></div>
                <div class="card-body">
                    <form method="POST" action="update_borrow.php?id=<?php echo $id; ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <div class="row">
                            <div class="col-lg-12 mb-12">
                                <center><h4>UPDATE BOOK BORROWER FORM</h4></center>
                                <hr>
                            </div>

                            <div class="col-lg-9 mb-12">
                                <div class="form-group">
                                    <label for="name">Name:</label><span class="text-danger">*</span>
                                    <input type="text" id="name" name="name" 
                                        class="form-control" required 
                                        value="<?php echo $borrow['name']; ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 mb-12">
                                <div class="form-group">
                                    <label for="date">Date:</label><span class="text-danger">*</span>
                                    <input type="date" id="date" name="date" 
                                        class="form-control" required 
                                        value="<?php echo $borrow['date']; ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 mb-12">
                                <div class="form-group">
                                    <label for="number">Book Number:</label><span class="text-danger">*</span>
                                    <input type="text" id="number" name="number" 
                                        class="form-control" required 
                                        value="<?php echo $borrow['number']; ?>">
                                </div>
                            </div>

                            <div class="col-lg-9 mb-12">
                                <div class="form-group">
                                    <label for="title_of_book">Book Title:</label><span class="text-danger">*</span>
                                    <input type="text" id="title_of_book" name="title_of_book" 
                                        class="form-control" required 
                                        value="<?php echo $borrow['title_of_book']; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6 mb-12">
                                <div class="form-group">
                                    <label for="author">Author:</label><span class="text-danger">*</span>
                                    <input type="text" id="author" name="author" 
                                        class="form-control" required 
                                        value="<?php echo $borrow['author']; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6 mb-12">
                                <div class="form-group">
                                    <label for="course">Course:</label><span class="text-danger">*</span>
                                    <input type="text" id="course" name="course" 
                                        class="form-control" required 
                                        value="<?php echo $borrow['course']; ?>">
                                </div>
                            </div>

                            <div class="col-lg-12 mb-12">
                            <button type="submit" class="btn btn-primary">Update</button>
                                <a href="./borrow.php" class="btn btn-danger">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

    <!-- Include your JS or Bootstrap scripts -->
    <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
</body>
</html>
