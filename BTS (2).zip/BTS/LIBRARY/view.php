<?php
include 'header.php';
include 'sidebar.php';

if (isset($_GET['books_id'])) {
    $books_id = intval($_GET['books_id']);

    $stmt = $conn->prepare("SELECT * FROM books WHERE books_id = ?");
    $stmt->bind_param("i", $books_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if book exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<p>Book not found!</p>";
        exit;
    }
} else {
    echo "<p>Invalid book ID!</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Details</title>
</head>
<body>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Add Book</h4>
                    <p class="mb-0">Adding of Book Form</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Add Book</a></li>
                    <li class="breadcrumb-item active"><a href="./Dashboard.php">Home</a></li>
                </ol>
            </div>
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <form method="POST" action="book.php" >
                            <div>
                                <div class="row">
                                    
                                <div class="col-12">
                                <p><strong>Title:</strong> <span><?php echo htmlspecialchars($row['title_of_book']); ?></span></p>
                                <p><strong>Author:</strong> <span><?php echo htmlspecialchars($row['author']); ?></span></p>
                                <p><strong>Edition:</strong> <span><?php echo htmlspecialchars($row['edition']); ?></span></p>
                                <p><strong>Volumes:</strong> <span><?php echo htmlspecialchars($row['volumes']); ?></span></p>
                                <p><strong>Pages:</strong> <span><?php echo htmlspecialchars($row['pages']); ?></span></p>
                                <p><strong>Source of Fund:</strong> <span><?php echo htmlspecialchars($row['source_of_fund']); ?></span></p>
                                <p><strong>Cost Price:</strong> <span><?php echo htmlspecialchars($row['cost_Price']); ?></span></p>
                                <p><strong>Publisher:</strong> <span><?php echo htmlspecialchars($row['publisher']); ?></span></p>
                                <p><strong>Year:</strong> <span><?php echo htmlspecialchars($row['year']); ?></span></p>
                                <p><strong>Date Received:</strong> <span><?php echo htmlspecialchars($row['date_received']); ?></span></p>
                                <p><strong>Class:</strong> <span><?php echo htmlspecialchars($row['class']); ?></span></p>
                                <p><strong>Remarks:</strong> <span><?php echo htmlspecialchars($row['remarks']); ?></span></p>
                                <a href="book.php" class="btn btn-primary">Back to Masterlist</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

       <!-- Required vendors -->
       <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
