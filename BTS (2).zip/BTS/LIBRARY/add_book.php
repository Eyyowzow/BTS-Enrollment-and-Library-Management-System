<?php
session_start();

include 'header.php';
include 'sidebar.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit();
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add book</title>

</head>
<body>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Add Book</h4>
                    <p class="mb-0">Adding of Book Form</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Add Book</a></li>
                    <li class="breadcrumb-item active"><a href="./Dashboard.php">Home</a></li>
                </ol>
            </div>
        </div>
        
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <form method="POST" action="book.php" >
                            <div>
                                <div class="row">
                                    <div class="col-lg-12 mb-12">
                                    <center><h4 id="addBook">ADD BOOK FORM</h4></center>
                                    <hr>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <h6 class="text-primary">BOOK INFORMATION</h6>
                                    </div>
                                    <div class="col-lg-6 mb-12">
                                        <div class="form-group">
                                            <label for="title_of_book">Book Title:</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                            <input type="text" id="title_of_book" name="title_of_book" class="form-control" placeholder="Enter Book Title" required>
                                                <div class="input-group"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-12">
                                        <div class="form-group">
                                        <label for="author">Author:</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                            <input type="text" id="author" name="author" placeholder="Enter Author Name" class="form-control">
                                                <div class="input-group"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-12">
                                        <div class="form-group">
                                        <label for="edition">Edition:</label>
                                            <input type="text" id="edition" name="edition" placeholder="Book Edition" class="form-control">
                                                <div class="input-group" id="studentList"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-12">
                                        <div class="form-group">
                                        <label for="volumes">Volumes:</label>
                                            <input type="text" id="volumes" name="volumes" placeholder="Book Volume" class="form-control">
                                                <div class="input-group" id="studentList"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-12">
                                        <div class="form-group">
                                        <label for="pages">Pages:</label>
                                        <input type="number" id="pages" placeholder="Pages" name="pages" class="form-control">
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-12">
                                        <div class="form-group">
                                        <label for="year">Year:</label>
                                        <input type="number" id="year" name="year" placeholder="Year" class="form-control">
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-12">
                                        <div class="form-group">
                                        <label for="publisher">Publisher:</label>
                                        <input type="text" id="publisher" name="publisher" placeholder="Publisher" class="form-control">
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-12">
                                        <div class="form-group">
                                        <label for="source_of_fund">Source of Fund:</label>
                                        <input type="text" id="source_of_fund" name="source_of_fund" placeholder="Source of Fund" class="form-control">
                                                <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-12">
                                        <div class="form-group">
                                        <label for="cost_Price">Cost Price:</label>
                                        <input type="number" step="0.01" placeholder="Price" id="cost_Price" name="cost_Price" class="form-control">
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 mb-12">
                                        <div class="form-group">
                                        <label for="date_received">Date Received:</label>
                                        <input type="date" id="date_received" name="date_received"class="form-control">
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-12">
                                        <div class="form-group">
                                        <label for="location">Location:</label>
                                        <input type="text" id="location" placeholder="Location" name="location" class="form-control">
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-12">
                                        <div class="form-group">
                                        <label for="class">Class:</label>
                                        <input type="text" id="class" placeholder="Class" name="class" class="form-control">
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <div class="form-group">
                                        <label for="remarks">Remarks:</label>
                                        <textarea id="remarks" name="remarks" class="form-control"></textarea>
                                            <div class="input-group"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-12">
                                        <center><button type="submit" class="btn btn-primary" name="addBook">Add book</button></center>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
     <script src="../bootstrap/vendor/global/global.min.js"></script>
    <script src="../bootstrap/js/quixnav-init.js"></script>
    <script src="../bootstrap/js/custom.min.js"></script>
    <script src="../bootstrap/vendor/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="../bootstrap/vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Form validate init -->
    <script src="../bootstrap/js/plugins-init/jquery.validate-init.js"></script>
    <!-- Form step init -->
    <script src="../bootstrap/js/plugins-init/jquery-steps-init.js"></script>
</body>
</html>