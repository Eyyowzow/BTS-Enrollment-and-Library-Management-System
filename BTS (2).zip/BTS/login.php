<?php
session_start();
include './Database/Database.php'; 
include './ENROLLMENT/encryption.php'; 

$sql = "SELECT * FROM users WHERE username = 'Admin'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $first_name = encryptData('Admin');
    $middle_name = encryptData('A');
    $last_name = encryptData('User');
    $username = 'Admin';
    $role = 'Administrator';

    $user_password = password_hash('admin', PASSWORD_DEFAULT); 

    $sql = "INSERT INTO users (first_name, middle_name, last_name, username, role, user_password) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssss', $first_name, $middle_name, $last_name, $username, $role, $user_password);

    if ($stmt->execute()) {
        echo "New admin user created successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>


<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BTS Enrollment Management System</title>
    <link rel="icon" type="../bootstrap/image/png" sizes="16x16" href="./bootstrap/images/logo.png">
    <link href="./bootstrap/css/style.css" rel="stylesheet">
    <style>
        body {
            background-image: url('./ASSETS/7.jpg');
            background-repeat: no-repeat;
            background-size: cover;
        }
        div.authincation-content {
            border-radius: 9px;
            color: #5d5d5d;
        }
    </style>
</head>
<body class="h-100">
    <div class="authincation h-100">
        <div class="container-fluid h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-4">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Benguet Technical School <br> Enrollment Management System</h4>
                                    <form action="login.php" method="POST">
                                        <div>
                                            <center><img src="./bootstrap/images/logo.png" height="100px" class="img-responsive" alt=""/></center>
                                        </div><br>
                                        <div class="form-group">
                                            <input type="text" name="username" class="form-control" placeholder="Username" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="user_password" class="form-control" placeholder="Password" required>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p>Sign in for Library? <a class="text-primary" href="./LIBRARY/login.php">Sign In</a></p>
                                    </div>

                                    <?php
                                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                        $username = $_POST['username'];
                                        $user_password = $_POST['user_password'];

                                        $sql = "SELECT * FROM users WHERE username = ?";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param('s', $username);
                                        $stmt->execute();
                                        $result = $stmt->get_result();

                                        if ($result->num_rows > 0) {
                                            $user = $result->fetch_assoc();
                                            if (password_verify($user_password, $user['user_password'])) {
                                                $_SESSION['user_id'] = $user['user_id'];
                                                $_SESSION['role'] = $user['role'];
                                                header("Location: ./ENROLLMENT/index.php");
                                                exit();
                                            } else {
                                                echo "<div class='alert alert-danger'>Invalid password.</div>";
                                            }
                                        } else {
                                            echo "<div class='alert alert-danger'>Invalid username.</div>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="./bootstrap/vendor/global/global.min.js"></script>
    <script src="./bootstrap/js/quixnav-init.js"></script>
    <script src="./bootstrap/js/custom.min.js"></script>

</body>
</html>
